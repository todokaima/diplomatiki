# engineKubernetes

engineJava on Kubernetes, across two machines on one LAN. A pod is one engine node --
the same worker and head that run side by side on a machine, sharing a directory -- and
it resolves artifacts and runs jobs exactly as engineJava does on its own. Kubernetes
places the pods, names them, restarts them, and -- with KEDA -- decides how many there are.

```
                              your LAN
  ┌─────────────────────────────────┐      ┌─────────────────────────────────┐
  │ PC1  k3s server + registry      │      │ PC2  k3s agent                  │
  │  StatefulSet engine-pc1  1..12  │◄────►│  StatefulSet engine-pc2  1..20  │
  │   pod engine-pc1-0, -1, ...     │ pod  │   pod engine-pc2-0, -1, ...     │
  │    ├ worker ./node  (1 thread)  │ net  │    ├ worker ./node  (1 thread)  │
  │    └ head   JobServerCli        │      │    └ head   JobServerCli        │
  │  pod etcd,  KEDA,  metrics      │      │                                 │
  └────────────────▲────────────────┘      └────────────────▲────────────────┘
                   │  <any node ip>:30100 = engine-pc1-0,  :30101 = engine-pc2-0
            any machine on the LAN:  pipeIn send / fetch,  ./k8s.sh grind
```

- **One StatefulSet per machine.** `engine-pc1` is pinned to node `pc1`, `engine-pc2` to
  `pc2` (the names `lan/server.sh` and `lan/pc2.sh` give them). A pod is one worker
  thread asking for 900m of CPU, so a pod is a core.
- **The heads spread the work.** Jobs are sent to engine-pc1-0; its head, run with
  `--spread`, ships every ready job in turn -- with its `.so` and data, marked SHIPPED --
  to each node registered in etcd, itself included. A pod that has just started
  registers, and gets its share of the next jobs to arrive.
- **The heads fetch what they lack.** A head whose job lacks a `.so` or data asks another
  head for it; the answer is the object, or WAITING and a push once it exists.
- **KEDA sizes each machine's share** on worker CPU: 1..12 pods on pc1, 1..20 on pc2
  (`./k8s.sh keda`, below).

Built from the sibling projects: `../engineJava` (the engine) and `../pipeIn` (the jobs).

## What you need

- Two Ubuntu machines on the same LAN that can reach each other.
- On PC1: docker (to build the image and run the registry), kubectl, python3.
- Nothing else on PC2 -- it runs containers pulled from PC1.

## 1. The cluster (once)

On **PC1**, with its LAN interface and address (`ip -br addr`):

    sudo lan/server.sh enp34s0 192.168.1.10

It installs the k3s server, starts an image registry on :5000, adds the kubectl
context `engine-lan`, opens the firewall if ufw is on, and prints PC2's command:

    scp lan/pc2.sh <user>@<pc2-ip>:~
    sudo SERVER_IP=192.168.1.10 NODE_IP=192.168.1.11 ./pc2.sh <token>       # on PC2

Check from PC1: `kubectl get nodes -o wide` -- both Ready.

**One PC only?** Run `sudo lan/server.sh <iface> <ip>` and skip PC2. With a single node,
`./k8s.sh up` applies `k8s/one-machine`, which unpins both StatefulSets from their
machines, so both run on this PC and everything below works the same. Any
single-node cluster will do (kind, minikube, docker-desktop: `./k8s.sh load` handles
them); `ONE_MACHINE=1` forces it.

## 2. The engine

On PC1:

    ./k8s.sh demo

which is, step by step:

    ./k8s.sh image      # build engine:dev: node, head.jar, and pipeIn's jobs built inside it
    ./k8s.sh load       # push it to PC1's registry; both machines pull it from there
    ./k8s.sh up         # etcd, one engine pod on each machine, the LAN ports
    ./k8s.sh jobs       # copy the jobs built in the image to ./out
    ./k8s.sh submit     # pipeIn send: the demo load's 10 jobs to engine-pc1-0
    ./k8s.sh results    # pipeIn fetch: every result by job id from both, then verify
    ./k8s.sh logs       # both pods' logs -> results/<timestamp>/, with the cross-node lines

`results` should end with every job `ok`. `logs` prints the lines that show the two heads
working together -- `asked ... for data <id>`, `answered ...`, `... does not hold ... yet`.

`./k8s.sh status` shows the machines, the pods and what each head has published to etcd;
`./k8s.sh down` removes it all.

## 3. Test loads: watching jobs cross

In one terminal:

    ./k8s.sh watch

follows both heads, one line per event, prefixed with the pod:

    [pod/engine-pc1-0/head] ... job 3f2a... shipped to engine-pc2-0
    [pod/engine-pc2-0/head] ... received job 3f2a... from engine-pc1-0
    [pod/engine-pc2-0/head] ... job 3f2a... resolved, running here (shipped here)
    [pod/engine-pc1-0/head] ... asked engine-pc2-0 for data 3f2a...  <- a dependent job
    [pod/engine-pc2-0/head] ... promised engine-pc1-0 3f2a..., then pushed it

In another, any load:

    LOAD=crossing ./k8s.sh submit && LOAD=crossing ./k8s.sh results
    ./k8s.sh suite       # fresh pods, then smoke, demo, crossing, bulk and cpu, each verified

`BOTH=1 ./k8s.sh submit` sends alternately to both nodes instead (each head then spreads
what it was given). `../pipeIn/pipein.py list` describes the loads.

## Autoscaling on CPU: KEDA and a grinding load

Each machine's number of engine pods follows how hard its workers work. Once the
cluster is up (sections 1 and 2), on PC1:

    ./k8s.sh keda        # metrics-server if missing (k3s has it), KEDA, the two ScaledObjects
    ./k8s.sh grind       # terminal 1: CPU-only jobs, every 10 s, until ctrl-c
    ./k8s.sh scale       # terminal 2: ScaledObjects, HPAs, pods per machine, CPU per node
    ./k8s.sh ran         # afterwards: jobs run by each pod

**What has to be in place** for the CPU trigger to work, and where it is set:

| what | why | where |
|---|---|---|
| metrics-server | the HPA reads pod CPU from it | k3s ships it; `./k8s.sh keda` installs it otherwise |
| KEDA (operator, metrics API, webhook) | turns a ScaledObject into an HPA | `./k8s.sh keda`: `helm`, or the release manifest |
| a CPU **request** on the worker container | utilisation is a share of the request: no request, no percentage | `k8s/engine.yaml`: `cpu: 900m` |
| one worker thread per pod | a pod is then one core | `k8s/config.yaml`: `ENGINE_THREADS: "1"` |
| no `replicas` in the StatefulSets | KEDA owns the count; re-applying never resets it | `k8s/engine.yaml` |
| the ScaledObjects | min/max pods, the 60 % target, how fast to grow and shrink | `k8s/autoscale/scaledobjects.yaml` |

**What happens.** `grind` sends engine-pc1-0 a batch of `spin` jobs every 10 seconds --
7 jobs of about 1.8 s of one core per running engine pod, a third more than the pods can
do -- and its head spreads them over every node in etcd. Every worker is busy, one busy
thread reads about 110 % of its 900m request, and the 60 % target makes each StatefulSet
grow (at most four pods every 15 s) until pc1 runs 12 pods and pc2 runs 20. New pods
register in etcd and get their share of the next batch. Stop `grind` and, once the queues
drain and two quiet minutes pass, each machine shrinks back to one pod, two pods a minute.

    PC1_MAX=8 PC2_MAX=16 ./k8s.sh keda                 # other limits
    GRIND_EVERY=5 GRIND_PER_POD=4 ./k8s.sh grind       # another pace
    ./k8s.sh keda-off                                  # fixed at one pod per machine again

**Limits of this set-up.**
- The grind jobs are independent and their results are not collected: scaling down
  deletes a pod and its results with it.
- A head asks *one* other head -- the first etcd lists -- for what it lacks. With exactly
  two nodes that is always the right one; with many, a dependent job whose producer ran on
  a third pod may wait for ever. Run the dependent loads (`demo`, `crossing`, `smokes`)
  with `./k8s.sh keda-off`.
- `grind` runs anywhere on the LAN with `../pipeIn` and `./out` (`./k8s.sh jobs`), and
  needs `kubectl` there only to count the running pods.

## 4. Timing

The `swarm` load is 5000 tiny jobs (one row of four values, 500 of them in two-step
chains), so what is measured is the system's cost per job -- receiving, resolving,
shipping, running, answering -- not the functions. It runs with `--spread`, 4 worker
threads and 16 slots per node:

**On Kubernetes** (PC1):

    ./k8s.sh bench

restarts the engine pods (empty `/data`), runs `pipein.py bench` against the NodePorts,
and puts both pods' logs and a per-node tally beside the timings in
`out/bench/k8s-<time>/`.

Each run directory holds `bench.log` (every event with its time), `results.csv`,
`summary.json`, the heads' and workers' logs, and `tally.txt` (per node: jobs run, jobs
shipped, requests made). Run each two or three times: the first run on a machine also
pays for the JVM warming up.

## From another machine on the LAN

Any machine with python3, `../pipeIn`, `../engineJava/worker/contract.h` and a copy of
`./out` can do the same:

    ../pipeIn/pipein.py send  192.168.1.10:30100 192.168.1.10:30101 --out out
    ../pipeIn/pipein.py fetch 192.168.1.10:30100 192.168.1.10:30101 --out out

Either machine's address works: a NodePort answers on every node.

Use the jobs built in the image (`./k8s.sh jobs`), not ones built on the submitting
machine: a function is compiled once, in the image, against the same glibc the workers
load it with -- and its id is the hash of those exact bytes.

## Files

    Dockerfile        one image for both pods: node, head.jar, JRE, and pipeIn with out/ built
    k8s.sh            build, deploy, submit, collect, watch, bench
    k8s/
      engine.yaml     headless Service + StatefulSets engine-pc1, engine-pc2: worker + head per pod
                      sharing /data (socket, functions/, datasets/)
      etcd.yaml       one etcd member, on an emptyDir -- the heads' live claims only
      lan.yaml        NodePorts 30100 -> engine-pc1-0, 30101 -> engine-pc2-0
      config.yaml     etcd address, worker threads, advertised slots
      one-machine/    overlay: both StatefulSets on one machine (picked when the cluster has one node)
      autoscale/      scaledobjects.yaml: KEDA, engine-pc1 1..12 pods, engine-pc2 1..20 (./k8s.sh keda)
    lan/
      server.sh       PC1: k3s server, registry, kubectl context, lan.env
      pc2.sh          PC2: join as an agent

## When something is off

| symptom | look at |
|---|---|
| `engine-pc2-*` stays Pending | node `pc2` has not joined, or is named otherwise: `kubectl get nodes`; on one machine, `ONE_MACHINE=1 ./k8s.sh up` |
| the last pods of a machine stay Pending | its cores are taken (900m per pod, plus system pods): lower `PC1_MAX` / `PC2_MAX` |
| `kubectl get hpa` shows `<unknown>` | metrics-server not ready yet, or the pod has no CPU request -- wait a minute, `kubectl top pods` |
| pods restarting | `kubectl -n engine logs engine-pc1-0 -c head` -- `lost the worker` or `worker ... not ready` |
| `submit` cannot connect | the NodePorts: `kubectl -n engine get svc`, the firewall on 30100-30101 |
| `results` keeps waiting | a job did not run: `./k8s.sh logs`; a dependent job logs whom it asked |
| image pull errors on PC2 | `/etc/rancher/k3s/registries.yaml` on PC2 names PC1's registry |

## Limits

- **No authentication.** Anyone who can reach 30100-30101 can run code on the cluster.
  Keep it on a home network.
- **Results live as long as their pod** (`emptyDir`). `./k8s.sh results` brings them out.
- **Placement is round robin** (`--spread`): a ready job goes to whichever node's turn
  it is, not to the least loaded one. `JobFileCli` has the load-based choice.
- **The worker never reports failures.** A job whose function fails simply never has a
  result, and `fetch` says which ones after `--wait` seconds.

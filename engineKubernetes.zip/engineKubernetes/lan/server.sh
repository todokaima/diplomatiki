#!/usr/bin/env bash
# usage: sudo lan/server.sh IFACE IP
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

IFACE="${1:?usage: sudo lan/server.sh <iface> <ip>}"
IP="${2:?usage: sudo lan/server.sh <iface> <ip>}"

[ "$(id -u)" -eq 0 ] || { echo "run with sudo" >&2; exit 1; }
USER_HOME="$(getent passwd "${SUDO_USER:-root}" | cut -d: -f6)"
ip -br addr show "$IFACE" | grep -q "$IP/" || { echo "!! $IFACE does not have $IP" >&2; exit 1; }

echo "== registry (docker, port 5000)"
command -v docker >/dev/null || { echo "!! needs docker, to build and serve the engine image" >&2; exit 1; }
docker inspect engine-registry >/dev/null 2>&1 \
    || docker run -d --restart=always -p 5000:5000 --name engine-registry registry:2 >/dev/null
echo "  $IP:5000"

echo "== k3s: pull $IP:5000 over plain http"
mkdir -p /etc/rancher/k3s
cat > /etc/rancher/k3s/registries.yaml <<YAML
mirrors:
  "$IP:5000":
    endpoint:
      - "http://$IP:5000"
YAML

echo "== firewall"
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow 6443/tcp >/dev/null
    ufw allow 8472/udp >/dev/null
    ufw allow 10250/tcp >/dev/null
    ufw allow 30100:30101/tcp >/dev/null
    ufw allow 5000/tcp >/dev/null
    echo "  ufw: opened 6443, 8472/udp, 10250, 30100-30101, 5000"
else
    echo "  ufw not active: nothing to open"
fi

echo "== k3s server"
curl -sfL https://get.k3s.io | INSTALL_K3S_EXEC="server --node-name ${NODE_NAME:-pc1} \
    --node-ip $IP --advertise-address $IP --tls-san $IP \
    --flannel-iface $IFACE --disable traefik --write-kubeconfig-mode 644" sh -
systemctl restart k3s

echo "== kubectl context engine-lan"
mkdir -p "$USER_HOME/.kube"
sed -e "s/127.0.0.1/$IP/" -e 's/: default$/: engine-lan/' /etc/rancher/k3s/k3s.yaml \
    > "$USER_HOME/.kube/engine-lan.yaml"
if [ -f "$USER_HOME/.kube/config" ]; then
    cp "$USER_HOME/.kube/config" "$USER_HOME/.kube/config.before-engine-lan"
    KUBECONFIG="$USER_HOME/.kube/config:$USER_HOME/.kube/engine-lan.yaml" \
        kubectl config view --flatten > "$USER_HOME/.kube/config.merged"
    mv "$USER_HOME/.kube/config.merged" "$USER_HOME/.kube/config"
else
    cp "$USER_HOME/.kube/engine-lan.yaml" "$USER_HOME/.kube/config"
fi
chown -R "${SUDO_USER:-root}": "$USER_HOME/.kube"
chmod 600 "$USER_HOME/.kube/config"
sudo -u "${SUDO_USER:-root}" kubectl config use-context engine-lan >/dev/null

cat > lan.env <<ENV
# written by lan/server.sh -- read by k8s.sh when the current kubectl context is \$LAN_CONTEXT
LAN_CONTEXT=engine-lan
REGISTRY=$IP:5000
SERVER_IP=$IP
ENV
chown "${SUDO_USER:-root}": lan.env

echo
echo "== done. Now on PC2:"
echo
echo "  scp lan/pc2.sh <user>@<pc2-ip>:~"
echo "  sudo SERVER_IP=$IP NODE_IP=<pc2-ip> ./pc2.sh $(cat /var/lib/rancher/k3s/server/node-token)"

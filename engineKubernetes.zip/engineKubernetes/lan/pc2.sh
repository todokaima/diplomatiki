#!/usr/bin/env bash
# usage: sudo SERVER_IP=... NODE_IP=... ./pc2.sh TOKEN
set -euo pipefail

SERVER_IP="${SERVER_IP:?set SERVER_IP to PC1's LAN address}"
NODE_IP="${NODE_IP:?set NODE_IP to this machine's LAN address}"
NODE_NAME="${NODE_NAME:-pc2}"
TOKEN="${1:-${K3S_TOKEN:-}}"

[ "$(id -u)" -eq 0 ] || { echo "run with sudo" >&2; exit 1; }
[ -n "$TOKEN" ] || { echo "usage: sudo SERVER_IP=... NODE_IP=... ./pc2.sh <token>" >&2; exit 1; }

IFACE="$(ip -o -4 addr show | awk -v ip="$NODE_IP" 'index($4, ip "/") == 1 {print $2}')"
[ -n "$IFACE" ] || { echo "!! no interface has $NODE_IP" >&2; exit 1; }
echo "== $NODE_IP on $IFACE, cluster at $SERVER_IP"

ping -c1 -W2 "$SERVER_IP" >/dev/null || { echo "!! cannot reach $SERVER_IP" >&2; exit 1; }
command -v curl >/dev/null || { apt-get update -qq && apt-get install -y -qq curl >/dev/null; }

echo "== firewall"
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow from "$SERVER_IP" >/dev/null
    ufw allow 30100:30101/tcp >/dev/null
    echo "  ufw: allowed $SERVER_IP, opened 30100-30101"
else
    echo "  ufw not active: nothing to open"
fi

echo "== k3s agent"
mkdir -p /etc/rancher/k3s
cat > /etc/rancher/k3s/registries.yaml <<YAML
mirrors:
  "$SERVER_IP:5000":
    endpoint:
      - "http://$SERVER_IP:5000"
YAML
curl -sfL https://get.k3s.io | K3S_URL="https://$SERVER_IP:6443" K3S_TOKEN="$TOKEN" \
    INSTALL_K3S_EXEC="agent --node-name $NODE_NAME --node-ip $NODE_IP --flannel-iface $IFACE" sh -
systemctl restart k3s-agent

echo
echo "== done. On PC1: kubectl get nodes -o wide     (both Ready)"

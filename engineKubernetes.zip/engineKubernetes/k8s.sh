#!/usr/bin/env bash
# usage: ./k8s.sh COMMAND
#   demo                  image, load, up, jobs, submit, results
#   image | load | up     build engine:dev, push it to the registry, deploy
#   submit | results      send LOAD (default demo) to engine-pc1-0; fetch and verify
#   bench | suite         timed run | every load, on fresh pods
#   watch | status | logs | fresh | down
#   keda | keda-off       CPU autoscaling on | off (PC1_MAX, PC2_MAX, KEDA_STEP, KEDA_EVERY)
#   grind | scale | ran   CPU load | watch the scaling | jobs run per pod
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
HERE="$PWD"
RPC="$(dirname "$HERE")"

NS=engine
IMAGE="${IMAGE:-engine:dev}"
PIPEIN="${PIPEIN:-$RPC/pipeIn}"
TIMEOUT="${TIMEOUT:-300}"
LOAD="${LOAD:-demo}"
SETS="engine-pc1 engine-pc2"

k() { kubectl -n "$NS" "$@"; }

[ -f lan/lan.env ] && . lan/lan.env
onLan() {
    [ -n "${LAN_CONTEXT:-}" ] && [ "$(kubectl config current-context)" = "$LAN_CONTEXT" ]
}

retarget() {
    if onLan; then
        sed -e "s|image: engine:dev|image: $REGISTRY/engine:dev|" \
            -e "s|imagePullPolicy: IfNotPresent|imagePullPolicy: Always|"
    else
        cat
    fi
}

image() {
    tar -C "$RPC" \
        --exclude='engineJava/.bak' --exclude='engineJava/.idea' --exclude='engineJava/head/.idea' \
        --exclude='engineJava/head/classes' --exclude='engineJava/head/head.jar' \
        --exclude='engineJava/node' --exclude='*.o' --exclude='engine.sock' \
        --exclude='engineJava/run' --exclude='engineJava/run-*' \
        --exclude='engineJava/jobs' --exclude='engineJava/datasets' --exclude='engineJava/functions' \
        --exclude='engineJava/head/src/main/java/dev/pms/engine/.git' \
        --exclude='pipeIn/out' --exclude='__pycache__' \
        -cf - engineJava pipeIn -C "$HERE" Dockerfile \
        | docker build -f Dockerfile -t "$IMAGE" -
}

load() {
    local context
    context="$(kubectl config current-context)"

    if onLan; then
        docker tag "$IMAGE" localhost:5000/engine:dev
        docker push localhost:5000/engine:dev
        return
    fi

    case "$context" in
        kind-*)   kind load docker-image "$IMAGE" --name "${context#kind-}" ;;
        minikube) minikube image load "$IMAGE" ;;
        docker-desktop|rancher-desktop) echo "  $context shares the docker daemon: nothing to load" ;;
        *)        echo "!! context '$context': run lan/server.sh, or push $IMAGE to a registry the cluster pulls from" >&2
                  return 1 ;;
    esac
}

manifests() {
    if [ -n "${ONE_MACHINE:-}" ] || [ "$(kubectl get nodes --no-headers 2>/dev/null | wc -l)" -eq 1 ]; then
        echo "  one machine: both engine pods on it (k8s/one-machine)" >&2
        echo k8s/one-machine
    else
        echo k8s
    fi
}

up() {
    kubectl kustomize "$(manifests)" | retarget | kubectl apply -f -
    local set
    for set in $SETS; do k rollout restart "statefulset/$set" >/dev/null 2>&1 || true; done
    k rollout status statefulset/etcd --timeout="${TIMEOUT}s"
    for set in $SETS; do k rollout status "statefulset/$set" --timeout="${TIMEOUT}s"; done
    sleep 2
    status
}

jobs() {
    local container
    container="$(docker create "$IMAGE")"
    rm -rf out
    docker cp "$container:/opt/pipeIn/out" out >/dev/null
    docker rm "$container" >/dev/null
    python3 "$PIPEIN/pipein.py" list --out out
}

targets() {
    local ip="${TARGET_IP:-${SERVER_IP:-}}"
    [ -n "$ip" ] || ip="$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')"
    echo "$ip:30100 $ip:30101"
}

senders() {
    if [ -n "${BOTH:-}" ]; then targets; else targets | cut -d' ' -f1; fi
}

submit() {
    [ -f "out/loads/$LOAD/manifest.json" ] || jobs
    python3 "$PIPEIN/pipein.py" send $(senders) --load "$LOAD" --out out
}

results() {
    python3 "$PIPEIN/pipein.py" fetch $(targets) --load "$LOAD" --out out --wait "${WAIT:-120}"
}

watch() {
    k logs -f -l app=engine -c head --prefix --max-log-requests 64 --tail 0 \
        | grep --line-buffered -E "received|shipped|running here|waiting|asked|answered|does not hold|linked"
}

fresh() {
    local set
    for set in $SETS; do k rollout restart "statefulset/$set"; done
    for set in $SETS; do k rollout status "statefulset/$set" --timeout="${TIMEOUT}s"; done
    sleep 3
}

suite() {
    fresh
    [ -d out/loads ] || jobs
    for load in smoke demo crossing bulk cpu; do
        echo "==== $load"
        LOAD=$load submit
        LOAD=$load WAIT="${WAIT:-300}" results
    done
    logs
}

bench() {
    local load="${BENCH_LOAD:-swarm}" before
    [ -f "out/loads/$load/manifest.json" ] || jobs
    fresh
    before="$(date +%s)"
    python3 "$PIPEIN/pipein.py" bench $(targets) --label k8s --load "$load" --out out --wait "${WAIT:-900}" || true

    local run
    run="$(ls -dt out/bench/k8s-* | head -1)"
    for pod in $(k get pods -l app=engine -o name | sed 's|pod/||'); do
        k logs "$pod" -c head   --since-time="$(date -u -d "@$before" +%Y-%m-%dT%H:%M:%SZ)" > "$run/$pod.head.log" 2>&1 || true
        k logs "$pod" -c worker --since-time="$(date -u -d "@$before" +%Y-%m-%dT%H:%M:%SZ)" > "$run/$pod.worker.log" 2>&1 || true
    done
    tally "$run"
}

tally() {
    local log
    for log in "$1"/*.head.log; do
        printf "  %-18s ran %6d  (shipped here %6d)  shipped %6d  asked %5d  answered %5d\n" "$(basename "$log" .head.log)" \
            "$(grep -c 'running here' "$log")" "$(grep -c 'shipped here' "$log")" "$(grep -c 'shipped to' "$log")" \
            "$(grep -c 'asked' "$log")" "$(grep -c 'answered' "$log")" | tee -a "$1/tally.txt"
    done
    echo "  -> $1"
}

status() {
    kubectl get nodes -o wide
    echo
    k get pods -o wide
    echo
    k exec statefulset/etcd -- etcdctl get --prefix /engine/nodes/ 2>/dev/null \
        | paste - - | sed 's|^/engine/nodes/|  node |' || echo "  (etcd not reachable)"
}

logs() {
    local out="results/$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$out"
    for pod in $(k get pods -l app=engine -o name | sed 's|pod/||'); do
        k logs "$pod" -c worker > "$out/$pod.worker.log" 2>&1 || true
        k logs "$pod" -c head   > "$out/$pod.head.log" 2>&1 || true
    done
    grep -h -E "asked|answered|does not hold|linked to" "$out"/*.head.log | sed 's/^/  /' || true
    echo "  -> $out"
}

down() {
    kubectl delete namespace "$NS" --ignore-not-found
}

demo() {
    image && load && up && jobs && submit && results && logs
}

keda() {
    if ! kubectl -n kube-system get deployment metrics-server >/dev/null 2>&1; then
        echo "== metrics-server"
        if [ "$(kubectl config current-context)" = minikube ]; then
            minikube addons enable metrics-server
        else
            kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
        fi
    fi
    kubectl -n kube-system rollout status deployment/metrics-server --timeout="${TIMEOUT}s"

    if ! kubectl get crd scaledobjects.keda.sh >/dev/null 2>&1; then
        echo "== KEDA"
        if command -v helm >/dev/null 2>&1; then
            helm repo add kedacore https://kedacore.github.io/charts --force-update >/dev/null
            helm upgrade --install keda kedacore/keda --namespace keda --create-namespace
        else
            kubectl apply --server-side -f \
                "https://github.com/kedacore/keda/releases/download/v${KEDA_VERSION:-2.16.1}/keda-${KEDA_VERSION:-2.16.1}.yaml"
        fi
    fi
    kubectl -n keda wait --for=condition=Available deployment --all --timeout="${TIMEOUT}s"

    echo "== autoscaling: engine-pc1 1..${PC1_MAX:-12} pods, engine-pc2 1..${PC2_MAX:-20} pods, on worker CPU > 60 %,"
    echo "   growing by at most ${KEDA_STEP:-4} pod(s) per machine every ${KEDA_EVERY:-15} s"
    awk -v pc1="${PC1_MAX:-12}" -v pc2="${PC2_MAX:-20}" -v step="${KEDA_STEP:-4}" -v every="${KEDA_EVERY:-15}" '
        /name: engine-pc1/ { max = pc1 }
        /name: engine-pc2/ { max = pc2 }
        /maxReplicaCount:/ { sub(/[0-9]+/, max) }
        /scaleUp:/   { up = 1 }
        /scaleDown:/ { up = 0 }
        up && /value:/         { sub(/[0-9]+/, step) }
        up && /periodSeconds:/ { sub(/[0-9]+/, every) }
        { print }' k8s/autoscale/scaledobjects.yaml | kubectl apply -f -
    sleep 5
    k get scaledobject
    k get hpa
}

keda_off() {
    k delete scaledobject $SETS --ignore-not-found
    local set
    for set in $SETS; do k scale "statefulset/$set" --replicas=1; done
    echo "  one pod per machine again"
}

grind() {
    local every="${GRIND_EVERY:-10}" per_pod="${GRIND_PER_POD:-7}" rounds="${GRIND_ROUNDS:-0}"
    local first="${GRIND_FROM:-$(date +%s)}" round=0 target pods count batch
    [ -f out/functions.json ] || jobs
    target="$(targets | cut -d' ' -f1)"
    echo "grinding into $target: every ${every}s, $per_pod jobs of ~1.8 s per running engine pod (ctrl-c stops)"
    while :; do
        pods="$(k get pods -l app=engine --field-selector=status.phase=Running --no-headers 2>/dev/null | wc -l)"
        [ "$pods" -gt 0 ] || pods=1
        count=$(( pods * per_pod ))
        batch=$(( (first + round) % 10000 ))
        for step in vectors jobs; do
            PIPEIN_GRIND_JOBS=$count PIPEIN_GRIND_BATCH=$batch \
                python3 "$PIPEIN/pipein.py" "$step" --load grind --out out >/dev/null
        done
        PIPEIN_GRIND_JOBS=$count PIPEIN_GRIND_BATCH=$batch \
            python3 "$PIPEIN/pipein.py" send "$target" --load grind --out out >/dev/null \
            || echo "  !! could not send to $target"
        printf "  %s  round %4d: %4d jobs for %2d running pods\n" "$(date +%T)" "$round" "$count" "$pods"
        round=$(( round + 1 ))
        [ "$rounds" -gt 0 ] && [ "$round" -ge "$rounds" ] && break
        sleep "$every"
    done
}

scale() {
    while :; do
        clear
        date '+%H:%M:%S'
        k get scaledobject 2>/dev/null || true
        echo
        k get hpa 2>/dev/null || echo "(no autoscaler: ./k8s.sh keda)"
        echo
        echo "engine pods per machine:"
        k get pods -l app=engine --no-headers -o custom-columns=NODE:.spec.nodeName,PHASE:.status.phase \
            | sort | uniq -c | sed 's/^/  /'
        echo
        kubectl top nodes 2>/dev/null || true
        sleep "${EVERY:-5}"
    done
}

ran() {
    local total=0 pod n
    for pod in $(k get pods -l app=engine -o name | sed 's|pod/||' | sort -V); do
        n="$(k logs "$pod" -c head 2>/dev/null | grep -c 'running here' || true)"
        printf "  %-16s %6d jobs run\n" "$pod" "$n"
        total=$(( total + n ))
    done
    printf "  %-16s %6d\n" total "$total"
}

case "${1:-}" in
    image|load|up|jobs|submit|results|watch|suite|bench|fresh|status|logs|down|demo) "$1" ;;
    keda|grind|scale|ran) "$1" ;;
    keda-off) keda_off ;;
    tally) tally "$2" ;;
    *) sed -n '2,9p' "$0" | sed 's/^# \{0,1\}//'; exit 1 ;;
esac

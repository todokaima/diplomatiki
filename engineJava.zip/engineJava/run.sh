#!/usr/bin/env bash
# usage: ./run.sh PORT [PEER]    (THREADS, ADVERTISE)
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

PORT="${1:?usage: ./run.sh PORT [PEER]}"
case "${2:-}" in
    "")  case "$PORT" in
             9000) PEER=127.0.0.1:9100 ;;
             9100) PEER=127.0.0.1:9000 ;;
             *) echo "no default peer for port $PORT: ./run.sh $PORT PEER" >&2; exit 1 ;;
         esac ;;
    *:*) PEER="$2" ;;
    *)   PEER="127.0.0.1:$2" ;;
esac
ADVERTISE="${ADVERTISE:-127.0.0.1:$PORT}"
THREADS="${THREADS:-2}"

[ -x node ] && [ -f head/head.jar ] || ./build.sh

RUN="$PWD/run-$PORT"
rm -rf "$RUN"
mkdir -p "$RUN"

(cd "$RUN" && exec ../node --socket "$RUN/engine.sock" --datasets "$RUN/datasets" --threads "$THREADS") > "$RUN/worker.log" 2>&1 &
WORKER=$!
trap 'kill $WORKER 2>/dev/null || true' EXIT INT TERM

for _ in $(seq 50); do
    [ -S "$RUN/engine.sock" ] && break
    kill -0 "$WORKER" 2>/dev/null || { echo "worker exited:" >&2; cat "$RUN/worker.log" >&2; exit 1; }
    sleep 0.1
done

echo "node-$PORT: worker $WORKER, head on $ADVERTISE, peer $PEER, logs in $RUN"
java -cp head/head.jar dev.pms.engine.adapter.in.JobServerCli \
    --port "$PORT" --node "$RUN/engine.sock" \
    --functions "$RUN/functions" --datasets "$RUN/datasets" \
    --node-id "node-$PORT" --advertise "$ADVERTISE" --peer "$PEER" \
    2>&1 | tee "$RUN/head.log"

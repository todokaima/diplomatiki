package dev.pms.engine.adapter.peer;

import dev.pms.engine.adapter.out.log.EventLog;
import dev.pms.engine.domain.*;
import dev.pms.engine.port.ArtifactRequester;
import dev.pms.engine.port.ClusterDirectory;
import dev.pms.engine.service.ArtifactExchange;
import dev.pms.engine.service.Resolution;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;

public final class PeerNetwork implements ArtifactRequester, AutoCloseable {

    private static final int CONNECT_TIMEOUT_MILLIS = 2000;
    private static final int INTAKE_BACKLOG = 4096;
    private static final int ANSWERING_BACKLOG = 16384;

    private final String nodeId;
    private final String peerAddress;
    private final ClusterDirectory cluster;
    private final EventLog log;

    private final List<PeerLink> links = new CopyOnWriteArrayList<>();
    private final Map<String, PeerLink> linksByAddress = new ConcurrentHashMap<>();
    private final BlockingQueue<RequestObject> requests = new LinkedBlockingQueue<>();

    private ArtifactExchange exchange;
    private Consumer<JobObject> onJob;
    private Runnable onArtifact;
    private Lane intake;
    private Lane answering;
    private ServerSocket server;
    private Thread dispatcher;

    public PeerNetwork(String nodeId, String peerAddress, ClusterDirectory cluster, EventLog log) {
        this.nodeId = nodeId;
        this.peerAddress = peerAddress;
        this.cluster = cluster;
        this.log = log;
    }

    public void attach(ArtifactExchange exchange, Consumer<JobObject> onJob, Runnable onArtifact) {
        this.exchange = exchange;
        this.onJob = onJob;
        this.onArtifact = onArtifact;

        intake = new Lane("intake", INTAKE_BACKLOG, log);
        answering = new Lane("answering", ANSWERING_BACKLOG, log);

        dispatcher = new Thread(this::dispatch, "requests");
        dispatcher.setDaemon(true);
        dispatcher.start();
    }

    public void listen(int port) throws IOException {
        server = new ServerSocket(port);
        log.event("listening on %d for the other head", port);

        Thread acceptor = new Thread(() -> {
            while (!server.isClosed()) {
                try {
                    Socket socket = server.accept();
                    adopt(socket, "peer " + socket.getRemoteSocketAddress());
                } catch (IOException failed) {
                    if (!server.isClosed()) log.event("accept: %s", failed.getMessage());
                }
            }
        }, "listen " + port);

        acceptor.setDaemon(true);
        acceptor.start();
    }

    public void ship(String address, Resolution resolution, boolean jobOnly) throws IOException {
        PeerLink link = linkTo(address);

        if (link == null) throw new IOException("cannot reach " + address);

        if (jobOnly) link.send(resolution.job());
        else link.ship(resolution.function(), resolution.data(), resolution.job());
    }

    @Override
    public boolean request(RequestObject request) {
        requests.add(request);
        return true;
    }

    private void dispatch() {
        try {
            while (true) {
                RequestObject request = requests.take();
                PeerLink link = otherHead();

                if (link == null) {
                    exchange.undelivered(request);
                    continue;
                }

                link.send(request);
                log.event("asked %s for %s %016x", link.name(), request.targetType() == Wire.OBJECT_TYPE_FUNCTION ? "function" : "data", request.targetId());
            }
        } catch (InterruptedException closing) {
        }
    }

    private PeerLink otherHead() {
        if (peerAddress != null) return linkTo(peerAddress);

        if (cluster == null) return null;

        try {
            for (NodeLoad node : cluster.nodes().values())
                if (!node.nodeId().equals(nodeId)) return linkTo(node.address());
        } catch (IOException unreachable) {
        }

        return null;
    }

    private synchronized PeerLink linkTo(String address) {
        PeerLink known = linksByAddress.get(address);
        if (known != null && known.isOpen()) return known;

        int colon = address.lastIndexOf(':');
        if (colon < 0) return null;

        try {
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(address.substring(0, colon), Integer.parseInt(address.substring(colon + 1))), CONNECT_TIMEOUT_MILLIS);

            PeerLink link = adopt(socket, address);
            linksByAddress.put(address, link);
            return link;

        } catch (IOException | NumberFormatException unreachable) {
            log.event("cannot reach %s: %s", address, unreachable.getMessage());
            return null;
        }
    }

    private PeerLink adopt(Socket socket, String name) throws IOException {
        PeerLink link = new PeerLink(socket, name, exchange, onJob, onArtifact, this::onClosed, intake, answering, log);

        links.add(link);
        link.start();
        log.event("linked to %s", name);

        return link;
    }

    private void onClosed(PeerLink link) {
        links.remove(link);
        if (linksByAddress.values().remove(link)) exchange.linkClosed();
        log.event("link %s closed", link.name());
    }

    @Override
    public void close() {
        if (dispatcher != null) dispatcher.interrupt();
        if (intake != null) intake.stop();
        if (answering != null) answering.stop();

        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }

        for (PeerLink link : links)
            link.close();
    }
}

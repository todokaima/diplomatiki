package dev.pms.engine.adapter.peer;

import dev.pms.engine.adapter.out.log.EventLog;
import dev.pms.engine.adapter.out.stream.StreamObjectReader;
import dev.pms.engine.adapter.out.stream.StreamObjectWriter;
import dev.pms.engine.domain.*;
import dev.pms.engine.port.ObjectReader;
import dev.pms.engine.port.ObjectWriter;
import dev.pms.engine.service.ArtifactExchange;

import java.io.IOException;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

// only the writer thread writes to the socket, so two heads cannot deadlock
final class PeerLink implements ArtifactExchange.Replier, AutoCloseable {

    private final Socket socket;
    private final String name;
    private final ObjectReader reader;
    private final ObjectWriter writer;
    private final ArtifactExchange exchange;
    private final Consumer<JobObject> onJob;
    private final Runnable onArtifact;
    private final Consumer<PeerLink> onClose;
    private final Lane intake;
    private final Lane answering;
    private final EventLog log;

    private final BlockingQueue<EngineObject> outbox = new LinkedBlockingQueue<>();
    private final Set<Long> functionsSent = new HashSet<>();
    private final AtomicBoolean open = new AtomicBoolean(true);

    private Thread writing;

    PeerLink(Socket socket, String name, ArtifactExchange exchange, Consumer<JobObject> onJob, Runnable onArtifact, Consumer<PeerLink> onClose, Lane intake, Lane answering, EventLog log) throws IOException {
        socket.setTcpNoDelay(true);

        this.socket = socket;
        this.name = name;
        this.reader = new StreamObjectReader(socket.getInputStream());
        this.writer = new StreamObjectWriter(socket.getOutputStream());
        this.exchange = exchange;
        this.onJob = onJob;
        this.onArtifact = onArtifact;
        this.onClose = onClose;
        this.intake = intake;
        this.answering = answering;
        this.log = log;
    }

    void start() {
        Thread reading = new Thread(this::readLoop, "link " + name + " in");
        reading.setDaemon(true);
        reading.start();

        writing = new Thread(this::writeLoop, "link " + name + " out");
        writing.setDaemon(true);
        writing.start();
    }

    String name() { return name; }

    @Override
    public boolean isOpen() { return open.get(); }

    void send(EngineObject object) { outbox.add(object); }

    @Override
    public void push(EngineObject artifact) {
        send(artifact);
        log.event("pushed %s to %s", artifact, name);
    }

    synchronized void ship(FunctionObject function, DataObject data, JobObject job) {
        if (functionsSent.add(function.id()))
            outbox.add(function);

        outbox.add(data);
        outbox.add(job);
    }

    private void readLoop() {
        try {
            EngineObject object;

            while ((object = reader.read()) != null) {
                EngineObject arrived = object;

                if (arrived instanceof RequestObject request) {
                    answering.put(() -> answer(request));

                } else if (arrived instanceof FunctionObject || arrived instanceof DataObject) {
                    intake.put(() -> {
                        exchange.receive(arrived);
                        log.event("received %s from %s", arrived, name);
                        onArtifact.run();
                    });

                } else if (arrived instanceof JobObject job) {
                    intake.put(() -> {
                        log.event("received job %s from %s", job.jobId(), name);
                        onJob.accept(job);
                    });
                }
            }
        } catch (InterruptedException stopping) {
        } catch (IOException | RuntimeException failed) {
            log.event("link %s: %s", name, failed.getMessage());
        } finally {
            close();
        }
    }

    private void answer(RequestObject request) throws IOException {
        EngineObject reply = exchange.answer(request, this);

        if (reply != null && isOpen()) send(reply);

        if (request.jobId() == 0) return;

        if (request.status() == Wire.REQUEST_STATUS_WAITING)
            log.event("%s will push %016x once it holds it", name, request.targetId());
        else if (request.status() == Wire.REQUEST_STATUS_NOT_FOUND)
            log.event("%s does not hold %016x yet", name, request.targetId());
        else if (reply instanceof RequestObject promise && promise.status() == Wire.REQUEST_STATUS_WAITING)
            log.event("promised %s %016x once held", name, request.targetId());
        else if (reply != null)
            log.event("answered %s: %s", name, reply);
    }

    private void writeLoop() {
        try {
            while (true) {
                writer.write(outbox.take());
                if (outbox.isEmpty()) writer.flush();
            }
        } catch (InterruptedException closing) {
        } catch (IOException | RuntimeException failed) {
            log.event("link %s: %s", name, failed.getMessage());
        } finally {
            close();
        }
    }

    @Override
    public void close() {
        if (!open.compareAndSet(true, false)) return;

        try {
            socket.close();
        } catch (IOException ignored) {
        }

        if (writing != null) writing.interrupt();

        onClose.accept(this);
    }
}

package dev.pms.engine.adapter.in;

import dev.pms.engine.adapter.out.etcd.EtcdClusterDirectory;
import dev.pms.engine.adapter.out.log.EventLog;
import dev.pms.engine.adapter.out.metrics.SystemLoadSampler;
import dev.pms.engine.adapter.out.stream.StreamObjectWriter;
import dev.pms.engine.adapter.peer.PeerNetwork;
import dev.pms.engine.domain.JobObject;
import dev.pms.engine.domain.NodeLoad;
import dev.pms.engine.port.ArtifactCatalog;
import dev.pms.engine.port.ClusterDirectory;
import dev.pms.engine.port.LoadSampler;
import dev.pms.engine.port.ObjectWriter;
import dev.pms.engine.service.ArtifactExchange;
import dev.pms.engine.service.JobResolver;
import dev.pms.engine.service.JobSubmitter;
import dev.pms.engine.service.OpenRequests;
import dev.pms.engine.service.PeerChooser;
import dev.pms.engine.service.Presence;
import dev.pms.engine.service.Resolution;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class HeadRuntime implements AutoCloseable {

    private static final int WORKER_CONNECT_ATTEMPTS = 30;
    private static final long NODES_FRESH_MILLIS = 1000;

    private final String nodeId;
    private final boolean spread;
    private final EventLog log;
    private final LoadSampler sampler = new SystemLoadSampler();
    private final ClusterDirectory cluster;
    private final Presence presence;
    private final ObjectWriter toWorker;
    private final JobSubmitter worker;
    private final PeerNetwork network;
    private final JobResolver resolver;
    private final ArtifactExchange exchange;
    private final PeerChooser chooser = new PeerChooser();

    private long turn;
    private Map<String, NodeLoad> nodes = Map.of();
    private long nodesRead;

    private ScheduledExecutorService timer;

    public HeadRuntime(String nodeId, ArtifactCatalog catalog, String workerSocket, String etcdEndpoints, String advertise, int maxSlots, String peerAddress, boolean spread, EventLog log) throws IOException {
        this.nodeId = nodeId;
        this.spread = spread;
        this.log = log;

        this.cluster = joinCluster(etcdEndpoints, nodeId, advertise, maxSlots);
        this.presence = cluster == null ? null : new Presence(nodeId, advertise, maxSlots, cluster, catalog, sampler);

        this.toWorker = workerSocket == null ? null : connectToWorker(workerSocket);
        this.worker = toWorker == null ? null : new JobSubmitter(toWorker);

        this.network = new PeerNetwork(nodeId, peerAddress, cluster, log);
        OpenRequests requests = new OpenRequests(network);
        this.resolver = new JobResolver(catalog, requests);
        this.exchange = new ArtifactExchange(catalog, requests);
        network.attach(exchange, this::onJob, this::onArtifact);

        if (workerSocket != null) log.event("resolved jobs go to the worker at %s", workerSocket);
        if (spread) log.event("spreading: ready jobs take turns between the nodes in etcd");
    }

    public JobResolver resolver() { return resolver; }

    public ArtifactExchange exchange() { return exchange; }

    public ClusterDirectory cluster() { return cluster; }

    public LoadSampler sampler() { return sampler; }

    public void start() {
        timer = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "tick");
            thread.setDaemon(true);
            return thread;
        });

        timer.scheduleWithFixedDelay(this::tick, 0, 1, TimeUnit.SECONDS);
    }

    public void listen(int port) throws IOException { network.listen(port); }

    public void ship(String address, Resolution resolution, boolean jobOnly) throws IOException {
        network.ship(address, new Resolution(resolution.job().asShipped(), resolution.function(), resolution.data(), false, false), jobOnly);
    }

    public void place(Resolution resolution) throws IOException {
        JobObject job = resolution.job();
        Optional<NodeLoad> target = spread && cluster != null && !job.shipped() ? nextTurn() : Optional.empty();

        if (target.isPresent()) {
            try {
                ship(target.get().address(), resolution, false);
                log.event("job %s shipped to %s", job.jobId(), target.get().nodeId());
                return;
            } catch (IOException unreachable) {
                log.event("cannot ship job %s to %s, running it here: %s", job.jobId(), target.get().nodeId(), unreachable.getMessage());
            }
        }

        runHere(resolution);
    }

    private synchronized Optional<NodeLoad> nextTurn() {
        long now = System.currentTimeMillis();

        if (now - nodesRead >= NODES_FRESH_MILLIS) {
            try {
                nodes = cluster.nodes();
            } catch (Exception lookup) {
                log.event("cluster: %s", lookup.getMessage());
            }
            nodesRead = now;
        }

        return chooser.spread(nodeId, nodes, turn++);
    }

    public void runHere(Resolution resolution) throws IOException {
        JobObject job = resolution.job();

        if (worker == null) {
            log.event("job %s resolved (no worker attached)", job.jobId());
            return;
        }

        try {
            worker.submit(resolution.function(), resolution.data(), job);
            worker.flush();
        } catch (IOException lost) {
            log.event("lost the worker: %s -- exiting", lost.getMessage());
            System.exit(3);
        }

        resolver.ranHere(job);
        log.event("job %s resolved, running here%s", job.jobId(), job.shipped() ? " (shipped here)" : "");
    }

    private void tick() {
        try {
            if (presence != null) {
                int changed = presence.publish();
                if (changed > 0) log.event("published %d dataset change(s)", changed);
            }
        } catch (Exception failed) {
            log.event("presence: %s", failed.getMessage());
        }

        try {
            runReady(resolver.sweep());
            exchange.deliverHeld();
        } catch (Exception failed) {
            log.event("sweep: %s", failed.getMessage());
        }
    }

    private void runReady(List<Resolution> ready) throws IOException {
        for (Resolution resolution : ready)
            place(resolution);
    }

    private void onJob(JobObject job) {
        try {
            Resolution resolution = resolver.resolve(job);

            if (resolution.complete()) place(resolution);
            else log.event("job %s waiting:%s%s", job.jobId(), resolution.needsFunction() ? String.format(" function %016x", job.functionId()) : "", resolution.needsData() ? String.format(" data %016x", job.inputDataId()) : "");

        } catch (IOException failed) {
            log.event("job %s: %s", job.jobId(), failed.getMessage());
        }
    }

    private void onArtifact() {
        try {
            runReady(resolver.recheck());
        } catch (IOException failed) {
            log.event("sweep: %s", failed.getMessage());
        }
    }

    private ObjectWriter connectToWorker(String socket) throws IOException {
        for (int attempt = 1; ; attempt++) {
            try {
                return StreamObjectWriter.connectUnix(socket);
            } catch (IOException notYet) {
                if (attempt >= WORKER_CONNECT_ATTEMPTS) throw notYet;
                log.event("worker at %s not ready yet (%s), retrying", socket, notYet.getMessage());
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                throw new IOException("interrupted waiting for the worker");
            }
        }
    }

    private ClusterDirectory joinCluster(String etcdEndpoints, String nodeId, String advertise, int maxSlots) {
        if (etcdEndpoints == null) {
            log.event("no --etcd: this node will not be discoverable");
            return null;
        }

        try {
            ClusterDirectory directory = new EtcdClusterDirectory(etcdEndpoints);
            log.event("cluster: %s as %s, advertising %s, %d slots", etcdEndpoints, nodeId, advertise, maxSlots);
            return directory;
        } catch (Exception unreachable) {
            log.event("cluster unavailable, running alone: %s", unreachable.getMessage());
            return null;
        }
    }

    @Override
    public void close() {
        if (timer != null) timer.shutdownNow();

        network.close();

        try {
            if (worker != null) worker.flush();
            if (toWorker != null) toWorker.close();
        } catch (IOException ignored) {
        }

        try {
            if (cluster != null) cluster.close();
        } catch (IOException ignored) {
        }
    }
}

# pipeIn

Builds everything the engine runs, and publishes it where the engine looks:

    functions/*.c  --build-->  out/functions/<id>.so     id = SHA-256 of the .so (first 8 bytes)
    workloads.py   --vectors-> out/loads/<load>/datasets/<id>.bin     id = SHA-256 of the dataset
                   --jobs----> out/loads/<load>/jobs.bin + manifest.json
                   --publish-> ../engineJava/jobs/jobs.bin     <- the head reads this by default

A **load** is a named set of vectors and jobs (`--load`, default `demo`); `./pipein.py
loads` prepares every one, `./pipein.py list` shows them.

Every wire offset is read from the engine's `worker/contract.h`, so this project cannot
drift from it. The engine is found at `$PIPEIN_ENGINE`, or next to this folder as
`../engineJava`.

## Run it

    ./pipein.py all            # build + vectors + jobs + publish   (build needs gcc)

    # in engineJava, once the node and head are built
    ./node &
    java -cp head/head.jar dev.pms.engine.adapter.in.JobFileCli --node engine.sock

    ./pipein.py verify         # compare engineJava/datasets/<jobId>.bin with Python's answers

No gcc on the host? Build inside the engine's toolchain image:

    docker run --rm -u "$(id -u):$(id -g)" -v "$PWD/..":/src -w /src/pipeIn enginejavabuild ./pipein.py all

Other steps: `build`, `vectors`, `jobs`, `publish` one at a time; `show FILE` decodes a job
file or a dataset. Tests (no compiler needed): `python3 -m unittest discover -s tests`.

## The functions

Each exports `engineJob`, the one entry point the worker looks up -- a function has no
other name than its id.

| source          | per value             | range  |
|-----------------|-----------------------|--------|
| `fib.c`         | fibonacci, fib(0) = 0 | 0..92  |
| `factorial.c`   | n!                    | 0..20  |
| `spin.c`        | n x 10^6 steps of a 64-bit LCG seeded with n; the final state | 0..200 |

`spin` is the CPU-bound one: its work grows with n, and Python checks it without the
loop, by jumping the generator ahead (squaring the affine map, O(log steps)).

All three read and write the dataset in `functions/dataset.h`:
`[magic][version][rows][cols][0]`, then per row `[rowId][cols x int64]`, rowId = the
hash of the row's values.

## The loads (`pipein/workloads.py`)

| load       | jobs | dependent | for |
|------------|-----:|----------:|-----|
| `smoke`    |    3 |         1 | is the deployment reachable, does fetching work |
| `demo`     |   10 |         5 | the three dependency shapes below |
| `crossing` |   24 |        16 | 8 chains fib -> fib -> factorial: almost every step crosses nodes |
| `bulk`     |   32 |         0 | 2048 x 16 values each, ~9 MB of inputs: transfer and throughput |
| `cpu`      |   20 |         4 | spin: seconds of work per job; fib -> spin chains |
| `swarm`    | 5000 |       500 | one row of 4 per job: the per-job cost of the system, for timing (`$PIPEIN_SWARM` sets the count) |
| `grind`    | 64 |        0 | `spin` only, ~1.8 s of one core each: keeps workers busy for autoscaling (`$PIPEIN_GRIND_JOBS`, `$PIPEIN_GRIND_BATCH`) |
| `smokes`   | 30000 |    10000 | `smoke` 10000 times, each copy on its own vectors: a run that lasts (`$PIPEIN_SMOKES` sets the copies) |

The `demo` load:

| job               | function  | input                                       |
|-------------------|-----------|---------------------------------------------|
| `fib`             | fib       | `fib_vectors`, 8 x 4 values in 0..92        |
| `factorial`       | factorial | `factorial_vectors`, 8 x 4 values in 0..20  |
| `chain_fib`       | fib       | `chain_vectors`, 4 x 4 values in 0..7       |
| `chain_factorial` | factorial | chain_fib's result -- DEPENDENT             |
| `deep_fib`        | fib       | `deep_vectors`, 4 x 4 values in 0..5        |
| `deep_fib_fib`    | fib       | deep_fib's result -- DEPENDENT              |
| `deep_factorial`  | factorial | deep_fib_fib's result -- DEPENDENT          |
| `fan_fib`         | fib       | `fan_vectors`, 4 x 4 values in 0..7         |
| `fan_factorial`   | factorial | fan_fib's result -- DEPENDENT               |
| `fan_fib_fib`     | fib       | fan_fib's result -- DEPENDENT               |

Three shapes of dependency: a **chain** of two, a **deep** chain of three (a dependent
job depending on a dependent job), and a **fan**-out (one result, two consumers). A
dependent job's input id is its producer's job id (a result is named by its job), no
DATA is sent for it, and the head holds it until that result exists. Each vector keeps
every step in the next function's range. The vectors are seeded, so the ids are the
same on every run with the same compiler.

`jobs.bin` carries FUNCTION, DATA and JOB objects back to back, so it is self-contained;
`manifest.json` lists each job's id, input and where its result will be.

## The big test, in one command

    ./run.sh                 # two fresh nodes here, the smokes load, collected, verified, analysed
    ./run.sh demo            # any load

`run.sh` rebuilds the engine, starts two nodes (`../engineJava/run.sh 9000` and `9100`),
runs `bench --alternate` against them, stops them, and leaves the run in
`out/bench/local-<time>/`: pipeIn's timings, both nodes' logs, and `analysis.txt` from
`./analyze.py` -- per node the jobs received, run and waited on, how long they waited,
the REQUESTs made and NOT_FOUNDs got back, the results fetched from the other node, and
the jobs run per second. `./analyze.py DIR` works on any directory of `*.head.log`.

## Talking to running nodes

A node's head listens on TCP and speaks the engine's protocol to anyone, so pipeIn can
push work to it and ask for results without touching its disk:

    ./pipein.py send 192.168.1.10:30100 192.168.1.11:30101    # jobs alternate between them
    ./pipein.py fetch 192.168.1.10:30100 192.168.1.11:30101   # REQUEST each result, verify

With two nodes, jobs alternate, so dependent chains cross between them: a head whose
job's producer ran on the other node asks the other head for the result. `fetch` asks
every node for every result by its job id (the head answers with the DATA, or
NOT_FOUND) until all are in `out/loads/<load>/results/` or `--wait` seconds pass, then verifies.
`../engineKubernetes` runs this against two machines.

## Timing a run

    ./pipein.py bench 192.168.1.10:9100 192.168.1.11:9100 --load swarm --label bare

`bench` first checks that the nodes are fresh (none holds a result yet), sends the whole
load to the first node -- its head, run with `--spread`, ships every other ready job to
the other node -- then keeps asking both nodes for every missing result (all the
REQUESTs of a round written at once) until all are in, and verifies them. Everything is
logged with wall-clock and elapsed times to `out/bench/<label>-<time>/`:

    bench.log       each event: send, every collection round, the summary
    results.csv     every job, the node it came from, when it was seen
    summary.json    send time, first / median / p95 / last result, jobs per second,
                    results per node, verified or not
    results/        the results themselves

`./pipein.py report` puts every run side by side. A result's time is when a collection
round saw it, so it is late by at most one round (a round is ~0.2 s plus the asking).

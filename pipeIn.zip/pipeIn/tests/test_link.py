import json
import os
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import unittest

PROJECT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT)

from pipein import link, objects, workloads     # noqa: E402
from pipein.contract import C                    # noqa: E402


class FakeHead:

    def __init__(self, results=None):
        self.results = dict(results or {})
        self.received = []
        self.on_job = None
        self.server = socket.create_server(("127.0.0.1", 0))
        self.address = "127.0.0.1:%d" % self.server.getsockname()[1]
        threading.Thread(target=self.serve, daemon=True).start()

    def serve(self):
        while True:
            try:
                connection, _ = self.server.accept()
            except OSError:
                return
            threading.Thread(target=self.talk, args=(connection,), daemon=True).start()

    def talk(self, connection):
        with connection:
            try:
                while True:
                    item = link.read_object(connection)
                    self.received.append(item)
                    if item["type"] == "JOB" and self.on_job:
                        self.on_job()
                    if item["type"] == "REQUEST":
                        connection.sendall(self.answer(item))
            except ConnectionError:
                return

    def answer(self, request):
        payload = self.results.get(request["target"])
        if payload is not None:
            return objects.data_object(payload, identity=request["target"])

        reply = bytearray(objects.request_object(request["targetType"], request["target"]))
        struct.pack_into("<H", reply, C["REQUEST_STATUS_OFFSET"], C["REQUEST_STATUS_NOT_FOUND"])
        return bytes(reply)

    def close(self):
        self.server.close()


def run(out, *arguments):
    return subprocess.run([sys.executable, os.path.join(PROJECT, "pipein.py"), *arguments, "--out", out],
                          capture_output=True, text=True, timeout=60)


class SendFetchTest(unittest.TestCase):

    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory()
        self.out = self.scratch.name

        os.makedirs(os.path.join(self.out, "functions"))
        built = {}
        for name in workloads.FUNCTIONS:
            code = ("stand-in for %s" % name).encode()
            identity = objects.hash_id(code)
            with open(os.path.join(self.out, "functions", "%016x.so" % identity), "wb") as handle:
                handle.write(code)
            built[name] = "%016x" % identity
        with open(os.path.join(self.out, "functions.json"), "w") as handle:
            json.dump(built, handle)

        for step in ("vectors", "jobs"):
            result = run(self.out, step)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

        with open(os.path.join(self.out, "loads", "demo", "manifest.json")) as handle:
            self.manifest = json.load(handle)["jobs"]

    def tearDown(self):
        self.scratch.cleanup()

    def test_send_alternates_jobs_and_carries_what_each_needs(self):
        heads = [FakeHead(), FakeHead()]
        result = run(self.out, "send", heads[0].address, heads[1].address)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

        import time
        deadline = time.time() + 5
        while sum(1 for head in heads for item in head.received if item["type"] == "JOB") < len(self.manifest) and time.time() < deadline:
            time.sleep(0.05)

        for index, head in enumerate(heads):
            got = [item for item in head.received if item["type"] == "JOB"]
            expected = [job for i, job in enumerate(self.manifest) if i % 2 == index]
            self.assertEqual(["%016x" % item["id"] for item in got], [job["job"] for job in expected])

            held = {item["id"] for item in head.received if item["type"] in ("FUNCTION", "DATA")}
            for item in got:
                self.assertIn(item["function"], held)
                if not item["dependent"]:
                    self.assertIn(item["input"], held)

        for head in heads:
            head.close()

    def test_fetch_finds_each_result_on_whichever_head_holds_it(self):
        expected = {int(job["job"], 16): workloads.expected_payload(job["name"]) for job in self.manifest}
        ids = sorted(expected)
        heads = [FakeHead({i: expected[i] for i in ids[::2]}), FakeHead({i: expected[i] for i in ids[1::2]})]

        result = run(self.out, "fetch", heads[0].address, heads[1].address, "--wait", "5")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(result.stdout.count(" ok, "), len(self.manifest), result.stdout)

        for head in heads:
            head.close()

    def test_fetch_gives_up_on_a_result_nobody_holds(self):
        head = FakeHead({})
        result = run(self.out, "fetch", head.address, "--wait", "1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("still missing", result.stdout + result.stderr)
        head.close()

    def test_bench_sends_to_the_first_collects_from_all_and_logs_the_run(self):
        expected = {int(job["job"], 16): workloads.expected_payload(job["name"]) for job in self.manifest}
        ids = sorted(expected)
        heads = [FakeHead(), FakeHead()]
        heads[0].on_job = lambda: heads[0].results.update({i: expected[i] for i in ids[::2]}) or heads[1].results.update({i: expected[i] for i in ids[1::2]})

        result = run(self.out, "bench", heads[0].address, heads[1].address, "--label", "test", "--wait", "5")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

        runs = os.listdir(os.path.join(self.out, "bench"))
        self.assertEqual(len(runs), 1)
        self.assertTrue(runs[0].startswith("test-"))
        with open(os.path.join(self.out, "bench", runs[0], "summary.json")) as handle:
            summary = json.load(handle)

        self.assertEqual((summary["jobs"], summary["collected"], summary["missing"], summary["verified"]), (len(self.manifest), len(self.manifest), 0, True))
        self.assertEqual(sum(summary["fromNode"].values()), len(self.manifest))
        self.assertEqual(sum(1 for item in heads[1].received if item["type"] == "JOB"), 0)

        again = run(self.out, "bench", heads[0].address, "--label", "again", "--wait", "5")
        self.assertNotEqual(again.returncode, 0)
        self.assertIn("not fresh", again.stdout + again.stderr)

        report = run(self.out, "report")
        self.assertEqual(report.returncode, 0, report.stdout + report.stderr)
        self.assertIn(runs[0], report.stdout)

        for head in heads:
            head.close()


class RequestTest(unittest.TestCase):

    def test_request_layout(self):
        blob = objects.request_object(C["OBJECT_TYPE_DATA"], 0x1122334455667788, 0x99)
        item = next(objects.read_objects(blob))
        self.assertEqual(len(blob), C["REQUEST_HEADER_LENGTH"])
        self.assertEqual((item["type"], item["target"], item["targetType"], item["status"]),
                         ("REQUEST", 0x1122334455667788, C["OBJECT_TYPE_DATA"], C["REQUEST_STATUS_PENDING"]))
        self.assertEqual(item["id"], objects.request_id(C["OBJECT_TYPE_DATA"], 0x1122334455667788, 0x99))


if __name__ == "__main__":
    unittest.main()

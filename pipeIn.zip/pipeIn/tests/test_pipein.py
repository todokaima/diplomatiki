import hashlib
import os
import random
import re
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pipein import dataset, objects, workloads            # noqa: E402
from pipein.contract import C, ENGINE, contract_path       # noqa: E402

OLD_JOB_FILE = os.path.join(ENGINE, ".bak", "run", "jobs.bin")


class ContractTest(unittest.TestCase):

    def test_constants_are_read_from_the_header(self):
        self.assertEqual(C["OBJECT_HEADER_LENGTH"], 24)
        self.assertEqual(C["JOB_HEADER_LENGTH"], 96)
        self.assertEqual(C["FUNCTION_CODE_OFFSET"], C["FUNCTION_HEADER_LENGTH"])
        self.assertEqual(C["DATA_MAX_PAYLOAD_LENGTH"], 256 << 20)
        self.assertEqual(C["JOB_FUNCTION_ENTRY"], "engineJob")
        self.assertEqual(C["JOB_FLAGS_OFFSET"], 92)


class IdentityTest(unittest.TestCase):

    def test_contract_sha256_is_sha256(self):
        with open(contract_path()) as header:
            digest = contract_sha256(header.read())
        samples = [b"", b"abc"] + [bytes(n) for n in (55, 56, 63, 64, 119, 120)]
        generator = random.Random(7)
        samples += [bytes(generator.randrange(256) for _ in range(generator.randint(0, 300))) for _ in range(100)]

        for sample in samples:
            self.assertEqual(digest(sample), hashlib.sha256(sample).digest(), len(sample))

    @unittest.skipUnless(os.path.exists(OLD_JOB_FILE), "no job file from an earlier engine run")
    def test_job_ids_match_the_engine(self):
        with open(OLD_JOB_FILE, "rb") as handle:
            jobs = [item for item in objects.read_objects(handle.read()) if item["type"] == "JOB"]

        self.assertTrue(jobs)
        for job in jobs:
            self.assertEqual(objects.job_id(job["function"], job["input"]), job["id"])
            self.assertEqual(job["output"], job["id"])


def contract_sha256(header):
    body = header[header.index("sha256RotateRight"):header.index("static inline uint64_t hashId")]
    rounds = [int(x, 16) for x in re.findall(r"0x([0-9a-f]{8})u", body.split("uint32_t w[64]")[0])]
    initial = [int(x, 16) for x in re.findall(r"0x([0-9a-f]{8})u", body.split("uint32_t state[8] =")[1].split("};")[0])]
    mask = 0xFFFFFFFF

    def rotate(value, bits):
        return ((value >> bits) | (value << (32 - bits))) & mask

    def block(state, chunk):
        w = [int.from_bytes(chunk[4 * i:4 * i + 4], "big") for i in range(16)]
        for i in range(16, 64):
            s0 = rotate(w[i - 15], 7) ^ rotate(w[i - 15], 18) ^ (w[i - 15] >> 3)
            s1 = rotate(w[i - 2], 17) ^ rotate(w[i - 2], 19) ^ (w[i - 2] >> 10)
            w.append((w[i - 16] + s0 + w[i - 7] + s1) & mask)
        a, b, c, d, e, f, g, h = state
        for i in range(64):
            t1 = (h + (rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25)) + ((e & f) ^ (~e & g)) + rounds[i] + w[i]) & mask
            t2 = ((rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) & mask
            h, g, f, e, d, c, b, a = g, f, e, (d + t1) & mask, c, b, a, (t1 + t2) & mask
        return [(x + y) & mask for x, y in zip(state, [a, b, c, d, e, f, g, h])]

    def digest(data):
        state, full = list(initial), len(data) - len(data) % 64
        for offset in range(0, full, 64):
            state = block(state, data[offset:offset + 64])
        remaining = len(data) - full
        tail = bytearray(128)
        tail[:remaining] = data[full:]
        tail[remaining] = 0x80
        length = 64 if remaining < 56 else 128
        for i in range(8):
            tail[length - 1 - i] = (len(data) * 8 >> (8 * i)) & 0xFF
        state = block(state, bytes(tail[:64]))
        if length == 128:
            state = block(state, bytes(tail[64:]))
        return b"".join(word.to_bytes(4, "big") for word in state)

    return digest


class DatasetTest(unittest.TestCase):

    def test_round_trip(self):
        rows = [[1, 2, 3], [-4, 5, 2 ** 62]]
        decoded = dataset.decode(dataset.encode(rows))
        self.assertEqual([values for _, values in decoded], rows)
        self.assertEqual([identity for identity, _ in decoded], [dataset.row_id(row) for row in rows])

    def test_header_layout(self):
        payload = dataset.encode([[5, 6]])
        self.assertEqual(struct.unpack_from("<IIQII", payload, 0), (dataset.MAGIC, C["ENGINE_VERSION"], 1, 2, 0))
        self.assertEqual(len(payload), 24 + 8 + 2 * 8)


class ObjectTest(unittest.TestCase):

    def test_objects_round_trip(self):
        code, payload = b"\x7fELF not really", dataset.encode([[3]])
        function_id, data_id = objects.hash_id(code), objects.hash_id(payload)

        blob = objects.function_object(code) + objects.data_object(payload) + objects.job_object(function_id, data_id, dependent=True)
        function, data, job = objects.read_objects(blob)

        self.assertEqual((function["type"], function["id"], function["code"]), ("FUNCTION", function_id, code))
        self.assertEqual((data["type"], data["id"], data["payload"]), ("DATA", data_id, payload))
        self.assertEqual((job["function"], job["input"], job["output"]), (function_id, data_id, job["id"]))
        self.assertTrue(job["dependent"])
        self.assertEqual(job["id"], objects.job_id(function_id, data_id))

    def test_lengths(self):
        self.assertEqual(len(objects.job_object(1, 2)), C["JOB_HEADER_LENGTH"])
        self.assertEqual(len(objects.data_object(b"abc")), C["DATA_HEADER_LENGTH"] + 3)
        self.assertEqual(len(objects.function_object(b"abcd")), C["FUNCTION_HEADER_LENGTH"] + 4)


class WorkloadTest(unittest.TestCase):

    def test_values_stay_in_range(self):
        for name, spec in workloads.VECTORS.items():
            for row in workloads.vector_rows(name):
                self.assertTrue(all(spec["low"] <= value <= spec["high"] for value in row), name)

    def test_expected_results_fit_int64(self):
        for job in workloads.JOBS:
            for row in workloads.expected_rows(job["name"]):
                self.assertTrue(all(value < 2 ** 63 for value in row), job["name"])

    def test_known_values(self):
        self.assertEqual([workloads.fib(n) for n in range(10)], [0, 1, 1, 2, 3, 5, 8, 13, 21, 34])
        self.assertEqual(workloads.fib(92), 7540113804746346429)
        self.assertEqual(workloads.FUNCTIONS["factorial"](20), 2432902008176640000)

    def test_every_input_is_in_its_functions_domain(self):
        for job in workloads.JOBS:
            domain = workloads.DOMAIN[job["function"]]
            for row in workloads.input_rows(job["name"]):
                self.assertTrue(all(value in domain for value in row), (job["name"], row))

    def test_a_job_comes_after_the_job_it_depends_on(self):
        seen = set()
        for job in workloads.JOBS:
            if "after" in job:
                self.assertIn(job["after"], seen, job["name"])
            seen.add(job["name"])

    def test_every_job_has_its_own_id(self):
        inputs = [(job["function"], job.get("input") or job["after"]) for job in workloads.JOBS]
        self.assertEqual(len(inputs), len(set(inputs)))

    def test_deep_chain_is_three_steps(self):
        fib, factorial = workloads.fib, workloads.FUNCTIONS["factorial"]
        start = workloads.vector_rows("deep_vectors")
        self.assertEqual(workloads.expected_rows("deep_factorial"), [[factorial(fib(fib(v))) for v in row] for row in start])

    def test_fan_out_shares_one_producer(self):
        produced = workloads.expected_rows("fan_fib")
        self.assertEqual(workloads.input_rows("fan_factorial"), produced)
        self.assertEqual(workloads.input_rows("fan_fib_fib"), produced)

    def test_chain_is_factorial_of_fibonacci(self):
        fibonacci = workloads.expected_rows("chain_fib")
        chained = workloads.expected_rows("chain_factorial")
        self.assertEqual(chained, [[workloads.FUNCTIONS["factorial"](v) for v in row] for row in fibonacci])


class EveryLoadTest(unittest.TestCase):

    def tearDown(self):
        workloads.select(workloads.DEFAULT_LOAD)

    def test_every_load(self):
        for load in workloads.LOADS:
            with self.subTest(load=load):
                workloads.select(load)
                seen, jobs = set(), set()
                for job in workloads.JOBS:
                    domain = workloads.DOMAIN[job["function"]]
                    for row in workloads.input_rows(job["name"]):
                        self.assertTrue(all(value in domain for value in row), (job["name"], row))

                    if "after" in job:
                        self.assertIn(job["after"], seen, job["name"])
                        source = ("after", job["after"])
                    else:
                        source = ("rows", repr(workloads.vector_rows(job["input"])))
                    seen.add(job["name"])

                    self.assertNotIn((job["function"], source), jobs, job["name"])
                    jobs.add((job["function"], source))

    def test_swarm_is_big_and_small(self):
        workloads.select("swarm")
        self.assertEqual(len(workloads.JOBS), 5000)
        self.assertTrue(all(len(workloads.input_rows(job["name"])) == 1 for job in workloads.JOBS))

    def test_grind_batches_never_share_a_job(self):
        import os
        seen = set()
        for batch in (0, 1, 9999):
            os.environ["PIPEIN_GRIND_BATCH"] = str(batch)
            workloads.select("grind")
            rows = [tuple(workloads.vector_rows(job["input"])[0]) for job in workloads.JOBS]
            self.assertEqual(len(rows), 64)
            self.assertTrue(all(job["function"] == "spin" and "after" not in job for job in workloads.JOBS))
            self.assertTrue(all(len(row) <= 16 and max(row) <= 200 for row in rows))
            self.assertFalse(seen & set(rows))
            seen |= set(rows)
        del os.environ["PIPEIN_GRIND_BATCH"]

    def test_smokes_is_smoke_many_times_and_every_dependency_crosses(self):
        workloads.select("smokes")
        self.assertEqual(len(workloads.JOBS), 30000)
        index = {job["name"]: i for i, job in enumerate(workloads.JOBS)}
        dependents = [job for job in workloads.JOBS if "after" in job]
        self.assertEqual(len(dependents), 10000)
        self.assertTrue(all(index[job["name"]] % 2 != index[job["after"]] % 2 for job in dependents))


class SpinTest(unittest.TestCase):

    def test_jump_ahead_is_the_loop(self):
        for x, steps in [(0, 0), (1, 1), (7, 1000), (123456789, 4097), (2 ** 64 - 1, 333)]:
            direct = x
            for _ in range(steps):
                direct = (direct * workloads.SPIN_MUL + workloads.SPIN_ADD) & workloads.MASK
            self.assertEqual(workloads.lcg_steps(x, steps), direct)

    def test_spin_is_signed(self):
        self.assertTrue(all(-2 ** 63 <= workloads.spin(n) < 2 ** 63 for n in range(0, 201, 50)))


if __name__ == "__main__":
    unittest.main()

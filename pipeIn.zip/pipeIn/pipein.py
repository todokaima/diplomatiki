#!/usr/bin/env python3
"""usage: ./pipein.py STEP [--load NAME]

  build | vectors | jobs | publish | all | loads | list
  send | fetch | bench | report   HOST:PORT ...
  show FILE | verify
"""
import argparse
import datetime
import json
import os
import shutil
import sys
import time

from pipein import dataset, functions, link, objects, workloads
from pipein.contract import C, ENGINE, PROJECT


def build(arguments):
    built = {}
    for name, source in functions.sources().items():
        identity, path = functions.build(name, source, os.path.join(arguments.out, "functions"), arguments.engine, arguments.cc)
        built[name] = "%016x" % identity
        print("  function %-10s %016x  %s" % (name, identity, os.path.relpath(path)))

    save(arguments.out, "functions.json", built)


def vectors(arguments):
    written = {}
    directory = os.path.join(load_directory(arguments), "datasets")
    os.makedirs(directory, exist_ok=True)

    for name in workloads.VECTORS:
        payload = dataset.encode(workloads.vector_rows(name))
        identity = objects.hash_id(payload)

        with open(os.path.join(directory, "%016x.bin" % identity), "wb") as out:
            out.write(payload)

        written[name] = "%016x" % identity

    save(load_directory(arguments), "vectors.json", written)
    print("  %s: %d vectors, %d B" % (arguments.load, len(written), sum(os.path.getsize(os.path.join(directory, "%s.bin" % i)) for i in written.values())))


def plan(arguments):
    built = load(arguments.out, "functions.json", "run ./pipein.py build first")
    vectors_written = load(load_directory(arguments), "vectors.json", "run ./pipein.py vectors --load %s first" % arguments.load)

    planned, job_ids = [], {}

    for job in workloads.JOBS:
        if job["function"] not in built:
            raise SystemExit("function %s is not built: run ./pipein.py build" % job["function"])

        function_id = int(built[job["function"]], 16)
        dependent = "after" in job
        needs = []

        with open(os.path.join(arguments.out, "functions", "%016x.so" % function_id), "rb") as code:
            needs.append((function_id, objects.function_object(code.read())))

        if dependent:
            input_id = job_ids[job["after"]]
        else:
            input_id = int(vectors_written[job["input"]], 16)
            with open(os.path.join(load_directory(arguments), "datasets", "%016x.bin" % input_id), "rb") as payload:
                needs.append((input_id, objects.data_object(payload.read())))

        identity = objects.job_id(function_id, input_id)
        job_ids[job["name"]] = identity
        needs.append((identity, objects.job_object(function_id, input_id, dependent)))

        planned.append({"spec": job, "id": identity, "function": function_id, "input": input_id,
                        "dependent": dependent, "objects": needs})

    return planned


def stream(jobs):
    sent, parts = set(), []
    for job in jobs:
        for identity, blob in job["objects"]:
            if identity not in sent:
                parts.append(blob)
                sent.add(identity)
    return b"".join(parts)


def jobs(arguments):
    planned = plan(arguments)
    manifest = []

    for job in planned:
        spec = job["spec"]
        manifest.append({"name": spec["name"], "job": "%016x" % job["id"],
                         "function": spec["function"], "functionId": "%016x" % job["function"],
                         "input": "%016x" % job["input"], "dependent": job["dependent"],
                         "result": "datasets/%016x.bin" % job["id"]})

    blob = stream(planned)
    with open(os.path.join(load_directory(arguments), "jobs.bin"), "wb") as out:
        out.write(blob)

    save(load_directory(arguments), "manifest.json", {"load": arguments.load, "jobs": manifest})
    print("  %s: %d jobs (%d dependent), jobs.bin %d B" % (arguments.load, len(manifest),
                                                          sum(job["dependent"] for job in manifest), len(blob)))


def publish(arguments):
    target = os.path.join(arguments.engine, "jobs")
    os.makedirs(target, exist_ok=True)

    for name in ("jobs.bin", "manifest.json"):
        source = os.path.join(load_directory(arguments), name)
        if not os.path.exists(source):
            raise SystemExit("%s missing: run ./pipein.py jobs --load %s first" % (source, arguments.load))
        shutil.copyfile(source, os.path.join(target, name))

    print("  published %s to %s -- the head reads jobs/jobs.bin when started without a path" % (arguments.load, os.path.relpath(target)))


def loads(arguments):
    for name in workloads.LOADS:
        arguments.load = name
        workloads.select(name)
        vectors(arguments)
        jobs(arguments)


def list_loads(arguments):
    for name, make in workloads.LOADS.items():
        _, jobs_of_load = make()
        prepared = os.path.exists(os.path.join(arguments.out, "loads", name, "manifest.json"))
        print("  %-9s %5d jobs (%3d dependent)  %s" % (name, len(jobs_of_load), sum("after" in job for job in jobs_of_load),
                                                      "prepared" if prepared else "not prepared"))


def send(arguments):
    targets = need_targets(arguments)
    planned = plan(arguments)

    placement = {target: [] for target in targets}
    for index, job in enumerate(planned):
        placement[targets[index % len(targets)]].append(job)

    for target, assigned in placement.items():
        if not assigned:
            continue

        blob = stream(assigned)
        with link.connect(target) as connection:
            connection.sendall(blob)

        print("  %-22s %3d jobs (%d dependent), %d B" % (target, len(assigned), sum(job["dependent"] for job in assigned), len(blob)))

    save(load_directory(arguments), "placement.json",
         {job["spec"]["name"]: target for target, assigned in placement.items() for job in assigned})


def fetch(arguments):
    targets = need_targets(arguments)
    manifest = load(load_directory(arguments), "manifest.json", "run ./pipein.py jobs --load %s first" % arguments.load)
    directory = os.path.join(load_directory(arguments), "results")
    os.makedirs(directory, exist_ok=True)

    wanted = {int(job["job"], 16): job["name"] for job in manifest["jobs"]}
    connections = {target: link.connect(target) for target in targets}
    started = time.time()
    deadline = started + arguments.wait

    try:
        while wanted:
            for identity in list(wanted):
                for target, connection in connections.items():
                    payload = link.fetch_data(connection, identity)
                    if payload is None:
                        continue

                    with open(os.path.join(directory, "%016x.bin" % identity), "wb") as out:
                        out.write(payload)

                    print("  %-24s %016x  from %s after %.1fs" % (wanted.pop(identity), identity, target, time.time() - started))
                    break

            if wanted:
                if time.time() > deadline:
                    raise SystemExit("still missing after %ds: %s" % (arguments.wait, ", ".join(sorted(wanted.values()))))
                time.sleep(1)
    finally:
        for connection in connections.values():
            connection.close()

    arguments.datasets = directory
    print("== verify")
    verify(arguments)


class BenchLog:

    def __init__(self, directory):
        self.started = time.time()
        self.file = open(os.path.join(directory, "bench.log"), "w")

    def elapsed(self):
        return time.time() - self.started

    def event(self, message, *values):
        line = "%s %9.3f  %s" % (datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3], self.elapsed(), message % values)
        print("  " + line)
        self.file.write(line + "\n")
        self.file.flush()


def collect_round(connections, wanted):
    found = {}
    for target, connection in connections.items():
        missing = [identity for identity in wanted if identity not in found]
        if not missing:
            break

        connection.sendall(b"".join(objects.request_object(C["OBJECT_TYPE_DATA"], identity) for identity in missing))

        for _ in missing:
            reply = link.read_object(connection)
            if reply["type"] == "DATA" and reply["id"] in wanted:
                found.setdefault(reply["id"], (target, reply["payload"]))
    return found


def bench(arguments):
    targets = need_targets(arguments)
    label = arguments.label or "run"
    directory = os.path.join(arguments.out, "bench", "%s-%s" % (label, datetime.datetime.now().strftime("%Y%m%d-%H%M%S")))
    results = os.path.join(directory, "results")
    os.makedirs(results, exist_ok=True)

    planned = plan(arguments)
    names = {job["id"]: job["spec"]["name"] for job in planned}
    log = BenchLog(directory)
    log.event("bench %s: load %s, %d jobs (%d dependent), nodes %s", label, arguments.load, len(planned), sum(job["dependent"] for job in planned), " ".join(targets))

    probes = {target: link.connect(target) for target in targets}
    try:
        stale = collect_round(probes, set(names))
    finally:
        for connection in probes.values():
            connection.close()
    if stale:
        log.event("stale: the nodes already hold %d of the results -- restart them for a clean run", len(stale))
        raise SystemExit("bench %s: the nodes are not fresh" % label)

    placement = {target: [] for target in (targets if arguments.alternate else targets[:1])}
    senders = list(placement)
    for index, job in enumerate(planned):
        placement[senders[index % len(senders)]].append(job)

    log.started = time.time()
    log.event("send: start")
    for target, assigned in placement.items():
        blob = stream(assigned)
        with link.connect(target) as connection:
            connection.sendall(blob)
        log.event("send: %d jobs, %d B to %s", len(assigned), len(blob), target)
    sent_after = log.elapsed()

    wanted = set(names)
    arrivals, rounds = [], 0
    connections = {target: link.connect(target) for target in targets}
    deadline = log.started + arguments.wait
    try:
        while wanted:
            rounds += 1
            found = collect_round(connections, wanted)
            now = log.elapsed()

            for identity, (target, payload) in found.items():
                with open(os.path.join(results, "%016x.bin" % identity), "wb") as out:
                    out.write(payload)
                arrivals.append((names[identity], identity, target, now))
                wanted.discard(identity)

            if found:
                log.event("collect: round %d, %d result(s), %d of %d in, %d missing", rounds, len(found), len(names) - len(wanted), len(names), len(wanted))
            if wanted:
                if time.time() > deadline:
                    log.event("collect: gave up after %ds, %d missing", arguments.wait, len(wanted))
                    break
                time.sleep(0.2)
    finally:
        for connection in connections.values():
            connection.close()

    total = log.elapsed()
    log.event("done: %d of %d results in %.3f s", len(arrivals), len(names), total)

    arguments.datasets = results
    try:
        verify(arguments)
        verified = True
    except SystemExit as failed:
        log.event("verify: %s", failed)
        verified = False

    with open(os.path.join(directory, "results.csv"), "w") as out:
        out.write("name,job,from,seconds\n")
        for name, identity, target, seconds in sorted(arrivals, key=lambda arrival: arrival[3]):
            out.write("%s,%016x,%s,%.3f\n" % (name, identity, target, seconds))

    times = sorted(arrival[3] for arrival in arrivals)
    summary = {
        "label": label, "load": arguments.load, "nodes": targets, "sentTo": senders,
        "jobs": len(names), "dependent": sum(job["dependent"] for job in planned),
        "bytesSent": sum(len(stream(assigned)) for assigned in placement.values()),
        "sendSeconds": round(sent_after, 3),
        "firstResultSeconds": round(times[0], 3) if times else None,
        "medianResultSeconds": round(times[len(times) // 2], 3) if times else None,
        "p95ResultSeconds": round(times[int(len(times) * 0.95) - 1], 3) if times else None,
        "totalSeconds": round(total, 3),
        "jobsPerSecond": round(len(arrivals) / total, 1) if total else None,
        "collected": len(arrivals), "missing": len(wanted), "rounds": rounds,
        "fromNode": {target: sum(arrival[2] == target for arrival in arrivals) for target in targets},
        "verified": verified,
        "started": datetime.datetime.fromtimestamp(log.started).isoformat(timespec="seconds"),
    }
    save(directory, "summary.json", summary)
    log.event("summary: %s", json.dumps(summary))
    print("  -> %s" % os.path.relpath(directory))

    if not verified or wanted:
        raise SystemExit("bench %s: not every result came back right" % label)


def report(arguments):
    benches = os.path.join(arguments.out, "bench")
    if not arguments.args and not os.path.isdir(benches):
        raise SystemExit("no runs in %s yet: ./pipein.py bench first" % benches)
    runs = arguments.args or sorted(os.path.join(benches, name) for name in os.listdir(benches))
    rows = []
    for directory in runs:
        path = os.path.join(directory, "summary.json")
        if os.path.exists(path):
            with open(path) as handle:
                rows.append((os.path.basename(directory.rstrip("/")), json.load(handle)))

    print("  %-28s %-6s %6s %8s %8s %8s %8s %9s  %s" % ("run", "load", "jobs", "send s", "first s", "p50 s", "total s", "jobs/s", "results from"))
    for name, run in rows:
        print("  %-28s %-6s %6d %8.2f %8s %8s %8.2f %9s  %s" % (name, run["load"], run["jobs"], run["sendSeconds"], run["firstResultSeconds"], run["medianResultSeconds"],
                                                                 run["totalSeconds"], run["jobsPerSecond"], " ".join("%s=%d" % item for item in run["fromNode"].items())))


def show(arguments):
    with open(arguments.args[0], "rb") as handle:
        blob = handle.read()

    if dataset.is_dataset(blob):
        for identity, values in dataset.decode(blob):
            print("  row %016x %s" % (identity, values))
        return

    for item in objects.read_objects(blob):
        line = "  %-8s %016x  %d B" % (item["type"], item["id"], item["length"])
        if item["type"] == "JOB":
            line += "  function %016x  input %016x%s" % (item["function"], item["input"], "  DEPENDENT" if item["dependent"] else "")
        print(line)


def verify(arguments):
    manifest = load(load_directory(arguments), "manifest.json", "run ./pipein.py jobs --load %s first" % arguments.load)
    directory = arguments.datasets or os.path.join(arguments.engine, "datasets")
    failures = 0
    quiet = len(manifest["jobs"]) > 50

    for job in manifest["jobs"]:
        path = os.path.join(directory, "%s.bin" % job["job"])
        expected = workloads.expected_payload(job["name"])

        if not os.path.exists(path):
            print("  %-24s %s  missing (%s)" % (job["name"], job["job"], path))
            failures += 1
            continue

        with open(path, "rb") as result:
            actual = result.read()

        if actual == expected:
            if not quiet:
                print("  %-24s %s  ok, %d rows" % (job["name"], job["job"], len(dataset.decode(actual))))
        else:
            print("  %-24s %s  WRONG" % (job["name"], job["job"]))
            print("      expected %s" % [values for _, values in dataset.decode(expected)][:4])
            print("      got      %s" % ([values for _, values in dataset.decode(actual)][:4] if dataset.is_dataset(actual) else "%d unreadable bytes" % len(actual)))
            failures += 1

    if failures:
        raise SystemExit("%d of %d jobs not as expected" % (failures, len(manifest["jobs"])))
    print("  %s: all %d jobs ok" % (manifest.get("load", arguments.load), len(manifest["jobs"])))


def load_directory(arguments):
    return os.path.join(arguments.out, "loads", arguments.load)


def need_targets(arguments):
    if not arguments.args:
        raise SystemExit("give at least one node as HOST:PORT")
    return arguments.args


def save(directory, name, content):
    os.makedirs(directory, exist_ok=True)
    with open(os.path.join(directory, name), "w") as out:
        json.dump(content, out, indent=2)


def load(directory, name, hint):
    path = os.path.join(directory, name)
    if not os.path.exists(path):
        raise SystemExit("%s missing: %s" % (path, hint))
    with open(path) as handle:
        return json.load(handle)


def main():
    parser = argparse.ArgumentParser(description="build the engine's job functions, vectors and job files, and talk to running nodes")
    parser.add_argument("step", choices=["build", "vectors", "jobs", "publish", "all", "loads", "list", "send", "fetch", "bench", "report", "show", "verify"])
    parser.add_argument("args", nargs="*", help="show: a FILE; send and fetch: nodes as HOST:PORT")
    parser.add_argument("--load", default=workloads.DEFAULT_LOAD, choices=list(workloads.LOADS))
    parser.add_argument("--engine", default=ENGINE)
    parser.add_argument("--out", default=os.path.join(PROJECT, "out"))
    parser.add_argument("--cc", default="gcc")
    parser.add_argument("--wait", type=int, default=120)
    parser.add_argument("--datasets", help="for verify: where the results are (default: <engine>/datasets)")
    parser.add_argument("--label", help="bench: what this run is, e.g. bare or k8s")
    parser.add_argument("--alternate", action="store_true", help="bench: send alternately to every node given")
    arguments = parser.parse_args()

    workloads.select(arguments.load)

    if arguments.step == "show":
        if not arguments.args:
            parser.error("show needs a FILE")
        return show(arguments)

    steps = {"build": [build], "vectors": [vectors], "jobs": [jobs], "publish": [publish],
             "all": [build, vectors, jobs, publish], "loads": [loads], "list": [list_loads],
             "send": [send], "fetch": [fetch], "bench": [bench], "report": [report], "verify": [verify]}

    for step in steps[arguments.step]:
        print("== %s" % step.__name__)
        step(arguments)


if __name__ == "__main__":
    sys.exit(main())

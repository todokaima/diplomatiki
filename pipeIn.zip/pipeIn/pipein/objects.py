import hashlib
import struct

from .contract import C

TYPE_NAMES = {C["OBJECT_TYPE_DATA"]: "DATA", C["OBJECT_TYPE_FUNCTION"]: "FUNCTION",
              C["OBJECT_TYPE_JOB"]: "JOB", C["OBJECT_TYPE_REQUEST"]: "REQUEST"}

WHOLE = 1


def hash_id(data):
    return int.from_bytes(hashlib.sha256(data).digest()[:8], "big")


def u64(value):
    return struct.pack("<Q", value)


def job_id(function_id, input_id):
    return hash_id(u64(input_id) + u64(function_id))


def _envelope(buffer, type_code, magic, object_id):
    struct.pack_into("<IHHQQ", buffer, 0, magic, C["ENGINE_VERSION"], type_code, object_id, len(buffer))


def data_object(payload, flags=0, identity=None):
    buffer = bytearray(C["DATA_HEADER_LENGTH"] + len(payload))
    _envelope(buffer, C["OBJECT_TYPE_DATA"], C["DATA_MAGIC"], hash_id(payload) if identity is None else identity)

    struct.pack_into("<Q", buffer, C["DATA_PAYLOAD_LENGTH_OFFSET"], len(payload))
    struct.pack_into("<I", buffer, C["DATA_FLAGS_OFFSET"], flags)
    struct.pack_into("<I", buffer, C["DATA_PART_COUNT_OFFSET"], WHOLE)
    struct.pack_into("<Q", buffer, C["DATA_PART_LENGTH_OFFSET"], len(payload))

    buffer[C["DATA_PAYLOAD_OFFSET"]:] = payload
    return bytes(buffer)


def function_object(code):
    buffer = bytearray(C["FUNCTION_HEADER_LENGTH"] + len(code))
    _envelope(buffer, C["OBJECT_TYPE_FUNCTION"], C["FUNCTION_MAGIC"], hash_id(code))

    struct.pack_into("<Q", buffer, C["FUNCTION_CODE_LENGTH_OFFSET"], len(code))
    struct.pack_into("<I", buffer, C["FUNCTION_ABI_VERSION_OFFSET"], C["ENGINE_ABI_VERSION"])

    buffer[C["FUNCTION_CODE_OFFSET"]:] = code
    return bytes(buffer)


def job_object(function_id, input_id, dependent=False):
    identity = job_id(function_id, input_id)

    buffer = bytearray(C["JOB_HEADER_LENGTH"])
    _envelope(buffer, C["OBJECT_TYPE_JOB"], C["JOB_MAGIC"], identity)

    struct.pack_into("<Q", buffer, C["JOB_FUNCTION_ID_OFFSET"], function_id)
    struct.pack_into("<Q", buffer, C["JOB_INPUT_DATA_ID_OFFSET"], input_id)
    struct.pack_into("<Q", buffer, C["JOB_OUTPUT_DATA_ID_OFFSET"], identity)
    struct.pack_into("<I", buffer, C["JOB_STATE_OFFSET"], C["JOB_STATE_CREATED"])
    struct.pack_into("<I", buffer, C["JOB_PART_COUNT_OFFSET"], WHOLE)
    struct.pack_into("<I", buffer, C["JOB_FLAGS_OFFSET"], C["JOB_FLAG_DEPENDENT"] if dependent else 0)

    return bytes(buffer)


def request_id(target_type, target_id, job_id):
    return hash_id(struct.pack("<H", target_type) + u64(target_id) + u64(job_id))


def request_object(target_type, target_id, job_id=0):
    buffer = bytearray(C["REQUEST_HEADER_LENGTH"])
    _envelope(buffer, C["OBJECT_TYPE_REQUEST"], C["REQUEST_MAGIC"], request_id(target_type, target_id, job_id))

    struct.pack_into("<Q", buffer, C["REQUEST_TARGET_ID_OFFSET"], target_id)
    struct.pack_into("<H", buffer, C["REQUEST_TARGET_TYPE_OFFSET"], target_type)
    struct.pack_into("<H", buffer, C["REQUEST_STATUS_OFFSET"], C["REQUEST_STATUS_PENDING"])
    struct.pack_into("<Q", buffer, C["REQUEST_JOB_ID_OFFSET"], job_id)

    return bytes(buffer)


def read_objects(blob):
    offset = 0

    while offset < len(blob):
        if len(blob) - offset < C["OBJECT_HEADER_LENGTH"]:
            raise ValueError("%d stray bytes at offset %d" % (len(blob) - offset, offset))

        magic, version, type_code, object_id, total = struct.unpack_from("<IHHQQ", blob, offset)
        if total < C["OBJECT_HEADER_LENGTH"] or offset + total > len(blob):
            raise ValueError("object at %d claims %d bytes" % (offset, total))

        body = blob[offset:offset + total]
        item = {"type": TYPE_NAMES.get(type_code, "unknown %d" % type_code), "id": object_id,
                "length": total, "magic": magic, "version": version}

        if type_code == C["OBJECT_TYPE_DATA"]:
            item["payload"] = body[C["DATA_PAYLOAD_OFFSET"]:]
            item["flags"] = struct.unpack_from("<I", body, C["DATA_FLAGS_OFFSET"])[0]
        elif type_code == C["OBJECT_TYPE_FUNCTION"]:
            item["code"] = body[C["FUNCTION_CODE_OFFSET"]:]
        elif type_code == C["OBJECT_TYPE_JOB"]:
            item["function"] = struct.unpack_from("<Q", body, C["JOB_FUNCTION_ID_OFFSET"])[0]
            item["input"] = struct.unpack_from("<Q", body, C["JOB_INPUT_DATA_ID_OFFSET"])[0]
            item["output"] = struct.unpack_from("<Q", body, C["JOB_OUTPUT_DATA_ID_OFFSET"])[0]
            item["dependent"] = bool(struct.unpack_from("<I", body, C["JOB_FLAGS_OFFSET"])[0] & C["JOB_FLAG_DEPENDENT"])
        elif type_code == C["OBJECT_TYPE_REQUEST"]:
            item["target"] = struct.unpack_from("<Q", body, C["REQUEST_TARGET_ID_OFFSET"])[0]
            item["targetType"] = struct.unpack_from("<H", body, C["REQUEST_TARGET_TYPE_OFFSET"])[0]
            item["status"] = struct.unpack_from("<H", body, C["REQUEST_STATUS_OFFSET"])[0]

        yield item
        offset += total

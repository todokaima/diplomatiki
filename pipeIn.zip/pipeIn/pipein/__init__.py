"""pipeIn -- builds the job functions, the input vectors and the job file the engine runs."""

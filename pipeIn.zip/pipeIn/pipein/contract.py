import os
import re

PROJECT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENGINE = os.environ.get("PIPEIN_ENGINE", os.path.join(os.path.dirname(PROJECT), "engineJava"))

DEFINE = re.compile(r"^\s*#define\s+([A-Z][A-Z0-9_]*)\s+(.+?)\s*(?://.*)?$")
NUMBER_SUFFIX = re.compile(r"\b(0x[0-9A-Fa-f]+|\d+)[uU]?[lL]*\b")
ARITHMETIC = re.compile(r"[A-Za-z0-9_\s()<>|+*-]+")


def load(path):
    constants = {}

    with open(path) as header:
        for line in header:
            match = DEFINE.match(line)
            if not match:
                continue

            name, value = match.groups()

            if value.startswith('"'):
                constants[name] = value.strip('"')
                continue

            expression = NUMBER_SUFFIX.sub(r"\1", value)
            if not ARITHMETIC.fullmatch(expression):
                continue

            try:
                constants[name] = eval(expression, {"__builtins__": {}}, dict(constants))
            except Exception:
                pass

    return constants


def contract_path(engine=None):
    return os.path.join(engine or ENGINE, "worker", "contract.h")


C = load(contract_path())

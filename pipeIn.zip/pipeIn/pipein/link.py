import socket
import struct

from . import objects
from .contract import C


def connect(address, timeout=30.0):
    host, _, port = address.rpartition(":")
    connection = socket.create_connection((host, int(port)), timeout=timeout)
    connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    return connection


def read_exactly(connection, length):
    chunks, remaining = [], length
    while remaining:
        chunk = connection.recv(min(remaining, 1 << 20))
        if not chunk:
            raise ConnectionError("the head closed the connection")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def read_object(connection):
    envelope = read_exactly(connection, C["OBJECT_HEADER_LENGTH"])
    total = struct.unpack_from("<Q", envelope, C["OBJECT_TOTAL_LENGTH_OFFSET"])[0]
    blob = envelope + read_exactly(connection, total - C["OBJECT_HEADER_LENGTH"])
    return next(objects.read_objects(blob))


def fetch_data(connection, data_id):
    connection.sendall(objects.request_object(C["OBJECT_TYPE_DATA"], data_id))

    while True:
        reply = read_object(connection)

        if reply["type"] == "DATA" and reply["id"] == data_id:
            return reply["payload"]
        if reply["type"] == "REQUEST" and reply["target"] == data_id:
            return None

import struct

from .contract import C
from .objects import hash_id

MAGIC = 0xD5E9C1FE
HEADER = struct.Struct("<IIQII")
MAX_ROWS = 100000
MAX_COLS = 16


def row_id(values):
    return hash_id(struct.pack("<%dq" % len(values), *values))


def encode(rows):
    if not rows:
        raise ValueError("a dataset needs at least one row")

    cols = len(rows[0])
    if not 1 <= cols <= MAX_COLS or len(rows) > MAX_ROWS:
        raise ValueError("%d x %d is out of range" % (len(rows), cols))
    if any(len(row) != cols for row in rows):
        raise ValueError("every row needs %d values" % cols)

    parts = [HEADER.pack(MAGIC, C["ENGINE_VERSION"], len(rows), cols, 0)]
    for values in rows:
        parts.append(struct.pack("<Q", row_id(values)))
        parts.append(struct.pack("<%dq" % cols, *values))

    return b"".join(parts)


def decode(payload):
    magic, version, count, cols, _ = HEADER.unpack_from(payload, 0)
    if magic != MAGIC:
        raise ValueError("not a dataset (magic %08x)" % magic)

    rows, offset = [], HEADER.size
    for _ in range(count):
        identity = struct.unpack_from("<Q", payload, offset)[0]
        values = list(struct.unpack_from("<%dq" % cols, payload, offset + 8))
        rows.append((identity, values))
        offset += 8 + 8 * cols

    return rows


def is_dataset(blob):
    return len(blob) >= HEADER.size and struct.unpack_from("<I", blob, 0)[0] == MAGIC

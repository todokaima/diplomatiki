import math
import os
import random

from . import dataset


def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


SPIN_STEP = 1000000
SPIN_MUL = 6364136223846793005
SPIN_ADD = 1442695040888963407
MASK = (1 << 64) - 1


def lcg_steps(x, steps):
    a, c = 1, 0
    pa, pc = SPIN_MUL, SPIN_ADD
    while steps:
        if steps & 1:
            a, c = (pa * a) & MASK, (pa * c + pc) & MASK
        pa, pc = (pa * pa) & MASK, (pa * pc + pc) & MASK
        steps >>= 1
    return (a * x + c) & MASK


def spin(n):
    state = lcg_steps(n, n * SPIN_STEP)
    return state - (1 << 64) if state >= 1 << 63 else state


FUNCTIONS = {"fib": fib, "factorial": math.factorial, "spin": spin}


DOMAIN = {"fib": range(0, 93), "factorial": range(0, 21), "spin": range(0, 201)}


def vector(seed, rows, cols, low, high):
    return {"seed": seed, "rows": rows, "cols": cols, "low": low, "high": high}


def fixed(*rows):
    return {"values": [list(row) for row in rows]}


def digits(i, base, count):
    return [(i // base ** place) % base for place in range(count)]


def independent(name, function, vector_name):
    return {"name": name, "function": function, "input": vector_name}


def dependent(name, function, after):
    return {"name": name, "function": function, "after": after}


def _demo():
    vectors = {
        "fib_vectors":       vector(1, 8, 4, 0, 92),
        "factorial_vectors": vector(2, 8, 4, 0, 20),
        "chain_vectors":     vector(3, 4, 4, 0, 7),
        "deep_vectors":      vector(4, 4, 4, 0, 5),
        "fan_vectors":       vector(5, 4, 4, 0, 7),
    }
    jobs = [
        independent("fib", "fib", "fib_vectors"),
        independent("factorial", "factorial", "factorial_vectors"),
        independent("chain_fib", "fib", "chain_vectors"),
        dependent("chain_factorial", "factorial", "chain_fib"),
        independent("deep_fib", "fib", "deep_vectors"),
        dependent("deep_fib_fib", "fib", "deep_fib"),
        dependent("deep_factorial", "factorial", "deep_fib_fib"),
        independent("fan_fib", "fib", "fan_vectors"),
        dependent("fan_factorial", "factorial", "fan_fib"),
        dependent("fan_fib_fib", "fib", "fan_fib"),
    ]
    return vectors, jobs


def _smoke():
    vectors = {"smoke_fib": vector(11, 4, 4, 0, 92), "smoke_chain": vector(12, 4, 4, 0, 7)}
    jobs = [
        independent("smoke_fib", "fib", "smoke_fib"),
        independent("smoke_chain_fib", "fib", "smoke_chain"),
        dependent("smoke_chain_factorial", "factorial", "smoke_chain_fib"),
    ]
    return vectors, jobs


def _crossing():
    vectors, jobs = {}, []
    for i in range(8):
        vectors["crossing_%d" % i] = vector(100 + i, 4, 4, 0, 5)
        jobs += [
            independent("crossing_%d_fib" % i, "fib", "crossing_%d" % i),
            dependent("crossing_%d_fib_fib" % i, "fib", "crossing_%d_fib" % i),
            dependent("crossing_%d_factorial" % i, "factorial", "crossing_%d_fib_fib" % i),
        ]
    return vectors, jobs


def _bulk():
    vectors, jobs = {}, []
    for i in range(16):
        vectors["bulk_fib_%d" % i] = vector(200 + i, 2048, 16, 0, 92)
        vectors["bulk_factorial_%d" % i] = vector(300 + i, 2048, 16, 0, 20)
        jobs.append(independent("bulk_fib_%d" % i, "fib", "bulk_fib_%d" % i))
        jobs.append(independent("bulk_factorial_%d" % i, "factorial", "bulk_factorial_%d" % i))
    return vectors, jobs


def _cpu():
    vectors, jobs = {}, []
    for i in range(12):
        vectors["cpu_%d" % i] = vector(400 + i, 4, 4, 100, 200)
        jobs.append(independent("cpu_spin_%d" % i, "spin", "cpu_%d" % i))
    for i in range(4):
        vectors["cpu_chain_%d" % i] = vector(500 + i, 4, 4, 10, 12)
        jobs.append(independent("cpu_chain_%d_fib" % i, "fib", "cpu_chain_%d" % i))
        jobs.append(dependent("cpu_chain_%d_spin" % i, "spin", "cpu_chain_%d_fib" % i))
    return vectors, jobs


def _swarm():
    total = int(os.environ.get("PIPEIN_SWARM", "5000"))
    chains = min(total // 10, 8 ** 4)
    vectors, jobs = {}, []
    for i in range(chains):
        vectors["swarm_chain_%d" % i] = fixed(digits(i, 8, 4))
        jobs.append(independent("swarm_chain_%d_fib" % i, "fib", "swarm_chain_%d" % i))
        jobs.append(dependent("swarm_chain_%d_factorial" % i, "factorial", "swarm_chain_%d_fib" % i))
    for i in range(total - 2 * chains):
        vectors["swarm_%d" % i] = fixed([8 + i % 85] + digits(i // 85, 93, 3))
        jobs.append(independent("swarm_%d" % i, "fib", "swarm_%d" % i))
    return vectors, jobs


def _smokes():
    copies = int(os.environ.get("PIPEIN_SMOKES", "10000"))
    vectors, jobs = {}, []
    for i in range(copies):
        vectors["smokes_%d_fib" % i] = vector(1000000 + 2 * i, 4, 4, 0, 92)
        vectors["smokes_%d_chain" % i] = vector(1000001 + 2 * i, 4, 4, 0, 7)
        jobs.append(independent("smokes_%d_fib" % i, "fib", "smokes_%d_fib" % i))
        jobs.append(independent("smokes_%d_chain_fib" % i, "fib", "smokes_%d_chain" % i))
        jobs.append(dependent("smokes_%d_chain_factorial" % i, "factorial", "smokes_%d_chain_fib" % i))
    return vectors, jobs


def _grind():
    count = int(os.environ.get("PIPEIN_GRIND_JOBS", "64"))
    batch = int(os.environ.get("PIPEIN_GRIND_BATCH", "0"))
    work = int(os.environ.get("PIPEIN_GRIND_VALUES", "7"))
    if not 1 <= work <= 8 or not 0 <= batch < 10 ** 4 or not 0 < count <= 10 ** 4:
        raise SystemExit("grind: PIPEIN_GRIND_VALUES 1..8, PIPEIN_GRIND_BATCH 0..9999, PIPEIN_GRIND_JOBS 1..10000")
    vectors, jobs = {}, []
    for i in range(count):
        name = "grind_%d_%d" % (batch, i)
        vectors[name] = fixed([200] * work + digits(batch, 10, 4) + digits(i, 10, 4))
        jobs.append(independent(name, "spin", name))
    return vectors, jobs


LOADS = {"smoke": _smoke, "demo": _demo, "crossing": _crossing, "bulk": _bulk, "cpu": _cpu, "swarm": _swarm, "smokes": _smokes, "grind": _grind}
DEFAULT_LOAD = "demo"

VECTORS, JOBS, BY_NAME = {}, [], {}


def select(name):
    global VECTORS, JOBS, BY_NAME
    if name not in LOADS:
        raise SystemExit("no load %r -- there are: %s" % (name, ", ".join(LOADS)))
    VECTORS, JOBS = LOADS[name]()
    BY_NAME = {job["name"]: job for job in JOBS}


select(DEFAULT_LOAD)


def job(name):
    return BY_NAME[name]


def vector_rows(name):
    spec = VECTORS[name]
    if "values" in spec:
        return spec["values"]
    generator = random.Random(spec["seed"])
    return [[generator.randint(spec["low"], spec["high"]) for _ in range(spec["cols"])] for _ in range(spec["rows"])]


def input_rows(job_name):
    spec = job(job_name)
    return expected_rows(spec["after"]) if "after" in spec else vector_rows(spec["input"])


def expected_rows(job_name):
    apply = FUNCTIONS[job(job_name)["function"]]
    return [[apply(value) for value in row] for row in input_rows(job_name)]


def expected_payload(job_name):
    return dataset.encode(expected_rows(job_name))

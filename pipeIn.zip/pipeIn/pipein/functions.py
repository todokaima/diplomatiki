import glob
import os
import subprocess

from .contract import C, ENGINE, PROJECT
from .objects import hash_id

SOURCES = os.path.join(PROJECT, "functions")


def sources():
    return {os.path.basename(path)[:-2]: path for path in sorted(glob.glob(os.path.join(SOURCES, "*.c")))}


def build(name, source, out_directory, engine=None, cc="gcc"):
    os.makedirs(out_directory, exist_ok=True)
    partial = os.path.join(out_directory, ".%s.%d.so" % (name, os.getpid()))

    command = [cc, "-std=gnu11", "-O2", "-Wall", "-Wextra", "-fPIC", "-shared",
               "-I", os.path.join(engine or ENGINE, "worker"), "-I", SOURCES,
               "-o", partial, source]
    subprocess.run(command, check=True)

    exported = subprocess.run(["nm", "-D", "--defined-only", partial], check=True, capture_output=True, text=True).stdout
    if not any(line.split()[-1:] == [C["JOB_FUNCTION_ENTRY"]] and " T " in line for line in exported.splitlines()):
        os.remove(partial)
        raise SystemExit("%s does not export %s" % (source, C["JOB_FUNCTION_ENTRY"]))

    with open(partial, "rb") as built:
        identity = hash_id(built.read())

    path = os.path.join(out_directory, "%016x.so" % identity)
    os.replace(partial, path)
    return identity, path

#!/usr/bin/env python3
"""usage: ./analyze.py DIR    (DIR holds <node>.head.log files)"""
import collections
import glob
import json
import os
import re
import sys

LINE = re.compile(r"^(\d\d):(\d\d):(\d\d)\.(\d{3}) (\S+) (.*)$")

EVENTS = [
    ("received_job", re.compile(r"^received job ([0-9a-f]{16}) from (.+)$")),
    ("received_data", re.compile(r"^received DataObject id=([0-9a-f]{16}) \d+ B from (.+)$")),
    ("received_function", re.compile(r"^received FunctionObject id=([0-9a-f]{16}) \d+ B from (.+)$")),
    ("ran", re.compile(r"^job ([0-9a-f]{16}) resolved, running here( \(shipped here\))?$")),
    ("waiting", re.compile(r"^job ([0-9a-f]{16}) waiting:(?: function ([0-9a-f]{16}))?(?: data ([0-9a-f]{16}))?$")),
    ("shipped", re.compile(r"^job ([0-9a-f]{16}) shipped to (\S+)$")),
    ("asked", re.compile(r"^asked (\S+) for (data|function) ([0-9a-f]{16})$")),
    ("not_found", re.compile(r"^(\S+) does not hold ([0-9a-f]{16}) yet$")),
    ("answered_data", re.compile(r"^answered (.+): (?:DataObject|FunctionObject) id=([0-9a-f]{16}) \d+ B$")),
    ("answered_not_found", re.compile(r"^answered (.+): RequestObject id=([0-9a-f]{16}) \d+ B$")),
    ("promise_received", re.compile(r"^(.+) will push ([0-9a-f]{16}) once it holds it$")),
    ("promised", re.compile(r"^promised (.+) ([0-9a-f]{16}) once held$")),
    ("pushed", re.compile(r"^pushed (?:DataObject|FunctionObject) id=([0-9a-f]{16}) \d+ B to (.+)$")),
    ("linked", re.compile(r"^linked to (.+)$")),
    ("closed", re.compile(r"^link (.+) closed$")),
]


def milliseconds(match):
    hours, minutes, seconds, millis = (int(match.group(i)) for i in range(1, 5))
    return ((hours * 60 + minutes) * 60 + seconds) * 1000 + millis


def read(path):
    events, last, day = [], None, 0
    with open(path, errors="replace") as log:
        for text in log:
            line = LINE.match(text.rstrip("\n"))
            if not line:
                continue
            at = milliseconds(line) + day
            if last is not None and at < last - 12 * 3600 * 1000:
                day += 24 * 3600 * 1000
                at += 24 * 3600 * 1000
            last = at
            for name, pattern in EVENTS:
                event = pattern.match(line.group(6))
                if event:
                    events.append((at, name, event.groups()))
                    break
    return events


def spread(values):
    if not values:
        return None
    values = sorted(values)
    pick = lambda share: values[min(len(values) - 1, int(len(values) * share))]
    return {"count": len(values), "min": values[0], "p50": pick(0.5), "p95": pick(0.95), "max": values[-1],
            "mean": round(sum(values) / len(values), 1)}


def node_report(events):
    counts = collections.Counter(name for _, name, _ in events)
    received = [groups[0] for _, name, groups in events if name == "received_job"]
    ran = [(at, groups[0]) for at, name, groups in events if name == "ran"]
    asked = {groups[2] for _, name, groups in events if name == "asked"}

    waiting_since, waited = {}, []
    for at, name, groups in events:
        if name == "waiting":
            waiting_since.setdefault(groups[0], at)
        elif name == "ran" and groups[0] in waiting_since:
            waited.append(at - waiting_since.pop(groups[0]))

    fetched = {groups[0] for _, name, groups in events if name == "received_data" and groups[0] in asked}

    per_second = collections.Counter(at // 1000 for at, _ in ran)
    start = min((at for at, _, _ in events), default=0)
    first_job = min((at for at, name, _ in events if name == "received_job"), default=None)
    last_run = max((at for at, _ in ran), default=None)

    return {
        "jobs received": len(received),
        "jobs received twice or more": len(received) - len(set(received)),
        "jobs run": len(ran),
        "jobs run (shipped here)": sum(1 for _, name, groups in events if name == "ran" and groups[1]),
        "jobs shipped away": counts["shipped"],
        "jobs that waited": len(waited) + len(waiting_since),
        "jobs still waiting at the end": len(waiting_since),
        "wait ms (waiting -> running)": spread(waited),
        "REQUESTs made": counts["asked"],
        "distinct ids asked for": len(asked),
        "REQUESTs per id asked (mean)": round(counts["asked"] / len(asked), 1) if asked else 0,
        "NOT_FOUND received": counts["not_found"],
        "WAITING received (the other node will push)": counts["promise_received"],
        "results fetched from the other node": len(fetched),
        "answered with data": counts["answered_data"],
        "answered NOT_FOUND": counts["answered_not_found"],
        "promised to the other node (WAITING)": counts["promised"],
        "pushed to the other node": counts["pushed"],
        "links opened": counts["linked"],
        "first job received at s": round((first_job - start) / 1000, 3) if first_job is not None else None,
        "busy s (first job received -> last job run)": round((last_run - first_job) / 1000, 3) if first_job is not None and last_run is not None else None,
        "jobs run per second": spread(list(per_second.values())),
        "_ran": {job for _, job in ran},
        "_waited": waited,
        "_first_job": first_job,
        "_last_run": last_run,
        "_waiting_inputs": {groups[0]: groups[2] for _, name, groups in events if name == "waiting" and groups[2]},
        "_fetched": fetched,
    }


def summarize(nodes, bench):
    names = list(nodes)
    column = lambda pick: [pick(nodes[name]) for name in names]
    waits = column(lambda figures: figures["_waited"])
    every_wait = [wait for node_waits in waits for wait in node_waits]
    mean = lambda values: round(sum(values) / len(values)) if values else "-"
    firsts = [first for first in column(lambda figures: figures["_first_job"]) if first is not None]
    lasts = [last for last in column(lambda figures: figures["_last_run"]) if last is not None]
    ran = column(lambda figures: figures["jobs run"])
    waited = column(lambda figures: len(figures["_waited"]))
    crossed = column(lambda figures: sum(1 for data in figures["_waiting_inputs"].values() if data in figures["_fetched"]))

    rows = [
        ("jobs resolved and run", ran, sum(ran)),
        ("  at once (input already held)", [r - w for r, w in zip(ran, waited)], sum(ran) - sum(waited)),
        ("  after waiting for their input", waited, sum(waited)),
        ("    input from the other node", crossed, sum(crossed)),
        ("wait ms, mean", [mean(node_waits) for node_waits in waits], mean(every_wait)),
        ("wait ms, p50", [(spread(node_waits) or {}).get("p50", "-") for node_waits in waits], (spread(every_wait) or {}).get("p50", "-")),
        ("wait ms, p95", [(spread(node_waits) or {}).get("p95", "-") for node_waits in waits], (spread(every_wait) or {}).get("p95", "-")),
        ("wait ms, max", [max(node_waits) if node_waits else "-" for node_waits in waits], max(every_wait) if every_wait else "-"),
        ("REQUESTs to the other node", column(lambda figures: figures["REQUESTs made"]), sum(column(lambda figures: figures["REQUESTs made"]))),
        ("NOT_FOUND back", column(lambda figures: figures["NOT_FOUND received"]), sum(column(lambda figures: figures["NOT_FOUND received"]))),
        ("results pushed to the other node", column(lambda figures: figures["pushed to the other node"]), sum(column(lambda figures: figures["pushed to the other node"]))),
        ("busy s (first job in -> last job run)", column(lambda figures: figures["busy s (first job received -> last job run)"]),
         round((max(lasts) - min(firsts)) / 1000, 3) if firsts and lasts else "-"),
    ]
    if bench:
        rows += [
            ("pipeIn: total s (send -> last result)", ["" for _ in names], bench.get("totalSeconds")),
            ("pipeIn: jobs per second", ["" for _ in names], bench.get("jobsPerSecond")),
            ("pipeIn: results verified", ["" for _ in names], "%s of %s %s" % (bench.get("collected"), bench.get("jobs"), "ok" if bench.get("verified") else "NOT VERIFIED")),
        ]
    return {"columns": names + ["total"], "rows": [[label] + values + [total] for label, values, total in rows]}


def table(summary):
    width = max(12, *(len(name) + 2 for name in summary["columns"]))
    lines = ["%-40s" % "" + "".join("%*s" % (width, name) for name in summary["columns"])]
    for row in summary["rows"]:
        lines.append("%-40s" % row[0] + "".join("%*s" % (width, value) for value in row[1:]))
    return lines


def text(report):
    lines = ["== summary"] + table(report["summary"]) + [""]
    for node, figures in report["nodes"].items():
        lines.append("== %s" % node)
        for key, value in figures.items():
            if isinstance(value, dict):
                value = "  ".join("%s %s" % item for item in value.items())
            lines.append("  %-44s %s" % (key, value))
    lines.append("== cluster")
    for key, value in report["cluster"].items():
        lines.append("  %-44s %s" % (key, value))
    if report.get("bench"):
        lines.append("== bench (pipeIn's view)")
        for key in ("jobs", "dependent", "sendSeconds", "firstResultSeconds", "medianResultSeconds",
                    "p95ResultSeconds", "totalSeconds", "jobsPerSecond", "collected", "missing", "verified"):
            if key in report["bench"]:
                lines.append("  %-44s %s" % (key, report["bench"][key]))
    return "\n".join(lines) + "\n"


def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    directory = sys.argv[1]
    logs = sorted(glob.glob(os.path.join(directory, "*.head.log")))
    if not logs:
        raise SystemExit("no *.head.log in %s" % directory)

    nodes = {os.path.basename(path)[:-len(".head.log")]: node_report(read(path)) for path in logs}

    ran_by = collections.Counter(job for figures in nodes.values() for job in figures["_ran"])
    crossed = sum(1 for figures in nodes.values()
                  for job, data in figures["_waiting_inputs"].items() if data in figures["_fetched"])
    cluster = {
        "distinct jobs run": len(ran_by),
        "jobs run on more than one node": sum(1 for count in ran_by.values() if count > 1),
        "dependent jobs whose input came from the other node": crossed,
    }
    bench = None
    summary = os.path.join(directory, "summary.json")
    if os.path.exists(summary):
        with open(summary) as source:
            bench = json.load(source)

    headline = summarize(nodes, bench)
    for figures in nodes.values():
        for key in [key for key in figures if key.startswith("_")]:
            del figures[key]

    report = {"summary": headline, "nodes": nodes, "cluster": cluster}
    if bench:
        report["bench"] = bench

    with open(os.path.join(directory, "analysis.json"), "w") as out:
        json.dump(report, out, indent=2)
    with open(os.path.join(directory, "analysis.txt"), "w") as out:
        out.write(text(report))
    sys.stdout.write(text(report))
    print("  -> %s" % os.path.join(directory, "analysis.txt"))


if __name__ == "__main__":
    main()

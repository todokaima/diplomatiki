#include "dataset.h"

#define SPIN_MAX   200
#define SPIN_STEP  1000000ULL
#define SPIN_MUL   6364136223846793005ULL
#define SPIN_ADD   1442695040888963407ULL

int64_t engineJob(const void *data, uint32_t dataLength, void *output, uint32_t outputCapacity)
{
    if (!dsValid(data, dataLength)) return -1;

    uint64_t rows = dsRows(data);
    uint32_t cols = dsCols(data);

    uint32_t need = dsBytes(rows, cols);
    if (need > outputCapacity) return -1;

    dsInit(output, rows, cols);

    int64_t values[DS_MAX_COLS];

    for (uint64_t row = 0; row < rows; row++) {
        for (uint32_t col = 0; col < cols; col++) {
            int64_t n = dsValue(data, row, col);
            if (n < 0 || n > SPIN_MAX) return -1;

            uint64_t x = (uint64_t)n;
            uint64_t steps = (uint64_t)n * SPIN_STEP;

            for (uint64_t k = 0; k < steps; k++) {
                x = x * SPIN_MUL + SPIN_ADD;
                __asm__ volatile("" : "+r"(x));
            }

            values[col] = (int64_t)x;
        }

        dsSetRow(output, row, values, cols);
    }

    return (int64_t)need;
}

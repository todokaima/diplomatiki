#include "dataset.h"

#define FACTORIAL_MAX 20

int64_t engineJob(const void *data, uint32_t dataLength, void *output, uint32_t outputCapacity)
{
    if (!dsValid(data, dataLength)) return -1;

    uint64_t rows = dsRows(data);
    uint32_t cols = dsCols(data);

    uint32_t need = dsBytes(rows, cols);
    if (need > outputCapacity) return -1;

    dsInit(output, rows, cols);

    int64_t values[DS_MAX_COLS];

    for (uint64_t row = 0; row < rows; row++) {
        for (uint32_t col = 0; col < cols; col++) {
            int64_t n = dsValue(data, row, col);
            if (n < 0 || n > FACTORIAL_MAX) return -1;

            int64_t product = 1;
            for (int64_t k = 2; k <= n; k++)
                product *= k;

            values[col] = product;
        }

        dsSetRow(output, row, values, cols);
    }

    return (int64_t)need;
}

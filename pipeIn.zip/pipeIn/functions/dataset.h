#ifndef PIPEIN_DATASET_H
#define PIPEIN_DATASET_H

#include "contract.h"

#define DS_MAGIC     0xD5E9C1FEu
#define DS_HEADER    24u
#define DS_MAX_ROWS  100000u
#define DS_MAX_COLS  16u

#define DS_MAGIC_OFFSET    0u
#define DS_VERSION_OFFSET  4u
#define DS_ROWS_OFFSET     8u
#define DS_COLS_OFFSET    16u

static inline uint64_t dsRows(const void *d) { return readUint64At(d, DS_ROWS_OFFSET); }
static inline uint32_t dsCols(const void *d) { return readUint32At(d, DS_COLS_OFFSET); }

static inline uint32_t dsStride(uint32_t cols) { return 8u + cols * 8u; }

static inline uint32_t dsBytes(uint64_t rows, uint32_t cols)
{
    if (cols == 0 || cols > DS_MAX_COLS || rows > DS_MAX_ROWS) return 0;
    return DS_HEADER + (uint32_t)rows * dsStride(cols);
}

static inline int dsValid(const void *d, uint32_t length)
{
    if (length < DS_HEADER) return 0;
    if (readUint32At(d, DS_MAGIC_OFFSET) != DS_MAGIC) return 0;
    if (readUint32At(d, DS_VERSION_OFFSET) != ENGINE_VERSION) return 0;

    uint32_t need = dsBytes(dsRows(d), dsCols(d));
    return need != 0 && need <= length;
}

static inline int64_t dsValue(const void *d, uint64_t row, uint32_t col)
{
    return (int64_t)readUint64At(d, DS_HEADER + (uint32_t)row * dsStride(dsCols(d)) + 8u + col * 8u);
}

static inline void dsInit(void *d, uint64_t rows, uint32_t cols)
{
    writeUint32At(d, DS_MAGIC_OFFSET, DS_MAGIC);
    writeUint32At(d, DS_VERSION_OFFSET, ENGINE_VERSION);
    writeUint64At(d, DS_ROWS_OFFSET, rows);
    writeUint32At(d, DS_COLS_OFFSET, cols);
    writeUint32At(d, 20u, 0u);
}

static inline void dsSetRow(void *d, uint64_t row, const int64_t *values, uint32_t cols)
{
    uint32_t offset = DS_HEADER + (uint32_t)row * dsStride(cols);

    writeUint64At(d, offset, hashId(values, (size_t)cols * 8u));

    for (uint32_t col = 0; col < cols; col++)
        writeUint64At(d, offset + 8u + col * 8u, (uint64_t)values[col]);
}

#endif

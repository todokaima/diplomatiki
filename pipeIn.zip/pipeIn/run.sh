#!/usr/bin/env bash
# usage: ./run.sh [LOAD]    two local nodes, bench, analysis
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

LOAD="${1:-smokes}"
ENGINE="${PIPEIN_ENGINE:-$(cd .. && pwd)/engineJava}"
read -r A B <<< "${PORTS:-9000 9100}"
WAIT="${WAIT:-600}"

for port in "$A" "$B"; do
    if (exec 3<>"/dev/tcp/127.0.0.1/$port") 2>/dev/null; then
        echo "port $port is in use -- stop the nodes running there first (ctrl-c)" >&2
        exit 1
    fi
done

echo "== engine (rebuilt, so the head is the current source)"
"$ENGINE/build.sh" | tail -1

echo "== load $LOAD"
[ -f out/functions.json ] || ./pipein.py build
./pipein.py vectors --load "$LOAD" | tail -1
./pipein.py jobs --load "$LOAD" | tail -1

NODES=()
stop() {
    for pid in "${NODES[@]}"; do kill -TERM -- "-$pid" 2>/dev/null || true; done
    for pid in "${NODES[@]}"; do wait "$pid" 2>/dev/null || true; done
    NODES=()
}
trap stop EXIT INT TERM

echo "== nodes on $A and $B"
setsid "$ENGINE/run.sh" "$A" "$B" > /dev/null 2>&1 & NODES+=($!)
setsid "$ENGINE/run.sh" "$B" "$A" > /dev/null 2>&1 & NODES+=($!)

for port in "$A" "$B"; do
    for _ in $(seq 300); do
        grep -qs " serving," "$ENGINE/run-$port/head.log" && break
        sleep 0.1
    done
    grep -qs " serving," "$ENGINE/run-$port/head.log" \
        || { echo "node $port did not start:" >&2; tail -5 "$ENGINE/run-$port/head.log" "$ENGINE/run-$port/worker.log" >&2; exit 1; }
    echo "  node $port serving"
done

echo "== bench: send to both, collect every result, verify"
./pipein.py bench "127.0.0.1:$A" "127.0.0.1:$B" --load "$LOAD" --alternate --label local --wait "$WAIT" || true

RUN="$(ls -dt out/bench/local-* | head -1)"
sleep 1
stop
for port in "$A" "$B"; do
    cp "$ENGINE/run-$port/head.log"   "$RUN/node-$port.head.log"
    cp "$ENGINE/run-$port/worker.log" "$RUN/node-$port.worker.log"
done

echo "== analysis"
./analyze.py "$RUN"

#!/usr/bin/env bash
# usage: ./run.sh a|b | PORT [PEER]
#   env: THREADS CONTROL_IP DATA_IP DATA_PORT PEER_DATA SOCKET_BUFFER
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

A_CONTROL=192.168.2.20 A_DATA=192.168.2.21 A_PORT=9000
B_CONTROL=192.168.2.10 B_DATA=192.168.2.11 B_PORT=9100

ROLE="${1:?usage: ./run.sh a|b|PORT [PEER]}"
case "$ROLE" in
    a)  PORT=$A_PORT
        CONTROL_IP="${CONTROL_IP:-$A_CONTROL}" DATA_IP="${DATA_IP:-$A_DATA}"
        PEER="${PEER:-$B_CONTROL:$B_PORT}" PEER_DATA="${PEER_DATA:-$B_DATA:$((B_PORT + 1))}" ;;
    b)  PORT=$B_PORT
        CONTROL_IP="${CONTROL_IP:-$B_CONTROL}" DATA_IP="${DATA_IP:-$B_DATA}"
        PEER="${PEER:-$A_CONTROL:$A_PORT}" PEER_DATA="${PEER_DATA:-$A_DATA:$((A_PORT + 1))}" ;;
    *)  PORT="$ROLE"
        case "${2:-}" in
            "")  case "$PORT" in
                     9000) PEER=127.0.0.1:9100 ;;
                     9100) PEER=127.0.0.1:9000 ;;
                     *) echo "no default peer for port $PORT: ./run.sh $PORT PEER" >&2; exit 1 ;;
                 esac
                 PEER_DATA="${PEER_DATA:-127.0.0.1:$((${PEER##*:} + 1))}" ;;
            *:*) PEER="$2" ;;
            *)   PEER="127.0.0.1:$2"
                 PEER_DATA="${PEER_DATA:-127.0.0.1:$(($2 + 1))}" ;;
        esac
        CONTROL_IP="${CONTROL_IP:-}" DATA_IP="${DATA_IP:-}" PEER_DATA="${PEER_DATA:-}" ;;
esac
DATA_PORT="${DATA_PORT:-$((PORT + 1))}"
ADVERTISE="${ADVERTISE:-${CONTROL_IP:-127.0.0.1}:$PORT}"
THREADS="${THREADS:-2}"
SOCKET_BUFFER="${SOCKET_BUFFER:-0}"

for ip in $CONTROL_IP $DATA_IP; do
    if ! (hostname -I 2>/dev/null || ip -o -4 addr 2>/dev/null) | grep -qw "$ip"; then
        echo "this machine has no address $ip -- wrong role? (a on the .20/.21 machine, b on the .10/.11 one)" >&2
        exit 1
    fi
done

nic_of() { ip -o -4 addr show | awk -v want="$1" '{ split($4, a, "/"); if (a[1] == want) print $2 }' | head -1; }
route_dev() { ip route get "$1" from "$2" 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -1; }

if [ "$ROLE" = a ] || [ "$ROLE" = b ]; then
    for pair in "$CONTROL_IP ${PEER%:*}" "$DATA_IP ${PEER_DATA%:*}"; do
        read -r from to <<< "$pair"
        want="$(nic_of "$from")"
        got="$(route_dev "$to" "$from")"
        if [ -z "$want" ] || [ "$got" != "$want" ]; then
            echo "warning: $from -> $to leaves through '${got:-?}', not ${want:-its NIC} (sudo ./net-setup.sh $ROLE pins it)" >&2
        else
            echo "$from -> $to via $got"
        fi
    done
    [ "$(nic_of "$CONTROL_IP")" != "$(nic_of "$DATA_IP")" ] \
        || echo "warning: $CONTROL_IP and $DATA_IP are on the same NIC: one link, not two" >&2
fi

[ -x node ] && [ -f head/head.jar ] || ./build.sh

RUN="$PWD/run-$PORT"
rm -rf "$RUN"
mkdir -p "$RUN"

(cd "$RUN" && exec ../node --socket "$RUN/engine.sock" --datasets "$RUN/datasets" --threads "$THREADS") > "$RUN/worker.log" 2>&1 &
WORKER=$!
trap 'kill $WORKER 2>/dev/null || true' EXIT INT TERM

for _ in $(seq 50); do
    [ -S "$RUN/engine.sock" ] && break
    kill -0 "$WORKER" 2>/dev/null || { echo "worker exited:" >&2; cat "$RUN/worker.log" >&2; exit 1; }
    sleep 0.1
done

CHANNELS=()
[ -n "$CONTROL_IP" ] && CHANNELS+=(--bind "$CONTROL_IP")
[ -n "$DATA_IP" ]    && CHANNELS+=(--data-bind "$DATA_IP")
[ -n "$PEER_DATA" ]  && CHANNELS+=(--data-port "$DATA_PORT" --peer-data "$PEER_DATA")

echo "node-$PORT: worker $WORKER, control ${CONTROL_IP:-*}:$PORT -> $PEER, data ${DATA_IP:-*}:$DATA_PORT -> ${PEER_DATA:-(none, one channel)}, logs in $RUN"
java -cp head/head.jar dev.pms.engine.adapter.in.JobServerCli \
    --port "$PORT" --node "$RUN/engine.sock" \
    --functions "$RUN/functions" --datasets "$RUN/datasets" \
    --node-id "node-$PORT" --advertise "$ADVERTISE" --peer "$PEER" \
    --socket-buffer "$SOCKET_BUFFER" "${CHANNELS[@]}" \
    2>&1 | tee "$RUN/head.log"

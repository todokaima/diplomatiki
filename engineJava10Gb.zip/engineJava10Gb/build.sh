#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

CC="${CC:-gcc}"
for tool in "$CC" javac jar make; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        cat >&2 <<'MSG'
missing a toolchain on this host (needs gcc, make and a JDK). Build in the container:

    docker build -t enginejavabuild -f Dockerfile.build .
    docker run --rm -u "$(id -u):$(id -g)" -v "$PWD":/src -w /src enginejavabuild ./build.sh
MSG
        exit 1
    fi
done

echo "== node (C) and head (Java) =="
make CC="$CC" build

echo
echo "built: ./node, head/head.jar"

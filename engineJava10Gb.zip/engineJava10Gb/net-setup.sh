#!/usr/bin/env bash
# usage: sudo ./net-setup.sh a|b [down]    (JUMBO=1 for MTU 9000)
set -euo pipefail

A_CONTROL=192.168.2.20 A_DATA=192.168.2.21
B_CONTROL=192.168.2.10 B_DATA=192.168.2.11

case "${1:-}" in
    a) MY_CONTROL=$A_CONTROL MY_DATA=$A_DATA PEER_CONTROL=$B_CONTROL PEER_DATA=$B_DATA ;;
    b) MY_CONTROL=$B_CONTROL MY_DATA=$B_DATA PEER_CONTROL=$A_CONTROL PEER_DATA=$A_DATA ;;
    *) echo "usage: sudo ./net-setup.sh a|b [down]" >&2; exit 1 ;;
esac

[ "$(id -u)" -eq 0 ] || { echo "needs root: sudo $0 $*" >&2; exit 1; }

nic_of() {
    ip -o -4 addr show | awk -v want="$1" '{ split($4, a, "/"); if (a[1] == want) print $2 }' | head -1
}

CONTROL_NIC="$(nic_of "$MY_CONTROL")"
DATA_NIC="$(nic_of "$MY_DATA")"
[ -n "$CONTROL_NIC" ] || { echo "no NIC holds $MY_CONTROL -- wrong side?" >&2; exit 1; }
[ -n "$DATA_NIC" ]    || { echo "no NIC holds $MY_DATA -- wrong side?" >&2; exit 1; }
[ "$CONTROL_NIC" != "$DATA_NIC" ] || { echo "$MY_CONTROL and $MY_DATA are both on $CONTROL_NIC -- one link, not two" >&2; exit 1; }

for nic in "$CONTROL_NIC" "$DATA_NIC"; do
    [ ! -d "/sys/class/net/$nic/wireless" ] || { echo "$nic is wireless, not a 10 Gb link" >&2; exit 1; }
    speed="$(cat "/sys/class/net/$nic/speed" 2>/dev/null || echo 0)"
    [ "$speed" -ge 10000 ] 2>/dev/null \
        || { echo "$nic runs at ${speed} Mb/s, not 10 Gb (cable / link down?) -- FORCE=1 to go on anyway" >&2; [ "${FORCE:-0}" = 1 ] || exit 1; }
done

if [ "${2:-}" = down ]; then
    ip route del "$PEER_CONTROL/32" dev "$CONTROL_NIC" 2>/dev/null || true
    ip route del "$PEER_DATA/32" dev "$DATA_NIC" 2>/dev/null || true
    echo "routes to $PEER_CONTROL and $PEER_DATA removed"
    exit 0
fi

echo "control: $MY_CONTROL on $CONTROL_NIC -> $PEER_CONTROL"
echo "data:    $MY_DATA on $DATA_NIC -> $PEER_DATA"

for nic in all "$CONTROL_NIC" "$DATA_NIC"; do
    sysctl -qw "net.ipv4.conf.$nic.arp_ignore=1" "net.ipv4.conf.$nic.arp_announce=2" "net.ipv4.conf.$nic.arp_filter=1"
done
for nic in "$CONTROL_NIC" "$DATA_NIC"; do
    sysctl -qw "net.ipv4.conf.$nic.rp_filter=2"
done

# both NICs share one subnet: host routes pin each channel to its own NIC
ip route replace "$PEER_CONTROL/32" dev "$CONTROL_NIC" src "$MY_CONTROL"
ip route replace "$PEER_DATA/32" dev "$DATA_NIC" src "$MY_DATA"
ip neigh flush to "$PEER_CONTROL" 2>/dev/null || true
ip neigh flush to "$PEER_DATA" 2>/dev/null || true

sysctl -qw net.core.rmem_max=67108864 net.core.wmem_max=67108864
sysctl -qw net.ipv4.tcp_rmem="4096 131072 67108864" net.ipv4.tcp_wmem="4096 65536 67108864"
sysctl -qw net.core.netdev_max_backlog=30000
sysctl -qw net.ipv4.tcp_mtu_probing=1

if [ "${JUMBO:-0}" = 1 ]; then
    ip link set "$CONTROL_NIC" mtu 9000
    ip link set "$DATA_NIC" mtu 9000
    echo "MTU 9000 on $CONTROL_NIC and $DATA_NIC"
fi

echo
echo "the kernel now routes:"
ip route get "$PEER_CONTROL" from "$MY_CONTROL" | head -1
ip route get "$PEER_DATA" from "$MY_DATA" | head -1
echo
echo "check each link: ping -c2 -I $MY_CONTROL $PEER_CONTROL; ping -c2 -I $MY_DATA $PEER_DATA"
echo "  (and with JUMBO: ping -M do -s 8972 -I $MY_DATA $PEER_DATA)"

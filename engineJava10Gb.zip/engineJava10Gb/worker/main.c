#define _GNU_SOURCE

#include "functionLoader/functionLoader.h"
#include "receiver/engineContext.h"
#include "receiver/objectStore.h"
#include "receiver/receiver.h"

#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#define DEFAULT_SOCKET_PATH "engine.sock"
#define DEFAULT_WORKER_THREADS 4
#define INPUT_ARENA_BYTES   (4ULL * 1024ULL * 1024ULL * 1024ULL)
#define RESULT_ARENA_BYTES  (1ULL * 1024ULL * 1024ULL * 1024ULL)
#define LISTEN_BACKLOG      1

static void requestShutdown(int signalNumber)
{
    (void)signalNumber;
}

static void installShutdownHandler(int signalNumber)
{
    struct sigaction action;

    memset(&action, 0, sizeof(action));
    action.sa_handler = requestShutdown;
    sigemptyset(&action.sa_mask);
    action.sa_flags = 0;

    sigaction(signalNumber, &action, NULL);
}

static int createListeningSocket(const char *socketPath)
{
    int listeningSocket = socket(AF_UNIX, SOCK_STREAM, 0);

    if (listeningSocket < 0)
        return -1;

    struct sockaddr_un address;

    memset(&address, 0, sizeof(address));
    address.sun_family = AF_UNIX;
    strncpy(address.sun_path, socketPath, sizeof(address.sun_path) - 1);

    unlink(socketPath);

    if (bind(listeningSocket, (struct sockaddr *)&address, sizeof(address)) != 0 ||
        listen(listeningSocket, LISTEN_BACKLOG) != 0) {
        close(listeningSocket);
        return -1;
    }

    return listeningSocket;
}

int main(int argc, char **argv)
{
    const char *datasetDirectory = DEFAULT_DATASET_DIRECTORY;
    const char *socketPath = DEFAULT_SOCKET_PATH;
    int workerThreads = DEFAULT_WORKER_THREADS;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--datasets") && i + 1 < argc)
            datasetDirectory = argv[++i];
        else if (!strcmp(argv[i], "--socket") && i + 1 < argc)
            socketPath = argv[++i];
        else if (!strcmp(argv[i], "--threads") && i + 1 < argc)
            workerThreads = atoi(argv[++i]);
        else {
            fprintf(stderr, "usage: node [--socket <path>] [--datasets <dir>] [--threads <n>]\n");
            return 1;
        }
    }

    ObjectStore store;
    ObjectStore outputResultStore;
    EngineContext engine;

    installShutdownHandler(SIGINT);
    installShutdownHandler(SIGTERM);
    signal(SIGPIPE, SIG_IGN);

    setvbuf(stdout, NULL, _IOLBF, 0);

    if (objectStoreCreate(&store, INPUT_ARENA_BYTES) != 0) {
        fprintf(stderr, "cannot create the object store\n");
        return 1;
    }

    if (objectStoreCreate(&outputResultStore, RESULT_ARENA_BYTES) != 0) {
        fprintf(stderr, "cannot create the output result store\n");
        objectStoreDestroy(&store);
        return 1;
    }

    if (workerThreads < 1) workerThreads = 1;

    if (engineContextCreate(&engine, &store, &outputResultStore, workerThreads) != 0) {
        fprintf(stderr, "cannot start the worker pool\n");
        objectStoreDestroy(&outputResultStore);
        objectStoreDestroy(&store);
        return 1;
    }

    receiverAttach(&engine);
    engineSetDatasetDirectory(&engine, datasetDirectory);

    if (mkdir(datasetDirectory, 0755) != 0 && errno != EEXIST) {
        perror(datasetDirectory);
        engineContextDestroy(&engine);
        objectStoreDestroy(&outputResultStore);
        objectStoreDestroy(&store);
        return 1;
    }

    if (mkdir(FUNCTION_DIRECTORY, 0755) != 0 && errno != EEXIST) {
        perror(FUNCTION_DIRECTORY);
        engineContextDestroy(&engine);
        objectStoreDestroy(&outputResultStore);
        objectStoreDestroy(&store);
        return 1;
    }

    int listeningSocket = createListeningSocket(socketPath);

    if (listeningSocket < 0) {
        perror("listen");
        engineContextDestroy(&engine);
        objectStoreDestroy(&outputResultStore);
        objectStoreDestroy(&store);
        return 1;
    }

    printf("node waiting for its head on %s, %d worker threads, results -> %s/\n", socketPath, workerThreads, datasetDirectory);

    int headSocket = accept(listeningSocket, NULL, NULL);

    close(listeningSocket);
    unlink(socketPath);

    if (headSocket >= 0) {
        printf("head connected\n");
        receiverServe(headSocket);
        close(headSocket);
        printf("head disconnected\n");
    }

    printf("shutting down\n");

    engineShutdownPool(&engine);

    int unfinished = engineReportUnfinishedJobs(&engine);

    if (unfinished)
        printf("%d job(s) unfinished at shutdown\n", unfinished);
    else
        printf("every job completed\n");

    engineContextDestroy(&engine);
    objectStoreDestroy(&outputResultStore);
    objectStoreDestroy(&store);

    return 0;
}

#define _GNU_SOURCE

#include "receiver.h"

#include "../contract.h"
#include "../dsa/circularList.h"
#include "../dsa/objects.h"
#include "../functionLoader/functionLoader.h"
#include "../workerPool/threadPool.h"
#include "objectStore.h"

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define JOB_OUTPUT_CAPACITY (8u << 20)
#define TRANSFER_CHUNK      (64u * 1024u)

static EngineContext *activeEngine;

void receiverAttach(EngineContext *engine)
{
    activeEngine = engine;
}

static int readExactBytes(int socketFd, void *buffer, size_t length)
{
    unsigned char *cursor = buffer;

    while (length > 0) {
        ssize_t received = read(socketFd, cursor, length);

        if (received < 0)
            return -1;

        if (received == 0)
            return -1;

        cursor += received;
        length -= (size_t)received;
    }

    return 0;
}

static int writeExactBytes(int fileDescriptor, const void *buffer, size_t length)
{
    const unsigned char *cursor = buffer;

    while (length > 0) {
        ssize_t written = write(fileDescriptor, cursor, length);

        if (written < 0) {
            if (errno == EINTR)
                continue;

            return -1;
        }

        if (written == 0)
            return -1;

        cursor += written;
        length -= (size_t)written;
    }

    return 0;
}

static void runJobTask(const uint8_t *payload, size_t size) { //TODO: proper function handling scheduling wise
    JobTicket ticket;

    if (size != sizeof(ticket))
        return;

    memcpy(&ticket, payload, sizeof(ticket));

    DataRecord *record = engineFindData(activeEngine, ticket.inputDataId);

    if (!record)
        return;

    JobFunction run = functionLoad(ticket.functionId);

    if (!run)
        return;

    unsigned char *output = malloc(JOB_OUTPUT_CAPACITY);

    if (!output)
        return;

    int64_t produced = run(record->payload, (uint32_t)record->payloadLength, output, JOB_OUTPUT_CAPACITY);

    if (produced >= 0)
        engineSubmitResult(activeEngine, ticket.jobId, ticket.outputDataId, output, (uint64_t)produced);

    free(output);
}

static void promoteReadyJobs(void)
{
    CircularList *pending = &activeEngine->pendingJobs;

    pthread_mutex_lock(&activeEngine->lock);

    JobTicket *ready = pending->count ? malloc(pending->count * sizeof(JobTicket)) : NULL;
    size_t readyCount = 0;

    CircularNode *node = pending->head;

    for (size_t i = 0, total = ready ? pending->count : 0; i < total; i++) {
        PendingJob *job = node->value;

        if (job->state == JOB_STATE_WAITING && engineFindData(activeEngine, job->inputDataId) != NULL && functionIsStored(job->functionId)) {
            ready[readyCount++] = (JobTicket){ .jobId = job->jobId, .inputDataId = job->inputDataId, .functionId = job->functionId, .outputDataId = job->outputDataId };
            job->state = JOB_STATE_RUNNING;
        }

        node = node->next;
    }

    pthread_mutex_unlock(&activeEngine->lock);

    for (size_t i = 0; i < readyCount; i++) {
        threadPoolEnqueue(activeEngine->pool, runJobTask, (const uint8_t *)&ready[i], sizeof(JobTicket));
        printf("job %016llx ready -> queued\n", (unsigned long long)ready[i].jobId);
    }

    free(ready);
}

static int receiveDataObject(int socketFd, const unsigned char *header)
{
    uint64_t dataId = objectId(header);
    uint64_t payloadLength = dataPayloadLength(header);

    if (objectTotalLength(header) != DATA_HEADER_LENGTH + payloadLength)
        return -1;

    if (payloadLength > DATA_MAX_PAYLOAD_LENGTH)
        return -1;

    if (objectStoreFindData(activeEngine->store, dataId) != NULL) {
        unsigned char buffer[TRANSFER_CHUNK];
        uint64_t remainingBytes = payloadLength;

        while (remainingBytes > 0) {
            size_t chunkLength =
                remainingBytes > sizeof(buffer)
                    ? sizeof(buffer)
                    : (size_t)remainingBytes;

            if (readExactBytes(socketFd, buffer, chunkLength) != 0)
                return -1;

            remainingBytes -= chunkLength;
        }

        printf("DATA %016llx already stored\n", (unsigned long long)dataId);

        return 0;
    }

    unsigned char *payload = objectStoreCreateDataPayload(activeEngine->store, dataId, payloadLength);

    if (!payload)
        return -1;

    if (readExactBytes(socketFd, payload, (size_t)payloadLength) != 0)
        return -1;

    printf("DATA %016llx stored: %llu bytes\n", (unsigned long long)dataId, (unsigned long long)payloadLength);

    return 0;
}

static int receiveFunctionObject(int socketFd, const unsigned char *header)
{
    uint64_t functionId = objectId(header);
    uint64_t codeLength = readUint64At(header, FUNCTION_CODE_LENGTH_OFFSET);
    uint32_t abiVersion = readUint32At(header, FUNCTION_ABI_VERSION_OFFSET);

    if (objectTotalLength(header) != FUNCTION_HEADER_LENGTH + codeLength)
        return -1;

    if (codeLength > FUNCTION_MAX_CODE_LENGTH)
        return -1;

    if (abiVersion != ENGINE_ABI_VERSION)
        return -1;

    char path[PATH_MAX];

    functionPath(path, sizeof(path), functionId, "so");

    char partialPath[PATH_MAX + 32];

    snprintf(partialPath, sizeof(partialPath), "%s.%ld.tmp", path, (long)getpid());

    int outputFile = open(partialPath, O_WRONLY | O_CREAT | O_TRUNC, 0755);

    if (outputFile < 0)
        return -1;

    unsigned char buffer[TRANSFER_CHUNK];
    uint64_t remainingBytes = codeLength;

    while (remainingBytes > 0) {
        size_t chunkLength =
            remainingBytes > sizeof(buffer)
                ? sizeof(buffer)
                : (size_t)remainingBytes;

        if (readExactBytes(socketFd, buffer, chunkLength) != 0 ||
            writeExactBytes(outputFile, buffer, chunkLength) != 0) {
            close(outputFile);
            unlink(partialPath);
            return -1;
        }

        remainingBytes -= chunkLength;
    }

    close(outputFile);

    if (rename(partialPath, path) != 0) {
        unlink(partialPath);
        return -1;
    }

    printf("FUNCTION %016llx stored\n", (unsigned long long)functionId);

    return 0;
}

static int receiveJobObject(const unsigned char *header)
{
    if (!isValidJob(header, JOB_HEADER_LENGTH))
        return -1;

    Job job;

    memset(&job, 0, sizeof(job));

    job.jobId = objectId(header);
    job.functionId = jobFunctionId(header);
    job.inputDataId = jobDataId(header);
    job.outputDataId = jobOutputDataId(header);
    job.parentJobId = jobParentId(header);
    job.previousJobId = readUint64At(header, JOB_PREVIOUS_JOB_ID_OFFSET);
    job.nextJobId = readUint64At(header, JOB_NEXT_JOB_ID_OFFSET);
    job.state = jobState(header);
    job.partIndex = jobPartIndex(header);
    job.partCount = jobPartCount(header);
    job.sourceNode = jobSourceNode(header);
    job.destinationNode = jobDestinationNode(header);

    if (objectStoreStoreJob(activeEngine->store, header) != 0)
        return -1;

    PendingJob pending;

    pending.jobId = job.jobId;
    pending.inputDataId = job.inputDataId;
    pending.functionId = job.functionId;
    pending.outputDataId = job.outputDataId;
    pending.state = JOB_STATE_WAITING;

    engineAppendJob(activeEngine, &pending);

    printf("JOB %016llx waiting: data %016llx function %016llx\n", (unsigned long long)job.jobId, (unsigned long long)job.inputDataId, (unsigned long long)job.functionId);

    return 0;
}

static int receiveRequestObject(const unsigned char *header)
{
    Request request;

    memset(&request, 0, sizeof(request));

    request.requestId = objectId(header);
    request.targetId = readUint64At(header, REQUEST_TARGET_ID_OFFSET);
    request.targetType = readUint16At(header, REQUEST_TARGET_TYPE_OFFSET);
    request.status = readUint16At(header, REQUEST_STATUS_OFFSET);
    request.jobId = readUint64At(header, REQUEST_JOB_ID_OFFSET);
    request.sourceNode = readUint32At(header, REQUEST_SOURCE_NODE_OFFSET);
    request.destinationNode = readUint32At(header, REQUEST_DESTINATION_NODE_OFFSET);

    printf("REQUEST %016llx target=%016llx type=%u status=%u\n", (unsigned long long)request.requestId, (unsigned long long)request.targetId, request.targetType, request.status);

    return 0;
}

static int receiveNextObject(int socketFd)
{
    unsigned char header[FUNCTION_HEADER_LENGTH];

    if (readExactBytes(socketFd, header, OBJECT_HEADER_LENGTH) != 0)
        return -1;

    uint16_t type = objectType(header);
    uint32_t headerLength = headerLengthForObjectType(type);

    if (headerLength == 0)
        return -1;

    uint64_t totalLength = objectTotalLength(header);

    if (totalLength < headerLength) {
        return -1;
    }

    uint64_t maxLength;

    switch (type) {
        case OBJECT_TYPE_DATA:
            maxLength = (uint64_t)DATA_HEADER_LENGTH + DATA_MAX_PAYLOAD_LENGTH;
            break;

        case OBJECT_TYPE_FUNCTION:
            maxLength = (uint64_t)FUNCTION_HEADER_LENGTH + FUNCTION_MAX_CODE_LENGTH;
            break;

        case OBJECT_TYPE_JOB:
        case OBJECT_TYPE_REQUEST:
            maxLength = headerLength;
            break;

        default:
            return -1;
    }

    if (totalLength > maxLength)
        return -1;

    if (headerLength > OBJECT_HEADER_LENGTH && readExactBytes(socketFd, header + OBJECT_HEADER_LENGTH, headerLength - OBJECT_HEADER_LENGTH) != 0)
        return -1;

    if (objectMagic(header) != magicForObjectType(type))
        return -1;

    if (objectVersion(header) != ENGINE_VERSION)
        return -1;

    switch (type) {
        case OBJECT_TYPE_DATA:
            return receiveDataObject(socketFd, header);

        case OBJECT_TYPE_FUNCTION:
            return receiveFunctionObject(socketFd, header);

        case OBJECT_TYPE_JOB:
            return receiveJobObject(header);

        case OBJECT_TYPE_REQUEST:
            return receiveRequestObject(header);
    }

    return -1;
}

void receiverServe(int clientSocket)
{
    while (receiveNextObject(clientSocket) == 0)
        promoteReadyJobs();
}

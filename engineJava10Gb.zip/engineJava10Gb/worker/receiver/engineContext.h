#ifndef ENGINE_CONTEXT_H
#define ENGINE_CONTEXT_H

#include <pthread.h>

#include "../contract.h"
#include "../dsa/circularList.h"
#include "../workerPool/threadPool.h"
#include "objectStore.h"

#define DEFAULT_DATASET_DIRECTORY "datasets"

typedef struct {
    uint64_t jobId;
    uint64_t inputDataId;
    uint64_t functionId;
    uint64_t outputDataId;
    uint32_t state;
} PendingJob;

typedef struct {
    uint64_t jobId;
    uint64_t inputDataId;
    uint64_t functionId;
    uint64_t outputDataId;
} JobTicket;

typedef struct {
    ObjectStore *store;
    ObjectStore *outputResultStore;

    CircularList pendingJobs;

    ThreadPool *pool;

    char datasetDirectory[256];

    pthread_mutex_t lock;
} EngineContext;

int engineContextCreate(EngineContext *engine, ObjectStore *store, ObjectStore *outputResultStore, int threadCount);

void engineSetDatasetDirectory(EngineContext *engine, const char *directory);

void engineShutdownPool(EngineContext *engine);

void engineContextDestroy(EngineContext *engine);

void engineAppendJob(EngineContext *engine, const PendingJob *job);

void engineSetJobState(EngineContext *engine, uint64_t jobId, uint32_t state);

int engineReportUnfinishedJobs(EngineContext *engine);

DataRecord *engineFindData(EngineContext *engine, uint64_t dataId);

void engineSubmitResult(EngineContext *engine, uint64_t jobId, uint64_t outputDataId, const unsigned char *payload, uint64_t payloadLength);

#endif

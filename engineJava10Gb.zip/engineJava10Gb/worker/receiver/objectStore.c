#include "objectStore.h"

#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

static void *arenaAllocate(ObjectStore *store, size_t length, size_t alignment)
{
    size_t start =
        (store->dataArenaUsed + alignment - 1)
        & ~(alignment - 1);

    if (start + length < start)
        return NULL;

    if (start + length > store->dataArenaCapacity)
        return NULL;

    store->dataArenaUsed = start + length;

    return store->dataArena + start;
}

int objectStoreCreate(ObjectStore *store, size_t dataArenaCapacity)
{
    memset(store, 0, sizeof(*store));

    store->dataArena = mmap(NULL, dataArenaCapacity, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);

    if (store->dataArena == MAP_FAILED) {
        store->dataArena = NULL;
        return -1;
    }

    store->dataArenaCapacity = dataArenaCapacity;
    store->dataArenaUsed = 0;

    pthread_mutex_init(&store->lock, NULL);

    store->dataBucketCount = DATA_BUCKET_COUNT;
    store->dataBuckets = calloc(store->dataBucketCount, sizeof(DataRecord *));

    store->jobBucketCount = JOB_BUCKET_COUNT;
    store->jobBuckets = calloc(store->jobBucketCount, sizeof(JobRecord *));

    if (!store->dataBuckets || !store->jobBuckets) {
        objectStoreDestroy(store);
        return -1;
    }

    return 0;
}

void objectStoreDestroy(ObjectStore *store)
{

    if (store->dataArena)
        munmap(store->dataArena, store->dataArenaCapacity);

    pthread_mutex_destroy(&store->lock);

    free(store->dataBuckets);
    free(store->jobBuckets);

    memset(store, 0, sizeof(*store));
}

unsigned char *objectStoreCreateDataPayload(ObjectStore *store, uint64_t dataId, uint64_t payloadLength)
{
    if (payloadLength > DATA_MAX_PAYLOAD_LENGTH)
        return NULL;

    pthread_mutex_lock(&store->lock);

    unsigned char *payload = arenaAllocate(store, (size_t)payloadLength, 8);

    if (!payload && payloadLength > 0) {
        pthread_mutex_unlock(&store->lock);
        return NULL;
    }

    DataRecord *record = arenaAllocate(store, sizeof(DataRecord), _Alignof(DataRecord));

    if (!record) {
        pthread_mutex_unlock(&store->lock);
        return NULL;
    }

    record->dataId = dataId;
    record->payloadLength = payloadLength;
    record->payload = payload;

    size_t bucket = (size_t)(dataId % store->dataBucketCount);
    record->next = store->dataBuckets[bucket];
    store->dataBuckets[bucket] = record;

    pthread_mutex_unlock(&store->lock);

    return payload;
}

DataRecord *objectStoreFindData(ObjectStore *store, uint64_t dataId)
{
    size_t bucket = (size_t)(dataId % store->dataBucketCount);

    pthread_mutex_lock(&store->lock);

    for (DataRecord *record = store->dataBuckets[bucket];
         record != NULL;
         record = record->next) {

        if (record->dataId == dataId) {
            pthread_mutex_unlock(&store->lock);
            return record;
        }
    }

    pthread_mutex_unlock(&store->lock);

    return NULL;
}

int objectStoreStoreJob(ObjectStore *store, const void *jobObject)
{
    uint64_t jobId = objectId(jobObject);

    if (objectStoreFindJob(store, jobId) != NULL)
        return 0;

    pthread_mutex_lock(&store->lock);

    JobRecord *record = arenaAllocate(store, sizeof(JobRecord), _Alignof(JobRecord));

    if (!record) {
        pthread_mutex_unlock(&store->lock);
        return -1;
    }

    record->jobId = jobId;

    memcpy(record->serializedJob, jobObject, JOB_HEADER_LENGTH);

    size_t bucket = (size_t)(jobId % store->jobBucketCount);
    record->next = store->jobBuckets[bucket];
    store->jobBuckets[bucket] = record;

    pthread_mutex_unlock(&store->lock);

    return 0;
}

JobRecord *objectStoreFindJob(ObjectStore *store, uint64_t jobId)
{
    size_t bucket = (size_t)(jobId % store->jobBucketCount);

    pthread_mutex_lock(&store->lock);

    for (JobRecord *record = store->jobBuckets[bucket];
         record != NULL;
         record = record->next) {

        if (record->jobId == jobId) {
            pthread_mutex_unlock(&store->lock);
            return record;
        }
    }

    pthread_mutex_unlock(&store->lock);

    return NULL;
}

#include "engineContext.h"

#include "../functionLoader/functionLoader.h"

#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void writeResultFile(EngineContext *engine, uint64_t dataId, const unsigned char *payload, uint64_t payloadLength);

int engineContextCreate(EngineContext *engine, ObjectStore *store, ObjectStore *outputResultStore, int threadCount)
{
    engine->store = store;
    engine->outputResultStore = outputResultStore;

    snprintf(engine->datasetDirectory, sizeof(engine->datasetDirectory), "%s", DEFAULT_DATASET_DIRECTORY);

    circularListInit(&engine->pendingJobs);

    pthread_mutex_init(&engine->lock, NULL);

    engine->pool = createThreadPool(threadCount);

    return engine->pool ? 0 : -1;
}

void engineShutdownPool(EngineContext *engine)
{
    if (engine->pool) {
        destroyThreadPool(engine->pool);
        engine->pool = NULL;
    }
}

void engineSetDatasetDirectory(EngineContext *engine, const char *directory)
{
    snprintf(engine->datasetDirectory, sizeof(engine->datasetDirectory), "%s", directory);
}

void engineContextDestroy(EngineContext *engine)
{
    engineShutdownPool(engine);

    functionUnloadAll();

    circularListDestroy(&engine->pendingJobs);

    pthread_mutex_destroy(&engine->lock);
}

void engineAppendJob(EngineContext *engine, const PendingJob *job) {
    PendingJob *held = malloc(sizeof(PendingJob));

    if (!held)
        return;

    *held = *job;

    pthread_mutex_lock(&engine->lock);
    circularListAppend(&engine->pendingJobs, held);
    pthread_mutex_unlock(&engine->lock);
}

void engineSetJobState(EngineContext *engine, uint64_t jobId, uint32_t state)
{
    pthread_mutex_lock(&engine->lock);

    CircularNode *node = engine->pendingJobs.head;

    for (size_t i = 0, total = engine->pendingJobs.count; i < total; i++) {
        PendingJob *job = node->value;

        if (job->jobId == jobId) {
            job->state = state;
            break;
        }

        node = node->next;
    }

    pthread_mutex_unlock(&engine->lock);
}

int engineReportUnfinishedJobs(EngineContext *engine)
{
    int unfinished = 0;

    pthread_mutex_lock(&engine->lock);

    CircularNode *node = engine->pendingJobs.head;

    for (size_t i = 0, total = engine->pendingJobs.count; i < total; i++) {
        PendingJob *job = node->value;

        if (job->state != JOB_STATE_COMPLETED) {
            printf("  job %016llx %-9s data %016llx function %016llx\n", (unsigned long long)job->jobId, jobStateName(job->state), (unsigned long long)job->inputDataId, (unsigned long long)job->functionId);

            unfinished++;
        }

        node = node->next;
    }

    pthread_mutex_unlock(&engine->lock);

    return unfinished;
}

DataRecord *engineFindData(EngineContext *engine, uint64_t dataId)
{
    DataRecord *record = objectStoreFindData(engine->store, dataId);

    if (record)
        return record;

    return objectStoreFindData(engine->outputResultStore, dataId);
}

static void storeResultPayload(EngineContext *engine, uint64_t dataId, const unsigned char *payload, uint64_t payloadLength)
{
    unsigned char *slot = objectStoreCreateDataPayload(engine->outputResultStore, dataId, payloadLength);

    if (slot)
        memcpy(slot, payload, (size_t)payloadLength);

    writeResultFile(engine, dataId, payload, payloadLength);
}

static void writeResultFile(EngineContext *engine, uint64_t dataId, const unsigned char *payload, uint64_t payloadLength)
{
    char finalPath[512];
    char partialPath[512];

    snprintf(finalPath, sizeof(finalPath), "%s/%016llx.bin", engine->datasetDirectory, (unsigned long long)dataId);
    snprintf(partialPath, sizeof(partialPath), "%s/%016llx.part", engine->datasetDirectory, (unsigned long long)dataId);

    int file = open(partialPath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (file < 0) {
        fprintf(stderr, "[worker] cannot write %s\n", partialPath);
        return;
    }

    const unsigned char *cursor = payload;
    uint64_t remaining = payloadLength;

    while (remaining > 0) {
        ssize_t written = write(file, cursor, (size_t)remaining);
        if (written <= 0) { close(file); return; }
        cursor += written;
        remaining -= (uint64_t)written;
    }

    close(file);

    // the rename is the reply: the result appears whole or not at all
    if (rename(partialPath, finalPath) != 0)
        fprintf(stderr, "[worker] cannot rename %s\n", partialPath);
}

void engineSubmitResult(EngineContext *engine, uint64_t jobId, uint64_t outputDataId, const unsigned char *payload, uint64_t payloadLength)
{
    storeResultPayload(engine, outputDataId, payload, payloadLength);

    printf("job %016llx result -> output store as %016llx (%llu bytes)\n", (unsigned long long)jobId, (unsigned long long)outputDataId, (unsigned long long)payloadLength);

    engineSetJobState(engine, jobId, JOB_STATE_COMPLETED);
}

#ifndef ENGINE_RECEIVER_H
#define ENGINE_RECEIVER_H

#include "engineContext.h"

void receiverAttach(EngineContext *engine);

void receiverServe(int clientSocket);

#endif

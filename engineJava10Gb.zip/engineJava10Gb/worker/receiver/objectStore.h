#ifndef ENGINE_OBJECT_STORE_H
#define ENGINE_OBJECT_STORE_H

#include <pthread.h>
#include <stddef.h>
#include <stdint.h>

#include "../contract.h"

#define DATA_BUCKET_COUNT 1000003u
#define JOB_BUCKET_COUNT  100003u

typedef struct DataRecord {
    uint64_t dataId;
    uint64_t payloadLength;
    unsigned char *payload;
    struct DataRecord *next;
} DataRecord;

typedef struct JobRecord {
    uint64_t jobId;
    unsigned char serializedJob[JOB_HEADER_LENGTH];
    struct JobRecord *next;
} JobRecord;

typedef struct {
    unsigned char *dataArena;
    size_t dataArenaCapacity;
    size_t dataArenaUsed;

    DataRecord **dataBuckets;
    size_t dataBucketCount;

    JobRecord **jobBuckets;
    size_t jobBucketCount;

    pthread_mutex_t lock;
} ObjectStore;

int objectStoreCreate(ObjectStore *store, size_t dataArenaCapacity);

void objectStoreDestroy(ObjectStore *store);

unsigned char *objectStoreCreateDataPayload(ObjectStore *store, uint64_t dataId, uint64_t payloadLength);

DataRecord *objectStoreFindData(ObjectStore *store, uint64_t dataId);

int objectStoreStoreJob(ObjectStore *store, const void *jobObject);

JobRecord *objectStoreFindJob(ObjectStore *store, uint64_t jobId);

#endif

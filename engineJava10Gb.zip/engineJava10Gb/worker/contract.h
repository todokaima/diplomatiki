#ifndef ENGINE_CONTRACT_H
#define ENGINE_CONTRACT_H

#include <errno.h>
#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define ENGINE_VERSION      1u
#define ENGINE_ABI_VERSION  1u

#define OBJECT_HEADER_LENGTH  24u

#define OBJECT_MAGIC_OFFSET         0u
#define OBJECT_VERSION_OFFSET       4u
#define OBJECT_TYPE_OFFSET          6u
#define OBJECT_ID_OFFSET            8u
#define OBJECT_TOTAL_LENGTH_OFFSET  16u

#define OBJECT_TYPE_DATA      1u
#define OBJECT_TYPE_FUNCTION  2u
#define OBJECT_TYPE_JOB       3u
#define OBJECT_TYPE_REQUEST   4u

#define DATA_MAGIC      0xDA7AFEEDu
#define FUNCTION_MAGIC  0xFCDEFEEDu
#define JOB_MAGIC       0x10BFEED0u
#define REQUEST_MAGIC   0x4E9FEED0u

#define DATA_HEADER_LENGTH       56u
#define DATA_MAX_PAYLOAD_LENGTH  (256u << 20)

#define DATA_PAYLOAD_LENGTH_OFFSET  24u
#define DATA_FLAGS_OFFSET           32u
#define DATA_PART_COUNT_OFFSET      36u
#define DATA_PART_LENGTH_OFFSET     40u
#define DATA_PARENT_DATA_ID_OFFSET  48u
#define DATA_PAYLOAD_OFFSET         DATA_HEADER_LENGTH

#define DATA_FLAG_PARALLELIZABLE  0x1u
#define DATA_FLAG_NO_CACHE        0x2u
#define DATA_FLAG_SUB_DATA        0x4u
#define DATA_FLAG_RESULT          0x8u

#define FUNCTION_HEADER_LENGTH      112u
#define FUNCTION_MAX_CODE_LENGTH    (64u << 20)
#define FUNCTION_SYMBOL_MAX_LENGTH  64u

#define FUNCTION_CODE_LENGTH_OFFSET  24u
#define FUNCTION_ABI_VERSION_OFFSET  32u
#define FUNCTION_RESERVED_A_OFFSET   36u
#define FUNCTION_RESERVED_B_OFFSET   40u
#define FUNCTION_SYMBOL_OFFSET       48u
#define FUNCTION_CODE_OFFSET         FUNCTION_HEADER_LENGTH

#define JOB_HEADER_LENGTH  96u

#define JOB_FUNCTION_ID_OFFSET       24u
#define JOB_INPUT_DATA_ID_OFFSET     32u
#define JOB_OUTPUT_DATA_ID_OFFSET    40u
#define JOB_PARENT_JOB_ID_OFFSET     48u
#define JOB_PREVIOUS_JOB_ID_OFFSET   56u
#define JOB_NEXT_JOB_ID_OFFSET       64u
#define JOB_STATE_OFFSET             72u
#define JOB_PART_INDEX_OFFSET        76u
#define JOB_PART_COUNT_OFFSET        80u
#define JOB_SOURCE_NODE_OFFSET       84u
#define JOB_DESTINATION_NODE_OFFSET  88u
#define JOB_FLAGS_OFFSET             92u

#define JOB_FLAG_DEPENDENT           0x1u
#define JOB_FLAG_SHIPPED             0x2u

#define NODE_UNASSIGNED  0xFFFFFFFFu

#define JOB_STATE_CREATED    0u
#define JOB_STATE_WAITING    1u
#define JOB_STATE_READY      2u
#define JOB_STATE_RUNNING    3u
#define JOB_STATE_COMPLETED  4u
#define JOB_STATE_FAILED     5u
#define JOB_STATE_CANCELLED  6u

#define JOB_STATE_SENT       7u

static inline const char *jobStateName(uint32_t state) {
    switch (state) {
        case JOB_STATE_CREATED:   return "created";
        case JOB_STATE_WAITING:   return "waiting";
        case JOB_STATE_READY:     return "ready";
        case JOB_STATE_RUNNING:   return "running";
        case JOB_STATE_COMPLETED: return "completed";
        case JOB_STATE_FAILED:    return "failed";
        case JOB_STATE_CANCELLED: return "cancelled";
        case JOB_STATE_SENT:      return "sent";
        default:            return "unknown state";
    }
}

#define REQUEST_HEADER_LENGTH  56u

#define REQUEST_TARGET_ID_OFFSET         24u
#define REQUEST_TARGET_TYPE_OFFSET       32u
#define REQUEST_STATUS_OFFSET            34u
#define REQUEST_RESERVED_OFFSET          36u
#define REQUEST_JOB_ID_OFFSET            40u
#define REQUEST_SOURCE_NODE_OFFSET       48u
#define REQUEST_DESTINATION_NODE_OFFSET  52u

#define REQUEST_STATUS_PENDING    0u
#define REQUEST_STATUS_NOT_FOUND  1u
#define REQUEST_STATUS_REFUSED    2u
#define REQUEST_STATUS_FAILED     3u
#define REQUEST_STATUS_WAITING    4u

static inline const char *requestStatusName(uint32_t status) {
    switch (status) {
        case REQUEST_STATUS_PENDING:   return "pending";
        case REQUEST_STATUS_NOT_FOUND: return "not found";
        case REQUEST_STATUS_REFUSED:   return "refused";
        case REQUEST_STATUS_FAILED:    return "failed";
        case REQUEST_STATUS_WAITING:   return "waiting";
        default:           return "unknown status";
    }
}

static inline uint16_t readUint16At(const void *object, uint32_t offset) {
    uint16_t value; memcpy(&value, (const unsigned char *)object + offset, 2); return value;
}
static inline uint32_t readUint32At(const void *object, uint32_t offset) {
    uint32_t value; memcpy(&value, (const unsigned char *)object + offset, 4); return value;
}
static inline uint64_t readUint64At(const void *object, uint32_t offset) {
    uint64_t value; memcpy(&value, (const unsigned char *)object + offset, 8); return value;
}
static inline void writeUint16At(void *object, uint32_t offset, uint16_t value) {
    memcpy((unsigned char *)object + offset, &value, 2);
}
static inline void writeUint32At(void *object, uint32_t offset, uint32_t value) {
    memcpy((unsigned char *)object + offset, &value, 4);
}
static inline void writeUint64At(void *object, uint32_t offset, uint64_t value) {
    memcpy((unsigned char *)object + offset, &value, 8);
}
static inline uint64_t alignUpTo8(uint64_t length)  { return (length + 7u) & ~7ull; }
static inline uint64_t alignUpTo16(uint64_t length) { return (length + 15u) & ~15ull; }

static inline uint32_t objectMagic(const void *object) {
    return readUint32At(object, OBJECT_MAGIC_OFFSET);
}
static inline uint16_t objectVersion(const void *object) {
    return readUint16At(object, OBJECT_VERSION_OFFSET);
}
static inline uint16_t objectType(const void *object) {
    return readUint16At(object, OBJECT_TYPE_OFFSET);
}
static inline uint64_t objectId(const void *object) {
    return readUint64At(object, OBJECT_ID_OFFSET);
}
static inline uint64_t objectTotalLength(const void *object) {
    return readUint64At(object, OBJECT_TOTAL_LENGTH_OFFSET);
}

static inline uint32_t magicForObjectType(uint16_t objectTypeCode) {
    switch (objectTypeCode) {
        case OBJECT_TYPE_DATA:     return DATA_MAGIC;
        case OBJECT_TYPE_FUNCTION: return FUNCTION_MAGIC;
        case OBJECT_TYPE_JOB:      return JOB_MAGIC;
        case OBJECT_TYPE_REQUEST:  return REQUEST_MAGIC;
        default:                   return 0u;
    }
}

static inline uint32_t headerLengthForObjectType(uint16_t objectTypeCode) {
    switch (objectTypeCode) {
        case OBJECT_TYPE_DATA:     return DATA_HEADER_LENGTH;
        case OBJECT_TYPE_FUNCTION: return FUNCTION_HEADER_LENGTH;
        case OBJECT_TYPE_JOB:      return JOB_HEADER_LENGTH;
        case OBJECT_TYPE_REQUEST:  return REQUEST_HEADER_LENGTH;
        default:                   return 0u;
    }
}

static inline void writeObjectHeader(void *object, uint16_t objectTypeCode, uint64_t identifier, uint64_t totalLength) {
    writeUint32At(object, OBJECT_MAGIC_OFFSET,        magicForObjectType(objectTypeCode));
    writeUint16At(object, OBJECT_VERSION_OFFSET,      (uint16_t)ENGINE_VERSION);
    writeUint16At(object, OBJECT_TYPE_OFFSET,         objectTypeCode);
    writeUint64At(object, OBJECT_ID_OFFSET,           identifier);
    writeUint64At(object, OBJECT_TOTAL_LENGTH_OFFSET, totalLength);
}

static inline int isValidObject(const void *object, uint64_t availableBytes) {
    if (availableBytes < OBJECT_HEADER_LENGTH)                 return 0;

    uint16_t objectTypeCode = objectType(object);
    uint32_t headerLength   = headerLengthForObjectType(objectTypeCode);
    if (headerLength == 0u)                                    return 0;
    if (objectMagic(object) != magicForObjectType(objectTypeCode)) return 0;
    if (objectVersion(object) != ENGINE_VERSION)               return 0;

    uint64_t totalLength = objectTotalLength(object);
    if (totalLength < headerLength)                            return 0;
    if (totalLength > availableBytes)                          return 0;

    if (objectTypeCode == OBJECT_TYPE_JOB
            && totalLength != JOB_HEADER_LENGTH)               return 0;
    if (objectTypeCode == OBJECT_TYPE_REQUEST
            && totalLength != REQUEST_HEADER_LENGTH)           return 0;
    if (objectTypeCode == OBJECT_TYPE_DATA
            && readUint64At(object, DATA_PAYLOAD_LENGTH_OFFSET)
               != totalLength - DATA_HEADER_LENGTH)            return 0;
    if (objectTypeCode == OBJECT_TYPE_FUNCTION
            && readUint64At(object, FUNCTION_CODE_LENGTH_OFFSET)
               != totalLength - FUNCTION_HEADER_LENGTH)        return 0;
    return 1;
}

static inline uint32_t sha256RotateRight(uint32_t value, unsigned bits) {
    return (value >> bits) | (value << (32u - bits));
}

static inline void sha256Block(uint32_t state[8], const unsigned char block[64]) {
    static const uint32_t K[64] = {
        0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u, 0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
        0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u, 0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
        0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu, 0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
        0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u, 0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
        0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u, 0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
        0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u, 0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
        0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u, 0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
        0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u, 0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u,
    };
    uint32_t w[64];
    for (unsigned i = 0; i < 16; i++)
        w[i] = (uint32_t)block[4 * i] << 24 | (uint32_t)block[4 * i + 1] << 16
             | (uint32_t)block[4 * i + 2] << 8 | (uint32_t)block[4 * i + 3];
    for (unsigned i = 16; i < 64; i++) {
        uint32_t s0 = sha256RotateRight(w[i - 15], 7) ^ sha256RotateRight(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = sha256RotateRight(w[i - 2], 17) ^ sha256RotateRight(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    uint32_t a = state[0], b = state[1], c = state[2], d = state[3];
    uint32_t e = state[4], f = state[5], g = state[6], h = state[7];
    for (unsigned i = 0; i < 64; i++) {
        uint32_t t1 = h + (sha256RotateRight(e, 6) ^ sha256RotateRight(e, 11) ^ sha256RotateRight(e, 25))
                        + ((e & f) ^ (~e & g)) + K[i] + w[i];
        uint32_t t2 = (sha256RotateRight(a, 2) ^ sha256RotateRight(a, 13) ^ sha256RotateRight(a, 22))
                        + ((a & b) ^ (a & c) ^ (b & c));
        h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
    state[4] += e; state[5] += f; state[6] += g; state[7] += h;
}

static inline void sha256(const void *bytes, size_t length, unsigned char digest[32]) {
    uint32_t state[8] = { 0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au,
                          0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u };
    const unsigned char *cursor = (const unsigned char *)bytes;
    size_t remaining = length;
    for (; remaining >= 64; remaining -= 64, cursor += 64)
        sha256Block(state, cursor);

    unsigned char tail[128] = { 0 };
    memcpy(tail, cursor, remaining);
    tail[remaining] = 0x80u;
    size_t tailLength = (remaining < 56) ? 64 : 128;
    uint64_t bitLength = (uint64_t)length * 8u;
    for (unsigned i = 0; i < 8; i++)
        tail[tailLength - 1 - i] = (unsigned char)(bitLength >> (8 * i));
    sha256Block(state, tail);
    if (tailLength == 128) sha256Block(state, tail + 64);

    for (unsigned i = 0; i < 8; i++) {
        digest[4 * i]     = (unsigned char)(state[i] >> 24);
        digest[4 * i + 1] = (unsigned char)(state[i] >> 16);
        digest[4 * i + 2] = (unsigned char)(state[i] >> 8);
        digest[4 * i + 3] = (unsigned char)state[i];
    }
}

static inline uint64_t hashId(const void *bytes, size_t length) {
    unsigned char digest[32];
    sha256(bytes, length, digest);
    uint64_t id = 0;
    for (unsigned i = 0; i < 8; i++) id = (id << 8) | digest[i];
    return id;
}

typedef int64_t (*JobFunction)(const void *payload, uint32_t payloadLength, void *output, uint32_t outputCapacity);

#define JOB_FUNCTION_ENTRY "engineJob"

static inline int writeAllToSocket(int socketFd, const void *buffer, size_t length) {
    const unsigned char *cursor = (const unsigned char *)buffer;
    while (length) {
        ssize_t written = send(socketFd, cursor, length, MSG_NOSIGNAL);
        if (written < 0) { if (errno == EINTR) continue; return -1; }
        if (written == 0) return -1;
        cursor += written; length -= (size_t)written;
    }
    return 0;
}
static inline int readAllFromSocket(int socketFd, void *buffer, size_t length) {
    unsigned char *cursor = (unsigned char *)buffer;
    while (length) {
        ssize_t received = read(socketFd, cursor, length);
        if (received < 0) { if (errno == EINTR) continue; return -1; }
        if (received == 0) return -1;
        cursor += received; length -= (size_t)received;
    }
    return 0;
}

static inline uint64_t jobFunctionId(const void *jobObject) {
    return readUint64At(jobObject, JOB_FUNCTION_ID_OFFSET);
}
static inline uint64_t jobDataId(const void *jobObject) {
    return readUint64At(jobObject, JOB_INPUT_DATA_ID_OFFSET);
}
static inline uint64_t jobParentId(const void *jobObject) {
    return readUint64At(jobObject, JOB_PARENT_JOB_ID_OFFSET);
}
static inline uint32_t jobState(const void *jobObject) {
    return readUint32At(jobObject, JOB_STATE_OFFSET);
}
static inline uint32_t jobPartIndex(const void *jobObject) {
    return readUint32At(jobObject, JOB_PART_INDEX_OFFSET);
}
static inline uint32_t jobPartCount(const void *jobObject) {
    return readUint32At(jobObject, JOB_PART_COUNT_OFFSET);
}
static inline uint32_t jobSourceNode(const void *jobObject) {
    return readUint32At(jobObject, JOB_SOURCE_NODE_OFFSET);
}
static inline uint32_t jobDestinationNode(const void *jobObject) {
    return readUint32At(jobObject, JOB_DESTINATION_NODE_OFFSET);
}

static inline uint64_t dataPayloadLength(const void *dataObject) {
    return readUint64At(dataObject, DATA_PAYLOAD_LENGTH_OFFSET);
}
static inline uint32_t dataFlags(const void *dataObject) {
    return readUint32At(dataObject, DATA_FLAGS_OFFSET);
}
static inline const unsigned char *dataPayload(const void *dataObject) {
    return (const unsigned char *)dataObject + DATA_PAYLOAD_OFFSET;
}
static inline int isValidJob(const void *jobObject, uint64_t availableBytes) {
    return isValidObject(jobObject, availableBytes)
        && objectType(jobObject) == OBJECT_TYPE_JOB;
}

static inline uint64_t jobIdFor(uint64_t functionId, uint64_t inputDataId) {
    unsigned char pair[16];
    writeUint64At(pair, 0, inputDataId);
    writeUint64At(pair, 8, functionId);
    return hashId(pair, sizeof pair);
}

static inline uint64_t jobOutputDataId(const void *jobObject) {
    return readUint64At(jobObject, JOB_OUTPUT_DATA_ID_OFFSET);
}

static inline void setJobState(void *jobObject, uint32_t state) {
    writeUint32At(jobObject, JOB_STATE_OFFSET, state);
}
static inline void setJobDestinationNode(void *jobObject, uint32_t destinationNode) {
    writeUint32At(jobObject, JOB_DESTINATION_NODE_OFFSET, destinationNode);
}

#endif

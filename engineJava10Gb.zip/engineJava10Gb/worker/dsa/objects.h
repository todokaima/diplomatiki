#ifndef ENGINE_DSA_OBJECTS_H
#define ENGINE_DSA_OBJECTS_H

#include <stdint.h>

#include "../contract.h"

typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t type;
    uint64_t objectId;
    uint64_t totalLength;
} ObjectHeader;

typedef struct {
    uint64_t dataId;
    uint64_t payloadLength;
    uint32_t flags;
    uint32_t partCount;
    uint64_t partLength;
    uint64_t parentDataId;

    const unsigned char *payload;
} Data;

typedef struct {
    uint64_t functionId;
    uint64_t codeLength;
    uint32_t abiVersion;

    const unsigned char *code;
} Function;

typedef struct {
    uint64_t jobId;
    uint64_t functionId;
    uint64_t inputDataId;
    uint64_t outputDataId;
    uint64_t parentJobId;
    uint64_t previousJobId;
    uint64_t nextJobId;
    uint32_t state;
    uint32_t partIndex;
    uint32_t partCount;
    uint32_t sourceNode;
    uint32_t destinationNode;
} Job;

typedef struct {
    uint64_t requestId;
    uint64_t targetId;
    uint16_t targetType;
    uint16_t status;
    uint64_t jobId;
    uint32_t sourceNode;
    uint32_t destinationNode;
} Request;

#endif

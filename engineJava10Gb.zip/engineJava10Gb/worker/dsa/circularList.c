#include "circularList.h"

#include <stdlib.h>

void circularListInit(CircularList *list)
{
    list->head = NULL;
    list->count = 0;
}

CircularNode *circularListAppend(CircularList *list, void *value)
{
    CircularNode *node = malloc(sizeof(CircularNode));

    if (!node)
        return NULL;

    node->value = value;

    if (!list->head) {
        node->next = node;
        node->previous = node;
        list->head = node;
    } else {
        CircularNode *last = list->head->previous;

        node->next = list->head;
        node->previous = last;

        last->next = node;
        list->head->previous = node;
    }

    list->count++;

    return node;
}

void *circularListRemove(CircularList *list, CircularNode *node)
{
    void *value = node->value;

    if (list->count == 1) {
        list->head = NULL;
    } else {
        node->previous->next = node->next;
        node->next->previous = node->previous;

        if (list->head == node)
            list->head = node->next;
    }

    list->count--;

    free(node);

    return value;
}

void circularListDestroy(CircularList *list)
{
    CircularNode *node = list->head;

    for (size_t i = 0, total = list->count; i < total; i++) {
        CircularNode *next = node->next;
        free(node);
        node = next;
    }

    list->head = NULL;
    list->count = 0;
}

size_t circularListCount(const CircularList *list)
{
    return list->count;
}

int circularListIsEmpty(const CircularList *list)
{
    return list->head == NULL;
}

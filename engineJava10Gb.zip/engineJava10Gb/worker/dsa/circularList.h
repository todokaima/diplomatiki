#ifndef ENGINE_DSA_CIRCULAR_LIST_H
#define ENGINE_DSA_CIRCULAR_LIST_H

#include <stddef.h>

typedef struct CircularNode {
    void *value;
    struct CircularNode *next;
    struct CircularNode *previous;
} CircularNode;

typedef struct {
    CircularNode *head;
    size_t count;
} CircularList;

void circularListInit(CircularList *list);

CircularNode *circularListAppend(CircularList *list, void *value);

void *circularListRemove(CircularList *list, CircularNode *node);

void circularListDestroy(CircularList *list);

size_t circularListCount(const CircularList *list);

int circularListIsEmpty(const CircularList *list);

#endif

#ifndef ENGINE_FUNCTION_LOADER_H
#define ENGINE_FUNCTION_LOADER_H

#include <stddef.h>
#include <stdint.h>

#include "../contract.h"

#define FUNCTION_DIRECTORY "functions"

void functionPath(char *path, size_t size, uint64_t functionId, const char *extension);

int functionIsStored(uint64_t functionId);

JobFunction functionLoad(uint64_t functionId);

void functionUnloadAll(void);

#endif

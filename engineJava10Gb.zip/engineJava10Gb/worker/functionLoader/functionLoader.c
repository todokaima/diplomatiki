#include "functionLoader.h"

#include <dlfcn.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct LoadedFunction {
    uint64_t functionId;
    void *handle;
    JobFunction run;
    struct LoadedFunction *next;
} LoadedFunction;

static LoadedFunction *loaded;
static pthread_mutex_t loadedLock = PTHREAD_MUTEX_INITIALIZER;

void functionPath(char *path, size_t size, uint64_t functionId, const char *extension)
{
    snprintf(path, size, "%s/%016llx.%s", FUNCTION_DIRECTORY, (unsigned long long)functionId, extension);
}

int functionIsStored(uint64_t functionId)
{
    char path[PATH_MAX];

    functionPath(path, sizeof(path), functionId, "so");

    return access(path, R_OK) == 0;
}

JobFunction functionLoad(uint64_t functionId)
{
    pthread_mutex_lock(&loadedLock);

    for (LoadedFunction *entry = loaded; entry != NULL; entry = entry->next) {
        if (entry->functionId == functionId) {
            JobFunction run = entry->run;
            pthread_mutex_unlock(&loadedLock);
            return run;
        }
    }

    char path[PATH_MAX];
    void *handle = NULL;
    void *address = NULL;
    LoadedFunction *entry = NULL;

    functionPath(path, sizeof(path), functionId, "so");

    if ((handle = dlopen(path, RTLD_NOW | RTLD_LOCAL)) == NULL ||
        (address = dlsym(handle, JOB_FUNCTION_ENTRY)) == NULL ||
        (entry = malloc(sizeof(LoadedFunction))) == NULL) {
        if (handle)
            dlclose(handle);
        pthread_mutex_unlock(&loadedLock);
        return NULL;
    }

    entry->functionId = functionId;
    entry->handle = handle;
    memcpy(&entry->run, &address, sizeof(entry->run));
    entry->next = loaded;
    loaded = entry;

    printf("function %016llx loaded\n", (unsigned long long)functionId);

    JobFunction run = entry->run;

    pthread_mutex_unlock(&loadedLock);

    return run;
}

void functionUnloadAll(void)
{
    pthread_mutex_lock(&loadedLock);

    while (loaded) {
        LoadedFunction *next = loaded->next;
        dlclose(loaded->handle);
        free(loaded);
        loaded = next;
    }

    pthread_mutex_unlock(&loadedLock);
}

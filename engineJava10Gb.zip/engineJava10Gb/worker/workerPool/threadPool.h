#ifndef THREADPOOL_H
#define THREADPOOL_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <pthread.h>

#define QUEUE_CAPACITY 256

typedef void (*TaskHandler)(const uint8_t* data, size_t size);

typedef struct {
    TaskHandler handler;
    uint8_t* payload;
    size_t payloadSize;
} Task;

typedef struct Queue Queue;

struct Queue {
    Task tasks[QUEUE_CAPACITY];
    int top;
    int bottom;
    pthread_mutex_t lock;

    bool (*enqueue)(Queue* self, Task task);
    bool (*dequeue)(Queue* self, Task* outTask);
    bool (*steal)(Queue* self, Task* outTask);
};

Queue* createQueue(void);
void destroyQueue(Queue* q);

typedef struct ThreadPool ThreadPool;
typedef struct Worker Worker;

struct Worker {
    int id;
    ThreadPool* pool;
    Queue* queue;
    pthread_t thread;
};

struct ThreadPool {
    Worker* workers;
    int threadCount;
    bool stop;
    pthread_mutex_t poolLock;
};

ThreadPool* createThreadPool(int threadCount);
void threadPoolEnqueue(ThreadPool* pool, TaskHandler handler, const uint8_t* data, size_t size);
void destroyThreadPool(ThreadPool* pool);

#endif

#include "threadPool.h"

#include <signal.h>
#include <unistd.h>

static _Thread_local Worker* currentWorker = NULL;

static bool queueEnqueue(Queue* self, Task task) {
    pthread_mutex_lock(&self->lock);
    if (self->bottom - self->top >= QUEUE_CAPACITY) {
        pthread_mutex_unlock(&self->lock);
        return false;
    }
    self->tasks[self->bottom % QUEUE_CAPACITY] = task;
    self->bottom++;
    pthread_mutex_unlock(&self->lock);
    return true;
}

static bool queueDequeue(Queue* self, Task* outTask) {
    pthread_mutex_lock(&self->lock);
    if (self->top >= self->bottom) {
        pthread_mutex_unlock(&self->lock);
        return false;
    }
    self->bottom--;
    *outTask = self->tasks[self->bottom % QUEUE_CAPACITY];
    pthread_mutex_unlock(&self->lock);
    return true;
}

static bool queueSteal(Queue* self, Task* outTask) {
    pthread_mutex_lock(&self->lock);
    if (self->top >= self->bottom) {
        pthread_mutex_unlock(&self->lock);
        return false;
    }
    *outTask = self->tasks[self->top % QUEUE_CAPACITY];
    self->top++;
    pthread_mutex_unlock(&self->lock);
    return true;
}

Queue* createQueue(void) {
    Queue* q = (Queue*)malloc(sizeof(Queue));
    if (!q) return NULL;

    q->top = 0;
    q->bottom = 0;
    pthread_mutex_init(&q->lock, NULL);

    q->enqueue = queueEnqueue;
    q->dequeue = queueDequeue;
    q->steal   = queueSteal;

    return q;
}

void destroyQueue(Queue* q) {
    if (!q) return;
    pthread_mutex_destroy(&q->lock);
    free(q);
}

static void* workerRoutine(void* arg) {
    Worker* self = (Worker*)arg;
    currentWorker = self;
    ThreadPool* pool = self->pool;

    sigset_t shutdownSignals;
    sigemptyset(&shutdownSignals);
    sigaddset(&shutdownSignals, SIGINT);
    sigaddset(&shutdownSignals, SIGTERM);
    // signals go to the main thread, to interrupt its accept()/read()
    pthread_sigmask(SIG_BLOCK, &shutdownSignals, NULL);

    while (1) {
        pthread_mutex_lock(&pool->poolLock);
        bool shouldStop = pool->stop;
        pthread_mutex_unlock(&pool->poolLock);

        Task task;
        bool foundTask = false;

        if (self->queue->dequeue(self->queue, &task)) {
            foundTask = true;
        } else {
            for (int i = 0; i < pool->threadCount; i++) {
                if (i == self->id) continue;
                if (pool->workers[i].queue->steal(pool->workers[i].queue, &task)) {
                    foundTask = true;
                    break;
                }
            }
        }

        if (foundTask) {
            task.handler(task.payload, task.payloadSize);
            free(task.payload);
        } else {
            if (shouldStop) break;
            struct timespec req = {0, 5000000};
            nanosleep(&req, NULL);
        }
    }
    return NULL;
}

ThreadPool* createThreadPool(int threadCount) {
    ThreadPool* pool = (ThreadPool*)malloc(sizeof(ThreadPool));
    if (!pool) return NULL;

    pool->threadCount = threadCount;
    pool->stop = false;
    pthread_mutex_init(&pool->poolLock, NULL);

    pool->workers = (Worker*)calloc((size_t)threadCount, sizeof(Worker));
    if (!pool->workers) { free(pool); return NULL; }

    for (int i = 0; i < threadCount; i++) {
        pool->workers[i].id = i;
        pool->workers[i].pool = pool;
        pool->workers[i].queue = createQueue();
        if (!pool->workers[i].queue) { destroyThreadPool(pool); return NULL; }
    }

    for (int i = 0; i < threadCount; i++) {
        pthread_create(&pool->workers[i].thread, NULL, workerRoutine, &pool->workers[i]);
    }

    return pool;
}

void threadPoolEnqueue(ThreadPool* pool, TaskHandler handler, const uint8_t* data, size_t size) {
    Task task;
    task.handler = handler;
    task.payloadSize = size;
    task.payload = (uint8_t*)malloc(size);
    if (!task.payload) return;
    memcpy(task.payload, data, size);

    Worker* target = currentWorker;
    if (!target) {
        static int roundRobin = 0;
        target = &pool->workers[roundRobin % pool->threadCount];
        roundRobin++;
    }

    if (target->queue->enqueue(target->queue, task)) return;

    for (;;) {
        for (int i = 0; i < pool->threadCount; i++) {
            if (pool->workers[i].queue->enqueue(pool->workers[i].queue, task)) return;
        }
        usleep(100);
    }
}

void destroyThreadPool(ThreadPool* pool) {
    pthread_mutex_lock(&pool->poolLock);
    pool->stop = true;
    pthread_mutex_unlock(&pool->poolLock);

    for (int i = 0; i < pool->threadCount; i++) {
        if (pool->workers[i].thread) pthread_join(pool->workers[i].thread, NULL);
    }

    for (int i = 0; i < pool->threadCount; i++) {
        destroyQueue(pool->workers[i].queue);
    }

    pthread_mutex_destroy(&pool->poolLock);
    free(pool->workers);
    free(pool);
}

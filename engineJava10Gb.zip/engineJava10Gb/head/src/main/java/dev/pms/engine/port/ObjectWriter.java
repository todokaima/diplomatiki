package dev.pms.engine.port;

import dev.pms.engine.domain.EngineObject;

import java.io.Closeable;
import java.io.IOException;

public interface ObjectWriter extends Closeable {

    void write(EngineObject object) throws IOException;

    default void flush() throws IOException { }

    @Override
    default void close() throws IOException { }
}

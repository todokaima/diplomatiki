package dev.pms.engine.adapter.in;

import dev.pms.engine.adapter.out.file.LocalArtifactCatalog;
import dev.pms.engine.adapter.out.log.EventLog;
import dev.pms.engine.port.ArtifactCatalog;

import java.io.IOException;
import java.nio.file.Path;

public final class JobServerCli {

    public static void main(String[] args) {
        int port = 9099;
        String node = null;
        String functionDirectory = LocalArtifactCatalog.DEFAULT_FUNCTION_DIRECTORY;
        String datasetDirectory = LocalArtifactCatalog.DEFAULT_DATASET_DIRECTORY;
        String etcdEndpoints = null;
        String nodeId = "node";
        String advertise = null;
        String peer = null;
        String logFile = null;
        boolean spread = false;
        String bind = null;
        String dataBind = null;
        int dataPort = 0;
        String peerData = null;
        int socketBuffer = 0;
        int maxSlots = Runtime.getRuntime().availableProcessors();

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--port"      -> port = Integer.parseInt(args[++i]);
                case "--node"      -> node = args[++i];
                case "--functions" -> functionDirectory = args[++i];
                case "--datasets"  -> datasetDirectory = args[++i];
                case "--etcd"      -> etcdEndpoints = args[++i];
                case "--node-id"   -> nodeId = args[++i];
                case "--advertise" -> advertise = args[++i];
                case "--peer"      -> peer = args[++i];
                case "--slots"     -> maxSlots = Integer.parseInt(args[++i]);
                case "--log"       -> logFile = args[++i];
                case "--spread"    -> spread = true;
                case "--bind"      -> bind = args[++i];
                case "--data-bind" -> dataBind = args[++i];
                case "--data-port" -> dataPort = Integer.parseInt(args[++i]);
                case "--peer-data" -> peerData = args[++i];
                case "--socket-buffer" -> socketBuffer = Integer.parseInt(args[++i]);
                default -> {
                    System.err.println("[jobserver] unknown argument: " + args[i]);
                    System.exit(1);
                }
            }
        }

        ArtifactCatalog catalog = new LocalArtifactCatalog(functionDirectory, datasetDirectory);
        EventLog log = new EventLog(nodeId, logFile == null ? null : Path.of(logFile));

        if (advertise == null) advertise = "127.0.0.1:" + port;

        try {
            HeadRuntime head = new HeadRuntime(nodeId, catalog, node, etcdEndpoints, advertise, maxSlots, peer, spread, log);

            head.splitChannels(bind, dataBind, peerData, socketBuffer);
            head.listen(port);
            if (dataPort > 0) head.listenData(dataPort);
            head.start();
            log.event("serving, functions=%s datasets=%s", functionDirectory, datasetDirectory);

            while (true)
                Thread.sleep(Long.MAX_VALUE);

        } catch (IOException | InterruptedException e) {
            System.err.println("[jobserver] " + e.getMessage());
            System.exit(1);
        }
    }
}

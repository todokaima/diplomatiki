package dev.pms.engine.domain;

import java.nio.ByteBuffer;

public final class RequestObject extends EngineObject {

    RequestObject(byte[] bytes, int offset) { super(bytes, offset); }

    public long targetId()        { return buffer.getLong(offset + Wire.REQUEST_TARGET_ID_OFFSET); }
    public int  targetType()      { return buffer.getShort(offset + Wire.REQUEST_TARGET_TYPE_OFFSET) & 0xFFFF; }
    public int  status()          { return buffer.getShort(offset + Wire.REQUEST_STATUS_OFFSET) & 0xFFFF; }
    public long jobId()           { return buffer.getLong(offset + Wire.REQUEST_JOB_ID_OFFSET); }
    public int  sourceNode()      { return buffer.getInt(offset + Wire.REQUEST_SOURCE_NODE_OFFSET); }
    public int  destinationNode() { return buffer.getInt(offset + Wire.REQUEST_DESTINATION_NODE_OFFSET); }

    public boolean answered() { return status() == Wire.REQUEST_STATUS_PENDING; }

    public static RequestObject forData(Ids.DataId dataId) {
        return builder().target(Wire.OBJECT_TYPE_DATA, dataId.value()).build();
    }

    public static RequestObject forFunction(Ids.FunctionId functionId) {
        return builder().target(Wire.OBJECT_TYPE_FUNCTION, functionId.value()).build();
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private int targetType = Wire.OBJECT_TYPE_DATA;
        private long targetId;
        private Long id;
        private int status = Wire.REQUEST_STATUS_PENDING;
        private long jobId;
        private int sourceNode;
        private int destinationNode;

        public Builder target(int type, long id)   { this.targetType = type; this.targetId = id; return this; }
        public Builder id(long id)                 { this.id = id; return this; }
        public Builder status(int status)          { this.status = status; return this; }
        public Builder forJob(Ids.JobId jobId)     { this.jobId = jobId.value(); return this; }
        public Builder sourceNode(int node)        { this.sourceNode = node; return this; }
        public Builder destinationNode(int node)   { this.destinationNode = node; return this; }

        public RequestObject build() {
            long requestId = (id != null) ? id : Ids.requestId(targetType, targetId, jobId);

            ByteBuffer buffer = allocate(Wire.REQUEST_HEADER_LENGTH, Wire.OBJECT_TYPE_REQUEST, requestId);
            buffer.putLong(Wire.REQUEST_TARGET_ID_OFFSET, targetId);
            buffer.putShort(Wire.REQUEST_TARGET_TYPE_OFFSET, (short) targetType);
            buffer.putShort(Wire.REQUEST_STATUS_OFFSET, (short) status);
            buffer.putLong(Wire.REQUEST_JOB_ID_OFFSET, jobId);
            buffer.putInt(Wire.REQUEST_SOURCE_NODE_OFFSET, sourceNode);
            buffer.putInt(Wire.REQUEST_DESTINATION_NODE_OFFSET, destinationNode);
            return new RequestObject(buffer.array(), 0);
        }
    }
}

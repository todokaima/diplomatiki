package dev.pms.engine.service;

import dev.pms.engine.domain.*;
import dev.pms.engine.port.ObjectWriter;
import dev.pms.engine.port.RawSource;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public final class JobSubmitter {

    private final RawSource raw;
    private final ObjectWriter writer;
    private final Set<Long> functionsSent = new HashSet<>();

    public JobSubmitter(RawSource raw, ObjectWriter writer) {
        this.raw = raw;
        this.writer = writer;
    }

    public JobSubmitter(ObjectWriter writer) {
        this(null, writer);
    }

    public JobObject submit(String soPath, String payloadPath) throws IOException {
        requireRawSource();
        return submit(FunctionObject.of(raw.read(soPath)), DataObject.of(raw.read(payloadPath)));
    }

    public JobObject submit(String soPath, byte[] payload) throws IOException {
        requireRawSource();
        return submit(FunctionObject.of(raw.read(soPath)), DataObject.of(payload));
    }

    public JobObject submit(FunctionObject function, DataObject data) throws IOException {
        JobObject job = JobObject.of(function.functionId(), data.dataId());
        submit(function, data, job);
        return job;
    }

    public synchronized void submit(FunctionObject function, DataObject data, JobObject job) throws IOException {
        if (functionsSent.add(function.id()))
            writer.write(function);

        writer.write(data);
        writer.write(job);
    }

    public synchronized void send(EngineObject object) throws IOException {
        writer.write(object);
    }

    public synchronized void request(RequestObject request) throws IOException {
        writer.write(request);
    }

    private void requireRawSource() {
        if (raw == null)
            throw new IllegalStateException("this submitter was built without a RawSource; pass objects that are already built");
    }

    public synchronized void flush() throws IOException {
        writer.flush();
    }
}

package dev.pms.engine.port;

import dev.pms.engine.domain.DataObject;
import dev.pms.engine.domain.FunctionObject;
import dev.pms.engine.domain.Ids;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public interface ArtifactCatalog {

    Optional<FunctionObject> function(Ids.FunctionId id) throws IOException;

    Optional<DataObject> data(Ids.DataId id) throws IOException;

    boolean hasFunction(Ids.FunctionId id);

    boolean hasData(Ids.DataId id);

    void refresh() throws IOException;

    List<Ids.DataId> readyData() throws IOException;

    void store(FunctionObject function) throws IOException;

    void store(DataObject data) throws IOException;
}

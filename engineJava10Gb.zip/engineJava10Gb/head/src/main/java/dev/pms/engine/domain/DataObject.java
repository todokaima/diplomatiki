package dev.pms.engine.domain;

import java.nio.ByteBuffer;
import java.util.Arrays;

public final class DataObject extends EngineObject {

    DataObject(byte[] bytes, int offset) { super(bytes, offset); }

    public long payloadLength() { return buffer.getLong(offset + Wire.DATA_PAYLOAD_LENGTH_OFFSET); }
    public int  flags()         { return buffer.getInt(offset + Wire.DATA_FLAGS_OFFSET); }
    public int  partCount()     { return buffer.getInt(offset + Wire.DATA_PART_COUNT_OFFSET); }
    public long partLength()    { return buffer.getLong(offset + Wire.DATA_PART_LENGTH_OFFSET); }
    public long parentDataId()  { return buffer.getLong(offset + Wire.DATA_PARENT_DATA_ID_OFFSET); }

    public Ids.DataId dataId() { return new Ids.DataId(id()); }

    public boolean parallelizable() { return (flags() & Wire.DATA_FLAG_PARALLELIZABLE) != 0; }
    public boolean subData()        { return (flags() & Wire.DATA_FLAG_SUB_DATA) != 0; }
    public boolean result()         { return (flags() & Wire.DATA_FLAG_RESULT) != 0; }

    public int payloadOffset() { return offset + Wire.DATA_PAYLOAD_OFFSET; }

    public byte[] payload() {
        int start = payloadOffset();
        return Arrays.copyOfRange(bytes, start, start + (int) payloadLength());
    }

    public static DataObject of(byte[] payload) {
        return builder().payload(payload).build();
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private byte[] payload = new byte[0];
        private Long id;
        private int flags;
        private static final int WHOLE = 1;

        public Builder payload(byte[] payload)   { this.payload = payload; return this; }
        public Builder id(long id)               { this.id = id; return this; }
        public Builder flags(int flags)          { this.flags = flags; return this; }
        public Builder flag(int flag)            { this.flags |= flag; return this; }

        public DataObject build() {
            int totalLength = Wire.DATA_HEADER_LENGTH + payload.length;
            long dataId = (id != null) ? id : Ids.DataId.of(payload).value();

            ByteBuffer buffer = allocate(totalLength, Wire.OBJECT_TYPE_DATA, dataId);
            buffer.putLong(Wire.DATA_PAYLOAD_LENGTH_OFFSET, payload.length);
            buffer.putInt(Wire.DATA_FLAGS_OFFSET, flags);
            buffer.putInt(Wire.DATA_PART_COUNT_OFFSET, WHOLE);
            buffer.putLong(Wire.DATA_PART_LENGTH_OFFSET, payload.length);
            buffer.putLong(Wire.DATA_PARENT_DATA_ID_OFFSET, 0L);

            byte[] object = buffer.array();
            System.arraycopy(payload, 0, object, Wire.DATA_PAYLOAD_OFFSET, payload.length);
            return new DataObject(object, 0);
        }
    }
}

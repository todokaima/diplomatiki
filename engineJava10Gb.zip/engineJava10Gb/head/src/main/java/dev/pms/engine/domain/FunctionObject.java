package dev.pms.engine.domain;

import java.nio.ByteBuffer;
import java.util.Arrays;

public final class FunctionObject extends EngineObject {

    FunctionObject(byte[] bytes, int offset) { super(bytes, offset); }

    public long codeLength() { return buffer.getLong(offset + Wire.FUNCTION_CODE_LENGTH_OFFSET); }
    public int  abiVersion() { return buffer.getInt(offset + Wire.FUNCTION_ABI_VERSION_OFFSET); }

    public Ids.FunctionId functionId() { return new Ids.FunctionId(id()); }

    public int codeOffset() { return offset + Wire.FUNCTION_CODE_OFFSET; }

    public byte[] code() {
        int start = codeOffset();
        return Arrays.copyOfRange(bytes, start, start + (int) codeLength());
    }

    public static FunctionObject of(byte[] code) {
        return builder().code(code).build();
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private byte[] code = new byte[0];
        private Long id;
        private int abiVersion = Wire.ENGINE_ABI_VERSION;

        public Builder code(byte[] code)         { this.code = code; return this; }
        public Builder id(long id)               { this.id = id; return this; }
        public Builder abiVersion(int version)   { this.abiVersion = version; return this; }

        public FunctionObject build() {
            int totalLength = Wire.FUNCTION_HEADER_LENGTH + code.length;
            long functionId = (id != null) ? id : Ids.FunctionId.of(code).value();

            ByteBuffer buffer = allocate(totalLength, Wire.OBJECT_TYPE_FUNCTION, functionId);
            buffer.putLong(Wire.FUNCTION_CODE_LENGTH_OFFSET, code.length);
            buffer.putInt(Wire.FUNCTION_ABI_VERSION_OFFSET, abiVersion);

            byte[] object = buffer.array();
            System.arraycopy(code, 0, object, Wire.FUNCTION_CODE_OFFSET, code.length);
            return new FunctionObject(object, 0);
        }
    }
}

// generated from worker/contract.h: keep the two in step
package dev.pms.engine.domain;

public final class Wire {
    private Wire() {}

    public static final int ENGINE_VERSION     = 1;
    public static final int ENGINE_ABI_VERSION = 1;

    public static final int OBJECT_HEADER_LENGTH       = 24;
    public static final int OBJECT_MAGIC_OFFSET        = 0;
    public static final int OBJECT_VERSION_OFFSET      = 4;
    public static final int OBJECT_TYPE_OFFSET         = 6;
    public static final int OBJECT_ID_OFFSET           = 8;
    public static final int OBJECT_TOTAL_LENGTH_OFFSET = 16;

    public static final int OBJECT_TYPE_DATA     = 1;
    public static final int OBJECT_TYPE_FUNCTION = 2;
    public static final int OBJECT_TYPE_JOB      = 3;
    public static final int OBJECT_TYPE_REQUEST  = 4;

    public static final int DATA_MAGIC     = 0xDA7AFEED;
    public static final int FUNCTION_MAGIC = 0xFCDEFEED;
    public static final int JOB_MAGIC      = 0x10BFEED0;
    public static final int REQUEST_MAGIC  = 0x4E9FEED0;

    public static final int DATA_HEADER_LENGTH         = 56;
    public static final int DATA_MAX_PAYLOAD_LENGTH    = 268435456;
    public static final int DATA_PAYLOAD_LENGTH_OFFSET = 24;
    public static final int DATA_FLAGS_OFFSET          = 32;
    public static final int DATA_PART_COUNT_OFFSET     = 36;
    public static final int DATA_PART_LENGTH_OFFSET    = 40;
    public static final int DATA_PARENT_DATA_ID_OFFSET = 48;
    public static final int DATA_PAYLOAD_OFFSET        = 56;
    public static final int DATA_FLAG_PARALLELIZABLE   = 1;
    public static final int DATA_FLAG_NO_CACHE         = 2;
    public static final int DATA_FLAG_SUB_DATA         = 4;
    public static final int DATA_FLAG_RESULT           = 8;

    public static final int FUNCTION_HEADER_LENGTH      = 112;
    public static final int FUNCTION_MAX_CODE_LENGTH    = 67108864;
    public static final int FUNCTION_SYMBOL_MAX_LENGTH  = 64;
    public static final int FUNCTION_CODE_LENGTH_OFFSET = 24;
    public static final int FUNCTION_ABI_VERSION_OFFSET = 32;
    public static final int FUNCTION_SYMBOL_OFFSET      = 48;
    public static final int FUNCTION_CODE_OFFSET        = 112;

    public static final int JOB_HEADER_LENGTH           = 96;
    public static final int JOB_FUNCTION_ID_OFFSET      = 24;
    public static final int JOB_INPUT_DATA_ID_OFFSET    = 32;
    public static final int JOB_OUTPUT_DATA_ID_OFFSET   = 40;
    public static final int JOB_PARENT_JOB_ID_OFFSET    = 48;
    public static final int JOB_PREVIOUS_JOB_ID_OFFSET  = 56;
    public static final int JOB_NEXT_JOB_ID_OFFSET      = 64;
    public static final int JOB_STATE_OFFSET            = 72;
    public static final int JOB_PART_INDEX_OFFSET       = 76;
    public static final int JOB_PART_COUNT_OFFSET       = 80;
    public static final int JOB_SOURCE_NODE_OFFSET      = 84;
    public static final int JOB_DESTINATION_NODE_OFFSET = 88;
    public static final int JOB_FLAGS_OFFSET            = 92;
    public static final int JOB_FLAG_DEPENDENT          = 1;
    public static final int JOB_FLAG_SHIPPED            = 2;
    public static final int NODE_UNASSIGNED             = 0xFFFFFFFF;

    public static final int JOB_STATE_CREATED   = 0;
    public static final int JOB_STATE_WAITING   = 1;
    public static final int JOB_STATE_READY     = 2;
    public static final int JOB_STATE_RUNNING   = 3;
    public static final int JOB_STATE_COMPLETED = 4;
    public static final int JOB_STATE_FAILED    = 5;
    public static final int JOB_STATE_CANCELLED = 6;
    public static final int JOB_STATE_SENT      = 7;

    public static final int REQUEST_HEADER_LENGTH           = 56;
    public static final int REQUEST_TARGET_ID_OFFSET        = 24;
    public static final int REQUEST_TARGET_TYPE_OFFSET      = 32;
    public static final int REQUEST_STATUS_OFFSET           = 34;
    public static final int REQUEST_JOB_ID_OFFSET           = 40;
    public static final int REQUEST_SOURCE_NODE_OFFSET      = 48;
    public static final int REQUEST_DESTINATION_NODE_OFFSET = 52;
    public static final int REQUEST_STATUS_PENDING          = 0;
    public static final int REQUEST_STATUS_NOT_FOUND        = 1;
    public static final int REQUEST_STATUS_REFUSED          = 2;
    public static final int REQUEST_STATUS_FAILED           = 3;
    public static final int REQUEST_STATUS_WAITING          = 4;
}

package dev.pms.engine.port;

import java.io.IOException;

public interface RawSource {

    byte[] read(String reference) throws IOException;
}

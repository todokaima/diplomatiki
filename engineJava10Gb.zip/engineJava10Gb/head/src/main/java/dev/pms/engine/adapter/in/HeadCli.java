package dev.pms.engine.adapter.in;

import dev.pms.engine.adapter.out.file.FileRawSource;
import dev.pms.engine.adapter.out.stream.ObjectDestination;
import dev.pms.engine.domain.*;
import dev.pms.engine.port.ObjectWriter;
import dev.pms.engine.port.RawSource;
import dev.pms.engine.service.JobSubmitter;

public final class HeadCli {


    public static void main(String[] args) {
        String destination = "engine.sock";
        String soPath = null;
        String payloadPath = null;
        boolean jobOnly = false;

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--to", "--node", "--socket" -> destination = args[++i];
                case "--job-only"         -> jobOnly = true;
                case "--so"               -> soPath = args[++i];
                case "--data"             -> payloadPath = args[++i];
                default -> {
                    System.err.println("[head] unknown argument: " + args[i]);
                    System.exit(1);
                }
            }
        }

        if (soPath == null || payloadPath == null) {
            System.err.println("usage: head --so <path> --data <path> [--to <socket|host:port|file|pipe:path>] [--job-only]");
            System.exit(1);
        }

        RawSource raw = new FileRawSource();

        try (ObjectWriter writer = ObjectDestination.open(destination)) {
            JobSubmitter submitter = new JobSubmitter(raw, writer);

            FunctionObject function = FunctionObject.of(raw.read(soPath));
            byte[] payload = raw.read(payloadPath);

            System.out.printf("[head] %s -> %s (%s)%n", soPath, destination, ObjectDestination.describe(destination));
            System.out.printf("  function %s  %d B%n", function.functionId(), function.codeLength());

            DataObject data = DataObject.of(payload);
            JobObject job = JobObject.of(function.functionId(), data.dataId());

            if (jobOnly) {
                submitter.send(job);
            } else {
                submitter.submit(function, data, job);
            }

            System.out.printf("  data     %s  %d B%n", data.dataId(), data.payloadLength());
            System.out.printf("  job      %s  -> output %016x%s%n", job.jobId(), job.outputDataId(), jobOnly ? "   (job only, 96 B)" : "");

            submitter.flush();
            System.out.println(jobOnly ? "[head] job sent; whoever reads it resolves the ids itself" : "[head] submitted; results stay on the node");

        } catch (Exception e) {
            System.err.println("[head] " + e.getMessage());
            System.exit(1);
        }
    }
}

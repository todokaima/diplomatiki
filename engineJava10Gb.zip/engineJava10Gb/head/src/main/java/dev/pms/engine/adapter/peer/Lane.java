package dev.pms.engine.adapter.peer;

import dev.pms.engine.adapter.out.log.EventLog;

import java.io.IOException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

final class Lane {

    interface Task {
        void run() throws IOException;
    }

    private final BlockingQueue<Task> queue;
    private final EventLog log;
    private final Thread thread;

    Lane(String name, int capacity, EventLog log) {
        this.queue = new ArrayBlockingQueue<>(capacity);
        this.log = log;
        this.thread = new Thread(this::drain, name);
        thread.setDaemon(true);
        thread.start();
    }

    void put(Task task) throws InterruptedException { queue.put(task); }

    int backlog() { return queue.size(); }

    void stop() { thread.interrupt(); }

    private void drain() {
        try {
            while (true) {
                Task task = queue.take();
                try {
                    task.run();
                } catch (IOException | RuntimeException failed) {
                    log.event("%s: %s", thread.getName(), failed.getMessage());
                }
            }
        } catch (InterruptedException stopping) {
        }
    }
}

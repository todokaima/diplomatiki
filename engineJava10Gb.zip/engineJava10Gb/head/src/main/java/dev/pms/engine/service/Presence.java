package dev.pms.engine.service;

import dev.pms.engine.port.ArtifactCatalog;
import dev.pms.engine.port.ClusterDirectory;
import dev.pms.engine.port.LoadSampler;

import java.io.IOException;

public final class Presence {

    private final String nodeId;
    private final String advertise;
    private final int maxSlots;
    private final ClusterDirectory cluster;
    private final ArtifactCatalog catalog;
    private final LoadSampler sampler;

    public Presence(String nodeId, String advertise, int maxSlots, ClusterDirectory cluster, ArtifactCatalog catalog, LoadSampler sampler) {
        this.nodeId = nodeId;
        this.advertise = advertise;
        this.maxSlots = maxSlots;
        this.cluster = cluster;
        this.catalog = catalog;
        this.sampler = sampler;
    }

    public int publish() throws IOException {
        sampler.sample();
        cluster.publishLoad(sampler.reading(nodeId, 0, maxSlots, advertise));
        return cluster.publishReadyData(nodeId, catalog.readyData());
    }
}

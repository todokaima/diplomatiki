package dev.pms.engine.service;

import dev.pms.engine.domain.NodeLoad;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class PeerChooser {

    private final double busyAbove;
    private final double margin;

    public PeerChooser() { this(0.70, 0.20); }

    public PeerChooser(double busyAbove, double margin) {
        this.busyAbove = busyAbove;
        this.margin = margin;
    }

    public Optional<NodeLoad> choose(String myself, double myLoad, Map<String, NodeLoad> cluster) {
        if (myLoad < busyAbove) return Optional.empty();

        NodeLoad lightest = null;

        for (NodeLoad peer : cluster.values()) {
            if (peer.nodeId().equals(myself)) continue;
            if (!peer.hasRoom()) continue;
            if (peer.load() > myLoad - margin) continue;

            if (lightest == null || peer.load() < lightest.load()) lightest = peer;
        }

        return Optional.ofNullable(lightest);
    }

    public Optional<NodeLoad> spread(String myself, Map<String, NodeLoad> cluster, long turn) {
        List<NodeLoad> candidates = new ArrayList<>();

        for (NodeLoad node : cluster.values())
            if (node.hasRoom() || node.nodeId().equals(myself)) candidates.add(node);

        if (candidates.isEmpty()) return Optional.empty();

        candidates.sort(Comparator.comparing(NodeLoad::nodeId));

        NodeLoad chosen = candidates.get(Math.floorMod(turn, candidates.size()));
        return chosen.nodeId().equals(myself) ? Optional.empty() : Optional.of(chosen);
    }
}

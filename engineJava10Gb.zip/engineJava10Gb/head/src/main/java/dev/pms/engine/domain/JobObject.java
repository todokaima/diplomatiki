package dev.pms.engine.domain;

import java.nio.ByteBuffer;

public final class JobObject extends EngineObject {

    JobObject(byte[] bytes, int offset) { super(bytes, offset); }

    public long functionId()      { return buffer.getLong(offset + Wire.JOB_FUNCTION_ID_OFFSET); }
    public long inputDataId()     { return buffer.getLong(offset + Wire.JOB_INPUT_DATA_ID_OFFSET); }
    public long outputDataId()    { return buffer.getLong(offset + Wire.JOB_OUTPUT_DATA_ID_OFFSET); }
    public long parentJobId()     { return buffer.getLong(offset + Wire.JOB_PARENT_JOB_ID_OFFSET); }
    public long previousJobId()   { return buffer.getLong(offset + Wire.JOB_PREVIOUS_JOB_ID_OFFSET); }
    public long nextJobId()       { return buffer.getLong(offset + Wire.JOB_NEXT_JOB_ID_OFFSET); }
    public int  state()           { return buffer.getInt(offset + Wire.JOB_STATE_OFFSET); }
    public int  partIndex()       { return buffer.getInt(offset + Wire.JOB_PART_INDEX_OFFSET); }
    public int  partCount()       { return buffer.getInt(offset + Wire.JOB_PART_COUNT_OFFSET); }
    public int  sourceNode()      { return buffer.getInt(offset + Wire.JOB_SOURCE_NODE_OFFSET); }
    public int  destinationNode() { return buffer.getInt(offset + Wire.JOB_DESTINATION_NODE_OFFSET); }
    public int  flags()           { return buffer.getInt(offset + Wire.JOB_FLAGS_OFFSET); }

    public Ids.JobId jobId()          { return new Ids.JobId(id()); }
    public Ids.DataId outputData()    { return new Ids.DataId(outputDataId()); }
    public boolean isPart()           { return parentJobId() != 0L; }
    public boolean placed()           { return destinationNode() != Wire.NODE_UNASSIGNED; }
    public boolean dependent()        { return (flags() & Wire.JOB_FLAG_DEPENDENT) != 0; }
    public boolean shipped()          { return (flags() & Wire.JOB_FLAG_SHIPPED) != 0; }

    // flags are not part of the id
    public JobObject asShipped() {
        byte[] copy = toBytes().clone();
        Bytes.wrapLittleEndian(copy).putInt(Wire.JOB_FLAGS_OFFSET, flags() | Wire.JOB_FLAG_SHIPPED);
        return new JobObject(copy, 0);
    }

    public static JobObject of(Ids.FunctionId functionId, Ids.DataId inputDataId) {
        return builder().function(functionId).input(inputDataId).build();
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private long functionId;
        private long inputDataId;
        private Long id;
        private Long outputDataId;
        private long previousJobId;
        private long nextJobId;
        private int state = Wire.JOB_STATE_CREATED;
        private static final int WHOLE = 1;
        private int sourceNode;
        private int destinationNode;
        private int flags;

        public Builder function(Ids.FunctionId functionId) { this.functionId = functionId.value(); return this; }
        public Builder input(Ids.DataId inputDataId)       { this.inputDataId = inputDataId.value(); return this; }
        public Builder id(long id)                         { this.id = id; return this; }
        public Builder output(Ids.DataId outputDataId)     { this.outputDataId = outputDataId.value(); return this; }
        public Builder previous(Ids.JobId previous)        { this.previousJobId = previous.value(); return this; }
        public Builder next(Ids.JobId next)                { this.nextJobId = next.value(); return this; }
        public Builder state(int state)                    { this.state = state; return this; }
        public Builder sourceNode(int node)                { this.sourceNode = node; return this; }
        public Builder destinationNode(int node)           { this.destinationNode = node; return this; }
        public Builder dependent()                         { this.flags |= Wire.JOB_FLAG_DEPENDENT; return this; }

        public JobObject build() {
            long jobId = (id != null) ? id
                       : Ids.JobId.of(new Ids.FunctionId(functionId), new Ids.DataId(inputDataId)).value();

            ByteBuffer buffer = allocate(Wire.JOB_HEADER_LENGTH, Wire.OBJECT_TYPE_JOB, jobId);
            buffer.putLong(Wire.JOB_FUNCTION_ID_OFFSET, functionId);
            buffer.putLong(Wire.JOB_INPUT_DATA_ID_OFFSET, inputDataId);
            buffer.putLong(Wire.JOB_OUTPUT_DATA_ID_OFFSET, outputDataId != null ? outputDataId : jobId);
            buffer.putLong(Wire.JOB_PARENT_JOB_ID_OFFSET, 0L);
            buffer.putLong(Wire.JOB_PREVIOUS_JOB_ID_OFFSET, previousJobId);
            buffer.putLong(Wire.JOB_NEXT_JOB_ID_OFFSET, nextJobId);
            buffer.putInt(Wire.JOB_STATE_OFFSET, state);
            buffer.putInt(Wire.JOB_PART_INDEX_OFFSET, 0);
            buffer.putInt(Wire.JOB_PART_COUNT_OFFSET, WHOLE);
            buffer.putInt(Wire.JOB_SOURCE_NODE_OFFSET, sourceNode);
            buffer.putInt(Wire.JOB_DESTINATION_NODE_OFFSET, destinationNode);
            buffer.putInt(Wire.JOB_FLAGS_OFFSET, flags);
            return new JobObject(buffer.array(), 0);
        }
    }
}

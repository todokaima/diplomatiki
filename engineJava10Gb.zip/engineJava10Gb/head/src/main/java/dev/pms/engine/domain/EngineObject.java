package dev.pms.engine.domain;

import java.nio.ByteBuffer;
import java.util.Arrays;

public abstract class EngineObject {

    protected final byte[] bytes;
    protected final int offset;
    protected final ByteBuffer buffer;

    protected EngineObject(byte[] bytes, int offset) {
        this.bytes = bytes;
        this.offset = offset;
        this.buffer = Bytes.wrapLittleEndian(bytes);
    }

    public int magic()        { return buffer.getInt(offset + Wire.OBJECT_MAGIC_OFFSET); }
    public int version()      { return buffer.getShort(offset + Wire.OBJECT_VERSION_OFFSET) & 0xFFFF; }
    public int type()         { return buffer.getShort(offset + Wire.OBJECT_TYPE_OFFSET) & 0xFFFF; }
    public long id()          { return buffer.getLong(offset + Wire.OBJECT_ID_OFFSET); }
    public long totalLength() { return buffer.getLong(offset + Wire.OBJECT_TOTAL_LENGTH_OFFSET); }

    public byte[] backing() { return bytes; }

    public int offset() { return offset; }

    public byte[] toBytes() {
        int length = (int) totalLength();
        if (offset == 0 && bytes.length == length) return bytes;
        return Arrays.copyOfRange(bytes, offset, offset + length);
    }

    public static EngineObject wrap(byte[] bytes) { return wrap(bytes, 0); }

    public static EngineObject wrap(byte[] bytes, int offset) {
        int type = Bytes.wrapLittleEndian(bytes)
                             .getShort(offset + Wire.OBJECT_TYPE_OFFSET) & 0xFFFF;
        return switch (type) {
            case Wire.OBJECT_TYPE_DATA     -> new DataObject(bytes, offset);
            case Wire.OBJECT_TYPE_FUNCTION -> new FunctionObject(bytes, offset);
            case Wire.OBJECT_TYPE_JOB      -> new JobObject(bytes, offset);
            case Wire.OBJECT_TYPE_REQUEST  -> new RequestObject(bytes, offset);
            default -> throw new IllegalArgumentException("unknown object type: " + type);
        };
    }

    public static int magicFor(int type) {
        return switch (type) {
            case Wire.OBJECT_TYPE_DATA     -> Wire.DATA_MAGIC;
            case Wire.OBJECT_TYPE_FUNCTION -> Wire.FUNCTION_MAGIC;
            case Wire.OBJECT_TYPE_JOB      -> Wire.JOB_MAGIC;
            case Wire.OBJECT_TYPE_REQUEST  -> Wire.REQUEST_MAGIC;
            default -> 0;
        };
    }

    protected static ByteBuffer allocate(int totalLength, int type, long id) {
        ByteBuffer buffer = Bytes.allocateLittleEndian(totalLength);
        buffer.putInt(Wire.OBJECT_MAGIC_OFFSET, magicFor(type));
        buffer.putShort(Wire.OBJECT_VERSION_OFFSET, (short) Wire.ENGINE_VERSION);
        buffer.putShort(Wire.OBJECT_TYPE_OFFSET, (short) type);
        buffer.putLong(Wire.OBJECT_ID_OFFSET, id);
        buffer.putLong(Wire.OBJECT_TOTAL_LENGTH_OFFSET, totalLength);
        return buffer;
    }

    @Override public String toString() {
        return String.format("%s id=%016x %d B", getClass().getSimpleName(), id(), totalLength());
    }
}

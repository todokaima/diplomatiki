package dev.pms.engine.port;

import dev.pms.engine.domain.RequestObject;

public interface ArtifactRequester {

    boolean request(RequestObject request);
}

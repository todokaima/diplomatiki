package dev.pms.engine.adapter.peer;

import dev.pms.engine.adapter.out.log.EventLog;
import dev.pms.engine.domain.*;
import dev.pms.engine.port.ArtifactRequester;
import dev.pms.engine.port.ClusterDirectory;
import dev.pms.engine.service.ArtifactExchange;
import dev.pms.engine.service.Resolution;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;

public final class PeerNetwork implements ArtifactRequester, AutoCloseable {

    private static final int CONNECT_TIMEOUT_MILLIS = 2000;
    private static final int INTAKE_BACKLOG = 4096;
    private static final int ANSWERING_BACKLOG = 16384;

    private final String nodeId;
    private final String peerAddress;
    private final ClusterDirectory cluster;
    private final EventLog log;

    private final List<PeerLink> links = new CopyOnWriteArrayList<>();
    private final Map<String, PeerLink> linksByAddress = new ConcurrentHashMap<>();
    private final BlockingQueue<RequestObject> requests = new LinkedBlockingQueue<>();

    private ArtifactExchange exchange;
    private Consumer<JobObject> onJob;
    private Runnable onArtifact;
    private Lane intake;
    private Lane answering;
    private ServerSocket server;
    private ServerSocket dataServer;
    private Thread dispatcher;

    private volatile String localControl;
    private volatile String localData;
    private volatile String peerData;
    private volatile Set<InetAddress> peerHosts = Set.of();
    private volatile int socketBuffer;

    public PeerNetwork(String nodeId, String peerAddress, ClusterDirectory cluster, EventLog log) {
        this.nodeId = nodeId;
        this.peerAddress = peerAddress;
        this.cluster = cluster;
        this.log = log;
    }

    public void attach(ArtifactExchange exchange, Consumer<JobObject> onJob, Runnable onArtifact) {
        this.exchange = exchange;
        this.onJob = onJob;
        this.onArtifact = onArtifact;

        intake = new Lane("intake", INTAKE_BACKLOG, log);
        answering = new Lane("answering", ANSWERING_BACKLOG, log);

        dispatcher = new Thread(this::dispatch, "requests");
        dispatcher.setDaemon(true);
        dispatcher.start();
    }

    public void splitChannels(String localControl, String localData, String peerData) throws IOException {
        this.localControl = localControl;
        this.localData = localData;
        this.peerData = peerData;

        if (peerData == null || peerAddress == null) return;

        peerHosts = Set.copyOf(List.of(InetAddress.getByName(host(peerAddress)), InetAddress.getByName(host(peerData))));
        log.event("two channels: control %s -> %s, data %s -> %s", orAny(localControl), peerAddress, orAny(localData), peerData);
    }

    public void socketBuffer(int bytes) { this.socketBuffer = bytes; }

    public void listen(int port) throws IOException {
        server = bind(localControl, port);
        log.event("listening on %s:%d for the other head (control)", orAny(localControl), port);
        accept(server, "listen " + port);
    }

    public void listenData(int port) throws IOException {
        dataServer = bind(localData, port);
        log.event("listening on %s:%d for the other head (data)", orAny(localData), port);
        accept(dataServer, "listen data " + port);
    }

    private ServerSocket bind(String host, int port) throws IOException {
        ServerSocket listener = new ServerSocket();
        listener.setReuseAddress(true);
        if (socketBuffer > 0) listener.setReceiveBufferSize(socketBuffer);
        listener.bind(host == null ? new InetSocketAddress(port) : new InetSocketAddress(host, port));
        return listener;
    }

    private void accept(ServerSocket listener, String threadName) {
        Thread acceptor = new Thread(() -> {
            while (!listener.isClosed()) {
                try {
                    Socket socket = listener.accept();
                    if (socketBuffer > 0) socket.setSendBufferSize(socketBuffer);
                    adopt(socket, "peer " + socket.getRemoteSocketAddress(), peerHosts.contains(socket.getInetAddress()));
                } catch (IOException failed) {
                    if (!listener.isClosed()) log.event("accept: %s", failed.getMessage());
                }
            }
        }, threadName);

        acceptor.setDaemon(true);
        acceptor.start();
    }

    public void ship(String address, Resolution resolution, boolean jobOnly) throws IOException {
        PeerLink link = jobOnly ? linkTo(address, localControl) : bulkLinkTo(address);

        if (link == null) throw new IOException("cannot reach " + address);

        if (jobOnly) link.send(resolution.job());
        else link.ship(resolution.function(), resolution.data(), resolution.job());
    }

    @Override
    public boolean request(RequestObject request) {
        requests.add(request);
        return true;
    }

    private void dispatch() {
        try {
            while (true) {
                RequestObject request = requests.take();
                PeerLink link = otherHead();

                if (link == null) {
                    exchange.undelivered(request);
                    continue;
                }

                link.send(request);
                log.event("asked %s for %s %016x", link.name(), request.targetType() == Wire.OBJECT_TYPE_FUNCTION ? "function" : "data", request.targetId());
            }
        } catch (InterruptedException closing) {
        }
    }

    private PeerLink otherHead() {
        if (peerAddress != null) return linkTo(peerAddress, localControl);

        if (cluster == null) return null;

        try {
            for (NodeLoad node : cluster.nodes().values())
                if (!node.nodeId().equals(nodeId)) return linkTo(node.address(), localControl);
        } catch (IOException unreachable) {
        }

        return null;
    }

    private PeerLink bulkLinkTo(String address) {
        if (peerData != null && address.equals(peerAddress)) {
            PeerLink data = linkTo(peerData, localData);
            if (data != null) return data;
            log.event("data channel down, using control to %s", address);
        }

        return linkTo(address, localControl);
    }

    private boolean sendBulk(EngineObject artifact) {
        if (peerData == null) return false;

        PeerLink data = linkTo(peerData, localData);
        if (data == null) return false;

        data.send(artifact);
        return true;
    }

    private synchronized PeerLink linkTo(String address, String localHost) {
        PeerLink known = linksByAddress.get(address);
        if (known != null && known.isOpen()) return known;

        int colon = address.lastIndexOf(':');
        if (colon < 0) return null;

        try {
            Socket socket = new Socket();
            if (socketBuffer > 0) {
                socket.setSendBufferSize(socketBuffer);
                socket.setReceiveBufferSize(socketBuffer);
            }
            if (localHost != null) socket.bind(new InetSocketAddress(localHost, 0));
            socket.connect(new InetSocketAddress(address.substring(0, colon), Integer.parseInt(address.substring(colon + 1))), CONNECT_TIMEOUT_MILLIS);

            boolean peer = peerData != null && (address.equals(peerAddress) || address.equals(peerData));
            PeerLink link = adopt(socket, address, peer);
            linksByAddress.put(address, link);
            return link;

        } catch (IOException | NumberFormatException unreachable) {
            log.event("cannot reach %s: %s", address, unreachable.getMessage());
            return null;
        }
    }

    private PeerLink adopt(Socket socket, String name, boolean peer) throws IOException {
        PeerLink.BulkRoute bulk = peer ? this::sendBulk : null;
        PeerLink link = new PeerLink(socket, name, exchange, onJob, onArtifact, this::onClosed, intake, answering, bulk, log);

        links.add(link);
        link.start();
        log.event("linked to %s", name);

        return link;
    }

    private void onClosed(PeerLink link) {
        links.remove(link);
        if (linksByAddress.values().remove(link)) exchange.linkClosed();
        log.event("link %s closed", link.name());
    }

    private static String host(String address) {
        int colon = address.lastIndexOf(':');
        return colon < 0 ? address : address.substring(0, colon);
    }

    private static String orAny(String host) { return host == null ? "*" : host; }

    @Override
    public void close() {
        if (dispatcher != null) dispatcher.interrupt();
        if (intake != null) intake.stop();
        if (answering != null) answering.stop();

        for (ServerSocket listener : new ServerSocket[] { server, dataServer }) {
            try {
                if (listener != null) listener.close();
            } catch (IOException ignored) {
            }
        }

        for (PeerLink link : links)
            link.close();
    }
}

package dev.pms.engine.port;

import dev.pms.engine.domain.NodeLoad;

public interface LoadSampler {

    void sample();

    NodeLoad reading(String nodeId, int running, int maxSlots, String address);

    double load();
}

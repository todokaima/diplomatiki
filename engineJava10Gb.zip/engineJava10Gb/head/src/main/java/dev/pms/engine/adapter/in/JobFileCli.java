package dev.pms.engine.adapter.in;

import dev.pms.engine.adapter.out.file.FollowingFileObjectReader;
import dev.pms.engine.adapter.out.file.LocalArtifactCatalog;
import dev.pms.engine.adapter.out.log.EventLog;
import dev.pms.engine.adapter.out.stream.StreamObjectReader;
import dev.pms.engine.domain.*;
import dev.pms.engine.port.ArtifactCatalog;
import dev.pms.engine.port.ObjectReader;
import dev.pms.engine.service.PeerChooser;
import dev.pms.engine.service.Resolution;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

public final class JobFileCli {

    public static final String DEFAULT_JOB_FILE = "jobs/jobs.bin";

    public static void main(String[] args) {
        String path = null;
        String node = null;
        boolean follow = false;
        String functionDirectory = LocalArtifactCatalog.DEFAULT_FUNCTION_DIRECTORY;
        String datasetDirectory = LocalArtifactCatalog.DEFAULT_DATASET_DIRECTORY;
        String etcdEndpoints = null;
        String nodeId = "node";
        String advertise = null;
        String peer = null;
        int port = 0;
        int maxSlots = Runtime.getRuntime().availableProcessors();
        double busyAbove = 0.70;
        double shipMargin = 0.20;
        boolean shipJobOnly = false;
        boolean spread = false;
        int lingerSeconds = 0;
        String logFile = null;

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--follow"    -> follow = true;
                case "--node"      -> node = args[++i];
                case "--functions" -> functionDirectory = args[++i];
                case "--datasets"  -> datasetDirectory = args[++i];
                case "--etcd"      -> etcdEndpoints = args[++i];
                case "--node-id"   -> nodeId = args[++i];
                case "--advertise" -> advertise = args[++i];
                case "--peer"      -> peer = args[++i];
                case "--port"      -> port = Integer.parseInt(args[++i]);
                case "--slots"     -> maxSlots = Integer.parseInt(args[++i]);
                case "--busy-above"   -> busyAbove = Double.parseDouble(args[++i]);
                case "--ship-margin"  -> shipMargin = Double.parseDouble(args[++i]);
                case "--ship-job-only" -> shipJobOnly = true;
                case "--spread"    -> spread = true;
                case "--linger"    -> lingerSeconds = Integer.parseInt(args[++i]);
                case "--log"       -> logFile = args[++i];
                default -> { if (path == null) path = args[i]; }
            }
        }

        if (path == null) path = DEFAULT_JOB_FILE;

        if (!Files.exists(Path.of(path))) {
            System.err.println("no job file at " + path + " -- publish one with pipeIn (./pipein.py all), or pass a path");
            System.err.println("usage: jobfile [path] [--follow] [--node <socket>] [--port <n>] [--peer <host:port>] [--functions <dir>] [--datasets <dir>]");
            System.exit(1);
        }

        if (advertise == null) advertise = "127.0.0.1:" + (port > 0 ? port : 9099);

        ArtifactCatalog catalog = new LocalArtifactCatalog(functionDirectory, datasetDirectory);
        EventLog log = new EventLog(nodeId, logFile == null ? null : Path.of(logFile));
        PeerChooser chooser = new PeerChooser(busyAbove, shipMargin);

        log.event("reading %s%s, functions=%s datasets=%s", path, follow ? " (following)" : "", functionDirectory, datasetDirectory);

        Path jobFile = Path.of(path);

        boolean isPipe = Files.exists(jobFile) && !Files.isRegularFile(jobFile);

        try (HeadRuntime head = new HeadRuntime(nodeId, catalog, node, etcdEndpoints, advertise, maxSlots, peer, false, log);
             ObjectReader reader = (follow && !isPipe)
                     ? new FollowingFileObjectReader(jobFile)
                     : new StreamObjectReader(new FileInputStream(path))) {

            if (port > 0) head.listen(port);
            head.start();

            int resolved = 0;
            int shipped = 0;
            long turn = 0;
            EngineObject object;

            while ((object = reader.read()) != null) {
                if (object instanceof FunctionObject || object instanceof DataObject) {
                    head.exchange().receive(object);
                    log.event("kept %s", object);
                    continue;
                }

                if (!(object instanceof JobObject job)) {
                    log.event("ignoring %s", object);
                    continue;
                }

                Resolution resolution = head.resolver().resolve(job);

                if (!resolution.complete()) {
                    log.event("job %s waiting:%s%s%s", job.jobId(), resolution.needsFunction() ? String.format(" function %016x", job.functionId()) : "", resolution.needsData() ? String.format(" data %016x", job.inputDataId()) : "", job.dependent() ? " (dependent)" : "");
                    continue;
                }

                Optional<NodeLoad> target = Optional.empty();
                if (head.cluster() != null) {
                    try {
                        target = spread
                                ? chooser.spread(nodeId, head.cluster().nodes(), turn++)
                                : chooser.choose(nodeId, head.sampler().load(), head.cluster().nodes());
                    } catch (Exception lookup) {
                        log.event("cluster: %s", lookup.getMessage());
                    }
                }

                if (target.isPresent()) {
                    try {
                        head.ship(target.get().address(), resolution, shipJobOnly);
                        log.event("job %s shipped to %s (%s; my load %.2f, theirs %.2f)", job.jobId(), target.get().nodeId(), shipJobOnly ? "job only, 96 B" : String.format("with function and %d B of data", resolution.data().payloadLength()), head.sampler().load(), target.get().load());
                        shipped++;
                        continue;
                    } catch (IOException unreachable) {
                        log.event("cannot ship job %s, running it here: %s", job.jobId(), unreachable.getMessage());
                    }
                }

                head.runHere(resolution);
                resolved++;
            }

            log.event("%d job(s) ran here, %d shipped, %d waiting", resolved, shipped, head.resolver().waiting().size());

            while (port > 0 || !head.resolver().waiting().isEmpty())
                Thread.sleep(1000);

            if (lingerSeconds > 0 && head.cluster() != null) {
                log.event("waiting %ds so the results are published", lingerSeconds);
                Thread.sleep(lingerSeconds * 1000L);
                log.event("now holding %d dataset(s)", catalog.readyData().size());
            }

        } catch (Exception e) {
            log.event("failed: %s", e.getMessage());
            System.exit(1);
        }
    }
}

package dev.pms.engine.service;

import dev.pms.engine.domain.JobObject;
import dev.pms.engine.domain.RequestObject;
import dev.pms.engine.port.ArtifactRequester;

import java.util.HashSet;
import java.util.Set;

public final class OpenRequests {

    private final ArtifactRequester requester;
    private final Set<Long> open = new HashSet<>();

    public OpenRequests(ArtifactRequester requester) {
        this.requester = requester;
    }

    synchronized void ask(int type, long id, JobObject job) {
        if (requester == null || open.contains(id)) return;

        RequestObject request = RequestObject.builder().target(type, id).forJob(job.jobId()).build();

        if (requester.request(request)) open.add(id);
    }

    synchronized void free(long id) { open.remove(id); }

    synchronized void freeAll() { open.clear(); }
}

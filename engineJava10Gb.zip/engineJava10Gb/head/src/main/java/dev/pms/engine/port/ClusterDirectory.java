package dev.pms.engine.port;

import dev.pms.engine.domain.Ids;
import dev.pms.engine.domain.NodeLoad;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

public interface ClusterDirectory extends AutoCloseable {

    void publishLoad(NodeLoad load) throws IOException;

    Map<String, NodeLoad> nodes() throws IOException;

    int publishReadyData(String nodeId, Collection<Ids.DataId> ready) throws IOException;

    Map<String, Collection<Ids.DataId>> readyData() throws IOException;

    Optional<String> nodeHolding(Ids.DataId dataId) throws IOException;

    @Override
    void close() throws IOException;
}

package dev.pms.engine.service;

import dev.pms.engine.domain.JobObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class WaitingJobs {

    interface Step {
        boolean resolved(JobObject job) throws IOException;
    }

    private static final class Node {
        final JobObject job;
        Node next;

        Node(JobObject job) { this.job = job; }
    }

    private Node head;
    private Node tail;
    private int size;
    private final Set<Long> ids = new HashSet<>();

    void add(JobObject job) {
        Node node = new Node(job);

        if (tail == null) head = node;
        else tail.next = node;

        tail = node;
        size++;
        ids.add(job.id());
    }

    boolean contains(long jobId) { return ids.contains(jobId); }

    int size() { return size; }

    List<JobObject> snapshot() {
        List<JobObject> jobs = new ArrayList<>(size);

        for (Node node = head; node != null; node = node.next)
            jobs.add(node.job);

        return jobs;
    }

    void walk(Step step) throws IOException {
        Node previous = null;
        Node node = head;

        while (node != null) {
            Node next = node.next;

            if (step.resolved(node.job)) {
                if (previous == null) head = next;
                else previous.next = next;

                if (node == tail) tail = previous;
                size--;
                ids.remove(node.job.id());
            } else {
                previous = node;
            }

            node = next;
        }
    }
}

package dev.pms.engine.service;

import dev.pms.engine.domain.*;
import dev.pms.engine.port.ArtifactCatalog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class ArtifactExchange {

    public interface Replier {
        void push(EngineObject artifact);

        boolean isOpen();
    }

    private record Watch(int type, Replier replier) {}

    private final ArtifactCatalog catalog;
    private final OpenRequests requests;
    private final Map<Long, List<Watch>> promised = new HashMap<>();

    public ArtifactExchange(ArtifactCatalog catalog, OpenRequests requests) {
        this.catalog = catalog;
        this.requests = requests;
    }

    public void receive(EngineObject artifact) throws IOException {
        if (artifact instanceof FunctionObject function) {
            catalog.store(function);
        } else if (artifact instanceof DataObject data) {
            catalog.store(data);
        } else {
            return;
        }

        requests.free(artifact.id());
        deliver(artifact.id());
    }

    public synchronized EngineObject answer(RequestObject request, Replier replier) throws IOException {
        long id = request.targetId();

        if (request.status() == Wire.REQUEST_STATUS_NOT_FOUND) {
            requests.free(id);
            return null;
        }
        if (request.status() == Wire.REQUEST_STATUS_WAITING) return null;

        EngineObject held = held(request.targetType(), id);
        if (held != null) return held;

        if (request.jobId() == 0 || replier == null) return withStatus(request, Wire.REQUEST_STATUS_NOT_FOUND);

        List<Watch> watches = promised.computeIfAbsent(id, unused -> new ArrayList<>());
        if (watches.stream().noneMatch(watch -> watch.replier() == replier))
            watches.add(new Watch(request.targetType(), replier));

        return withStatus(request, Wire.REQUEST_STATUS_WAITING);
    }

    public synchronized int deliverHeld() throws IOException {
        int pushed = 0;

        for (Iterator<Map.Entry<Long, List<Watch>>> entries = promised.entrySet().iterator(); entries.hasNext(); ) {
            Map.Entry<Long, List<Watch>> entry = entries.next();
            entry.getValue().removeIf(watch -> !watch.replier().isOpen());

            if (entry.getValue().isEmpty()) {
                entries.remove();
                continue;
            }

            EngineObject held = held(entry.getValue().get(0).type(), entry.getKey());
            if (held == null) continue;

            for (Watch watch : entry.getValue()) {
                watch.replier().push(held);
                pushed++;
            }
            entries.remove();
        }

        return pushed;
    }

    public synchronized int promisedCount() { return promised.size(); }

    public void linkClosed() { requests.freeAll(); }

    public void undelivered(RequestObject request) { requests.free(request.targetId()); }

    private synchronized void deliver(long id) throws IOException {
        List<Watch> watches = promised.remove(id);
        if (watches == null) return;

        EngineObject held = held(watches.get(0).type(), id);
        if (held == null) {
            promised.put(id, watches);
            return;
        }

        for (Watch watch : watches)
            if (watch.replier().isOpen()) watch.replier().push(held);
    }

    private EngineObject held(int type, long id) throws IOException {
        return type == Wire.OBJECT_TYPE_FUNCTION
                ? catalog.function(new Ids.FunctionId(id)).orElse(null)
                : catalog.data(new Ids.DataId(id)).orElse(null);
    }

    private static RequestObject withStatus(RequestObject request, int status) {
        return RequestObject.builder().id(request.id()).target(request.targetType(), request.targetId()).forJob(new Ids.JobId(request.jobId())).status(status).build();
    }
}

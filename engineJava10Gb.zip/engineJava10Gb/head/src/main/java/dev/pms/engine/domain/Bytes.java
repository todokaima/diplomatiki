package dev.pms.engine.domain;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class Bytes {
    private Bytes() {}

    public static ByteBuffer wrapLittleEndian(byte[] bytes) {
        return ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
    }

    public static ByteBuffer allocateLittleEndian(int size) {
        return ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
    }

    public static long hashId(byte[] data) {
        return hashId(data, 0, data.length);
    }

    public static long hashId(byte[] data, int offset, int length) {
        MessageDigest sha256 = newSha256();
        sha256.update(data, offset, length);
        return ByteBuffer.wrap(sha256.digest()).getLong();
    }

    public static long hashId(byte[]... pieces) {
        MessageDigest sha256 = newSha256();
        for (byte[] piece : pieces) sha256.update(piece);
        return ByteBuffer.wrap(sha256.digest()).getLong();
    }

    private static MessageDigest newSha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("every JDK ships SHA-256", e);
        }
    }

    public static byte[] uint16ToBytes(int value) {
        return new byte[] { (byte) value, (byte) (value >>> 8) };
    }

    public static byte[] uint32ToBytes(int value) {
        return new byte[] { (byte) value, (byte) (value >>> 8),
                            (byte) (value >>> 16), (byte) (value >>> 24) };
    }

    public static byte[] uint64ToBytes(long value) {
        byte[] bytes = new byte[8];
        for (int i = 0; i < 8; i++) bytes[i] = (byte) (value >>> (8 * i));
        return bytes;
    }
}

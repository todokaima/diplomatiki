package dev.pms.engine.service;

import dev.pms.engine.domain.DataObject;
import dev.pms.engine.domain.FunctionObject;
import dev.pms.engine.domain.JobObject;

public record Resolution(JobObject job, FunctionObject function, DataObject data, boolean needsFunction, boolean needsData) {

    static Resolution ready(JobObject job, FunctionObject function, DataObject data) {
        return new Resolution(job, function, data, false, false);
    }

    static Resolution waiting(JobObject job, boolean needsFunction, boolean needsData) {
        return new Resolution(job, null, null, needsFunction, needsData);
    }

    public boolean complete() { return !needsFunction && !needsData; }
}

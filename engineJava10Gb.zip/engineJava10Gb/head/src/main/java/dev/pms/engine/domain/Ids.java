package dev.pms.engine.domain;

public final class Ids {
    private Ids() {}

    public record FunctionId(long value) {
        public static FunctionId of(byte[] code) { return new FunctionId(Bytes.hashId(code)); }
        @Override public String toString() { return String.format("%016x", value); }
    }

    public record DataId(long value) {
        public static DataId of(byte[] payload) { return new DataId(Bytes.hashId(payload)); }
        @Override public String toString() { return String.format("%016x", value); }
    }

    public record JobId(long value) {

        public static JobId of(FunctionId functionId, DataId inputDataId) {
            return new JobId(Bytes.hashId(Bytes.uint64ToBytes(inputDataId.value()), Bytes.uint64ToBytes(functionId.value())));
        }

        @Override public String toString() { return String.format("%016x", value); }

        public int ownerIndex(int nodes) {
            if (nodes <= 0) throw new IllegalArgumentException("no nodes");
            return (int) Long.remainderUnsigned(value, nodes);
        }
    }

    public static long requestId(int targetType, long targetId, long jobId) {
        return Bytes.hashId(Bytes.uint16ToBytes(targetType), Bytes.uint64ToBytes(targetId), Bytes.uint64ToBytes(jobId));
    }
}

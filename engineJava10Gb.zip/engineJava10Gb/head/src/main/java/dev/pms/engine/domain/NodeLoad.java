package dev.pms.engine.domain;

public record NodeLoad(String nodeId, double cpu, double memory, int running, int maxSlots, String address) {

    public double load() { return 0.5 * cpu + 0.5 * memory; }

    public int freeSlots() { return Math.max(0, maxSlots - running); }

    public boolean hasRoom() { return freeSlots() > 0; }

    public String serialize() {
        return String.format("%.4f|%.4f|%d|%d|%s", cpu, memory, running, maxSlots, address);
    }

    public static NodeLoad parse(String nodeId, String stored) {
        String[] field = stored.split("\\|", -1);
        if (field.length < 5) throw new IllegalArgumentException("bad node record: " + stored);

        return new NodeLoad(nodeId, Double.parseDouble(field[0]), Double.parseDouble(field[1]), Integer.parseInt(field[2]), Integer.parseInt(field[3]), field[4]);
    }
}

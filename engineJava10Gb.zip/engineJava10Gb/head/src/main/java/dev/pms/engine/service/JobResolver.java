package dev.pms.engine.service;

import dev.pms.engine.domain.*;
import dev.pms.engine.port.ArtifactCatalog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class JobResolver {

    private final ArtifactCatalog catalog;
    private final OpenRequests requests;

    private final WaitingJobs waiting = new WaitingJobs();
    private final Set<Long> ranHere = new HashSet<>();

    public JobResolver(ArtifactCatalog catalog, OpenRequests requests) {
        this.catalog = catalog;
        this.requests = requests;
    }

    public synchronized Resolution resolve(JobObject job) throws IOException {
        boolean needsFunction = !holdsFunction(job);
        boolean needsData = !holdsData(job);

        if (!needsFunction && !needsData) return ready(job);

        if (!waiting.contains(job.id())) waiting.add(job);
        askForWhatIsMissing(job);

        return Resolution.waiting(job, needsFunction, needsData);
    }

    public synchronized List<Resolution> sweep() throws IOException {
        catalog.refresh();
        return walk(true);
    }

    public synchronized List<Resolution> recheck() throws IOException {
        return walk(false);
    }

    private List<Resolution> walk(boolean ask) throws IOException {
        if (waiting.size() == 0) return List.of();

        List<Resolution> nowReady = new ArrayList<>();

        waiting.walk(job -> {
            if (isReady(job)) {
                nowReady.add(ready(job));
                return true;
            }

            if (ask) askForWhatIsMissing(job);
            return false;
        });

        return nowReady;
    }

    public synchronized void ranHere(JobObject job) { ranHere.add(job.id()); }

    public synchronized List<JobObject> waiting() { return waiting.snapshot(); }

    private boolean isReady(JobObject job) {
        return holdsFunction(job) && holdsData(job);
    }

    private void askForWhatIsMissing(JobObject job) {
        if (!holdsFunction(job))
            requests.ask(Wire.OBJECT_TYPE_FUNCTION, job.functionId(), job);

        if (!holdsData(job) && !resultIsOurs(job))
            requests.ask(Wire.OBJECT_TYPE_DATA, job.inputDataId(), job);
    }

    private boolean resultIsOurs(JobObject job) {
        long producer = job.inputDataId();
        return job.dependent() && (ranHere.contains(producer) || waiting.contains(producer));
    }

    private boolean holdsFunction(JobObject job) {
        return catalog.hasFunction(new Ids.FunctionId(job.functionId()));
    }

    private boolean holdsData(JobObject job) {
        return catalog.hasData(new Ids.DataId(job.inputDataId()));
    }

    private Resolution ready(JobObject job) throws IOException {
        FunctionObject function = catalog.function(new Ids.FunctionId(job.functionId())).orElseThrow(() -> new IOException(String.format("function %016x vanished", job.functionId())));
        DataObject data = catalog.data(new Ids.DataId(job.inputDataId())).orElseThrow(() -> new IOException(String.format("data %016x vanished", job.inputDataId())));

        return Resolution.ready(job, function, data);
    }
}

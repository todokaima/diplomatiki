package dev.pms.engine.port;

import dev.pms.engine.domain.EngineObject;

import java.io.Closeable;
import java.io.IOException;

public interface ObjectReader extends Closeable {

    EngineObject read() throws IOException;

    @Override
    default void close() throws IOException { }
}

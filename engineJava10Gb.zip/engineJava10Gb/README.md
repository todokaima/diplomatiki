# engineJava10Gb

engineJava with two channels between the heads, each on its own 10 Gb link:

| channel | this machine (`a`) | other machine (`b`) | carries |
|---------|--------------------|---------------------|---------|
| control | 192.168.2.20:9000  | 192.168.2.10:9100   | REQUEST, WAITING / NOT_FOUND, lone jobs |
| data    | 192.168.2.21:9001  | 192.168.2.11:9101   | every FUNCTION (.so) and DATA, and a shipped job right behind its artifacts |

The worker (C) is unchanged; only the head's peer network is different
(`head/.../adapter/peer/PeerNetwork.java`, `PeerLink.java`).

## Deploy

Copy this whole directory to the other machine, then on **each** machine:

    ./build.sh                    # or the Dockerfile.build route
    sudo ./net-setup.sh a         # b on the other machine; once per boot
    ./run.sh a                    # b on the other machine

Only the two 10 Gb links are used -- never the Wi-Fi or the third wired link.
`net-setup.sh` refuses a NIC that is wireless, not up at 10 Gb, or holds both
addresses; `run.sh a|b` refuses to start unless each channel's route leaves through
the NIC that holds its own address. `net-setup.sh` is required: both 10 Gb NICs sit on 192.168.2.0/24, so without its
host routes the kernel sends both channels out of the same NIC. `JUMBO=1` also sets
MTU 9000 (both ends must match). If a firewall is on, open 9000-9001 (a) and
9100-9101 (b) on the 192.168.2.x addresses.

Check in the head log: `two channels: control ... data ...`, and later
`pushed ... (data channel)`. Watch each NIC carry its share with
`ip -s link show <nic>` or `nload`.

## How the split works

- REQUESTs always go on the control link; the answer comes back as WAITING on the
  same link, and the artifact itself on the answering head's **data** link.
- `ship` (with `--spread`) sends FUNCTION, DATA, JOB all on the data link, so the job
  can never arrive before its inputs (which would cost a second transfer).
- A client such as pipeIn (job id 0) gets its answers on the socket it asked on, on
  either port.
- If the data link cannot be reached, everything falls back to the control link.

## Options (JobServerCli)

    --bind IP  --port P               control listener and source address
    --data-bind IP  --data-port P     data listener and source address
    --peer HOST:PORT --peer-data HOST:PORT
    --socket-buffer BYTES             fixed SO_SNDBUF/SO_RCVBUF; default 0 keeps the
                                      kernel's autotuning (usually better)

Without `--peer-data` it is the original single link. `./run.sh 9000` / `./run.sh 9100`
still runs both nodes on one machine over loopback, with data on port+1, so
`PIPEIN_ENGINE=$PWD ../pipeIn/run.sh` works as before.
